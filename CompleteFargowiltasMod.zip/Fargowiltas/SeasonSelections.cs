namespace Fargowiltas;

public enum SeasonSelections
{
	Normal,
	AlwaysOn,
	AlwaysOff
}
