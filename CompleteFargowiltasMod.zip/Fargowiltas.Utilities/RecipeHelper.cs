using Terraria;
using Terraria.Localization;

namespace Fargowiltas.Utilities;

public static class RecipeHelper
{
	public static void CreateSimpleRecipe(int ingredientID, int resultID, int tileID, int ingredientAmount = 1, int resultAmount = 1, bool disableDecraft = false, bool usesRecipeGroup = false, params Condition[] conditions)
	{
		Recipe recipe = Recipe.Create(resultID, resultAmount);
		if (usesRecipeGroup)
		{
			recipe.AddRecipeGroup(ingredientID, ingredientAmount);
		}
		else
		{
			recipe.AddIngredient(ingredientID, ingredientAmount);
		}
		recipe.AddTile(tileID);
		foreach (Condition condition in conditions)
		{
			recipe.AddCondition(condition);
		}
		if (disableDecraft)
		{
			recipe.DisableDecraft();
		}
		recipe.Register();
	}

	public static string GenerateAnyItemRecipeGroupText(int vanillaId)
	{
		return $"{Language.GetTextValue("LegacyMisc.37")} {Lang.GetItemName(vanillaId)}";
	}

	public static string GenerateAnyItemRecipeGroupText(string localizationKey, bool isVanillaKey = false)
	{
		return Language.GetTextValue("LegacyMisc.37") + " " + Language.GetTextValue(isVanillaKey ? localizationKey : ("Mods.Fargowiltas.RecipeGroups." + localizationKey));
	}

	public static string GenerateAnyBannerRecipeGroupText(string vanillaKey)
	{
		return $"{Language.GetTextValue("LegacyMisc.37")} {Language.GetTextValue(vanillaKey)} {Language.GetTextValue("MapObject.Banner")}";
	}
}
