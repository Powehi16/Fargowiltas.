using System;
using System.Linq;
using Fargowiltas.Items.Misc;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent.UI.Elements;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.UI;

namespace Fargowiltas.UI;

public class StatSheetUI : UIState
{
	public struct Stat
	{
		public int ItemID;

		public Func<string> TextFunction;

		public Stat(int itemID, Func<string> textFunction)
		{
			ItemID = itemID;
			TextFunction = textFunction;
		}
	}

	public struct PermaUpgrade
	{
		public Item Item;

		public Func<bool> ConsumedBool;

		public PermaUpgrade(Item item, Func<bool> consumedBool)
		{
			Item = item;
			ConsumedBool = consumedBool;
		}
	}

	public int BackWidth = 650;

	public int BackHeight = 380;

	public const int HowManyPerColumn = 14;

	public const int HowManyColumns = 2;

	public int LineCounter;

	public int ColumnCounter;

	public UISearchBar SearchBar;

	public UIDragablePanel BackPanel;

	public UIPanel InnerPanel;

	public override void OnInitialize()
	{
		Vector2 offset = new Vector2((float)(Main.screenWidth / 2) - (float)BackWidth * 0.75f, (float)(Main.screenHeight / 2) - (float)BackHeight * 0.75f);
		BackPanel = new UIDragablePanel();
		BackPanel.Left.Set(offset.X, 0f);
		BackPanel.Top.Set(offset.Y, 0f);
		BackPanel.Width.Set(BackWidth, 0f);
		BackPanel.Height.Set(BackHeight, 0f);
		BackPanel.PaddingLeft = (BackPanel.PaddingRight = (BackPanel.PaddingTop = (BackPanel.PaddingBottom = 0f)));
		BackPanel.BackgroundColor = new Color(29, 33, 70) * 0.7f;
		Append(BackPanel);
		SearchBar = new UISearchBar(BackWidth - 8, 26);
		SearchBar.Left.Set(4f, 0f);
		SearchBar.Top.Set(6f, 0f);
		BackPanel.Append(SearchBar);
		InnerPanel = new UIPanel();
		InnerPanel.Left.Set(6f, 0f);
		InnerPanel.Top.Set(34f, 0f);
		InnerPanel.Width.Set(BackWidth - 12, 0f);
		InnerPanel.Height.Set(BackHeight - 12 - 28, 0f);
		InnerPanel.PaddingLeft = (InnerPanel.PaddingRight = (InnerPanel.PaddingTop = (InnerPanel.PaddingBottom = 0f)));
		InnerPanel.BackgroundColor = new Color(73, 94, 171) * 0.9f;
		BackPanel.Append(InnerPanel);
		base.OnInitialize();
	}

	public override void Update(GameTime gameTime)
	{
		base.Update(gameTime);
		if (Main.GameUpdateCount % ((!SearchBar.IsEmpty) ? 2 : 4) == 0)
		{
			RebuildStatList();
		}
	}

	public void RebuildStatList()
	{
		Player player = Main.LocalPlayer;
		FargoPlayer modPlayer = player.GetModPlayer<FargoPlayer>();
		InnerPanel.RemoveAllChildren();
		ColumnCounter = (LineCounter = 0);
		AddStat("MeleeDamage", 3508, Damage(DamageClass.Melee));
		AddStat("MeleeCritical", 3508, Crit(DamageClass.Melee));
		AddStat("MeleeSpeed", 3508, (int)Math.Round(player.GetAttackSpeed(DamageClass.Melee) * 100f));
		AddStat("RangedDamage", 3504, Damage(DamageClass.Ranged));
		AddStat("RangedCritical", 3504, Crit(DamageClass.Ranged));
		AddStat("MagicDamage", 3069, Damage(DamageClass.Magic));
		AddStat("MagicCritical", 3069, Crit(DamageClass.Magic));
		AddStat("ManaCostReduction", 3069, Math.Round((1.0 - (double)player.manaCost) * 100.0));
		AddStat("SummonDamage", 1309, Damage(DamageClass.Summon));
		if (Fargowiltas.ModLoaded["FargowiltasSouls"])
		{
			AddStat("SummonCritical", 1309, (int)ModLoader.GetMod("FargowiltasSouls").Call("GetSummonCrit"));
		}
		else
		{
			AddStat("");
		}
		AddStat("MaxMinions", 1309, player.maxMinions);
		AddStat("MaxSentries", 1309, player.maxTurrets);
		AddStat("ArmorPenetration", 3212, player.GetArmorPenetration(DamageClass.Generic));
		AddStat("Aggro", 3016, player.aggro);
		AddStat("Life", 29, player.statLifeMax2);
		AddStat("LifeRegen", 49, player.lifeRegen / 2);
		AddStat("Mana", 109, player.statManaMax2);
		AddStat("ManaRegen", 109, player.manaRegen / 2);
		AddStat("Defense", 156, player.statDefense);
		float drCap = 100f;
		if (ModLoader.TryGetMod("FargowiltasSouls", out var soulsMod) && soulsMod.Version >= Version.Parse("1.6.1") && (bool)soulsMod.Call("EternityMode"))
		{
			drCap = 75f;
		}
		string cap = ((drCap < 100f) ? Language.GetTextValue("Mods.Fargowiltas.UI.DRCap", drCap) : "");
		AddStat("DamageReduction", 3224, Math.Round(player.endurance * 100f), cap);
		AddStat("Luck", 8, Math.Round(player.luck, 2));
		AddStat("FishingQuests", 2374, player.anglerQuestsFinished);
		AddStat("BattleCry", ModContent.ItemType<BattleCry>(), modPlayer.BattleCry ? ("[c/ff0000:" + Language.GetTextValue("Mods.Fargowiltas.Items.BattleCry.Battle") + "]") : (modPlayer.CalmingCry ? ("[c/00ffff:" + Language.GetTextValue("Mods.Fargowiltas.Items.BattleCry.Calming") + "]") : Language.GetTextValue("Mods.Fargowiltas.UI.BattleCryNone")));
		AddStat("MaxSpeed", 54, (int)((player.accRunSpeed + player.maxRunSpeed) / 2f * player.moveSpeed * 3f));
		AddStat("WingTime", 493, (player.wingTimeMax / 60 > 60 || (player.empressBrooch && !Fargowiltas.ModLoaded["CalamityMod"])) ? Language.GetTextValue("Mods.Fargowiltas.UI.WingTimeMoreThan60Sec") : Language.GetTextValue("Mods.Fargowiltas.UI.WingTimeActual", RenderWingStat(Math.Round((double)player.wingTimeMax / 60.0, 2))));
		AddStat("WingMaxSpeed", 493, RenderWingStat(Math.Round((double)(modPlayer.StatSheetWingSpeed * 32f) / 6.25)));
		AddStat("WingAscentModifier", 493, RenderWingStat(Math.Round(modPlayer.StatSheetMaxAscentMultiplier * 100f)));
		AddStat("WingHover", 493, (!modPlayer.CanHover.HasValue) ? Language.GetTextValue("Mods.Fargowiltas.UI.WingNull") : (modPlayer.CanHover.Value ? Language.GetTextValue("Mods.Fargowiltas.UI.WingHoverTrue") : Language.GetTextValue("Mods.Fargowiltas.UI.WingHoverFalse")));
		foreach (Stat stat in Fargowiltas.Instance.ModStats)
		{
			AddStat(stat.TextFunction(), stat.ItemID);
		}
		foreach (PermaUpgrade upgrade in Fargowiltas.Instance.PermaUpgrades)
		{
			if (upgrade.ConsumedBool())
			{
				AddStat(upgrade.Item.Name, upgrade.Item.type);
			}
		}
		int Crit(DamageClass damageClass)
		{
			return (int)player.GetTotalCritChance(damageClass);
		}
		double Damage(DamageClass damageClass)
		{
			return Math.Round(player.GetTotalDamage(damageClass).Additive * player.GetTotalDamage(damageClass).Multiplicative * 100f - 100f);
		}
		static string RenderWingStat(double stat)
		{
			return (stat <= 0.0) ? Language.GetTextValue("Mods.Fargowiltas.UI.WingNull") : stat.ToString();
		}
	}

	public void AddStat(string key, int item = -1, params object[] args)
	{
		AddStat(Language.GetTextValue("Mods.Fargowiltas.UI." + key, args), item);
	}

	public void AddStat(string text, int item = -1)
	{
		int left = 8 + ColumnCounter * ((BackWidth - 8) / 2);
		int top = 8 + LineCounter * 23;
		BackHeight = 25 * (LineCounter + 1) + 26 + 4;
		if (++ColumnCounter == 2)
		{
			LineCounter++;
			ColumnCounter = 0;
		}
		UIText ui = new UIText((item > -1) ? $"[i:{item}] {text}" : text);
		ui.Left.Set(left, 0f);
		ui.Top.Set(top, 0f);
		string[] words = text.Split(' ');
		if (!SearchBar.IsEmpty)
		{
			if (words.Any((string s) => s.StartsWith(SearchBar.Input, StringComparison.OrdinalIgnoreCase)))
			{
				float fade = MathHelper.Lerp(0.1f, 0.9f, (float)(Math.Sin((float)Main.GameUpdateCount / 10f) + 1.0) / 2f);
				Color color = Color.Lerp(Color.Yellow, Color.Goldenrod, fade);
				ui.TextColor = color;
			}
			else
			{
				ui.TextColor = Color.Gray * 1.5f;
			}
		}
		BackPanel.Height.Set(BackHeight, 0f);
		InnerPanel.Height.Set(BackHeight - 12 - 28, 0f);
		InnerPanel.Append(ui);
	}
}
