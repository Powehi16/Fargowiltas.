using Terraria.ModLoader.Default;

namespace Fargowiltas.TileEntities;

internal class SiblingPylonTileEntity : TEModdedPylon
{
}
