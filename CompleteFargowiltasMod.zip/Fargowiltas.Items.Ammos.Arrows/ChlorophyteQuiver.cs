namespace Fargowiltas.Items.Ammos.Arrows;

public class ChlorophyteQuiver : BaseAmmo
{
	public override int AmmunitionItem => 1235;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
