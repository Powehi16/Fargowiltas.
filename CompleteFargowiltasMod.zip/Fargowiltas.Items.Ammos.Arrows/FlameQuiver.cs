namespace Fargowiltas.Items.Ammos.Arrows;

public class FlameQuiver : BaseAmmo
{
	public override int AmmunitionItem => 41;
}
