namespace Fargowiltas.Items.Ammos.Arrows;

public class FrostburnQuiver : BaseAmmo
{
	public override int AmmunitionItem => 988;
}
