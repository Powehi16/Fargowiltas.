namespace Fargowiltas.Items.Ammos.Arrows;

public class CursedQuiver : BaseAmmo
{
	public override int AmmunitionItem => 545;
}
