namespace Fargowiltas.Items.Ammos.Arrows;

public class HellfireQuiver : BaseAmmo
{
	public override int AmmunitionItem => 265;
}
