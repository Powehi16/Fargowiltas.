namespace Fargowiltas.Items.Ammos.Arrows;

public class HolyQuiver : BaseAmmo
{
	public override int AmmunitionItem => 516;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
