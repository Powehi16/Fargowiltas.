namespace Fargowiltas.Items.Ammos.Arrows;

public class VenomQuiver : BaseAmmo
{
	public override int AmmunitionItem => 1341;
}
