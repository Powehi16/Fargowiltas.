namespace Fargowiltas.Items.Ammos.Arrows;

public class UnholyQuiver : BaseAmmo
{
	public override int AmmunitionItem => 47;
}
