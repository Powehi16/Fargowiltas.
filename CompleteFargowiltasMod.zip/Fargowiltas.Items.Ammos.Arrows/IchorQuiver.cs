namespace Fargowiltas.Items.Ammos.Arrows;

public class IchorQuiver : BaseAmmo
{
	public override int AmmunitionItem => 1334;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
