namespace Fargowiltas.Items.Ammos.Arrows;

public class BoneQuiver : BaseAmmo
{
	public override int AmmunitionItem => 3003;
}
