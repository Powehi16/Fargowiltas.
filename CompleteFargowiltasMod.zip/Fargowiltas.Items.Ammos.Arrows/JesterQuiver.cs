namespace Fargowiltas.Items.Ammos.Arrows;

public class JesterQuiver : BaseAmmo
{
	public override int AmmunitionItem => 51;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
