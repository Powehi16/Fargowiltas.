namespace Fargowiltas.Items.Ammos.Arrows;

public class LuminiteQuiver : BaseAmmo
{
	public override int AmmunitionItem => 3568;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
