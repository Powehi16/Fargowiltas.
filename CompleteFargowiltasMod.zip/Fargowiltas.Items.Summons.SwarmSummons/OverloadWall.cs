using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadWall : SwarmSummonBase
{
	public OverloadWall()
		: base(113, "OverloadWall", 10, "FleshyDoll")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive && player.ZoneUnderworldHeight;
	}
}
