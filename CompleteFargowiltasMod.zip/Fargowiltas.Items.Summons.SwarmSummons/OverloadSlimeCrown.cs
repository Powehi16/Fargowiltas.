using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadSlimeCrown : SwarmSummonBase
{
	public OverloadSlimeCrown()
		: base(50, "OverloadSlimeCrown", 50, "SlimyCrown")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
