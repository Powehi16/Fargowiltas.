using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadBetsy : SwarmSummonBase
{
	public OverloadBetsy()
		: base(551, "OverloadBetsy", 25, "BetsyEgg")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
