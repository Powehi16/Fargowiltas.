using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadEmpress : SwarmSummonBase
{
	public OverloadEmpress()
		: base(636, "OverloadEmpress", 25, "PrismaticPrimrose")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
