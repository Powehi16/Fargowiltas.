using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadDeer : SwarmSummonBase
{
	public OverloadDeer()
		: base(668, "OverloadDeer", 50, "DeerThing2")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
