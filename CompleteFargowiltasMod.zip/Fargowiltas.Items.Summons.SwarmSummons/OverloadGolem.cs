using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadGolem : SwarmSummonBase
{
	public OverloadGolem()
		: base(245, "OverloadGolem", 25, "LihzahrdPowerCell2")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive && NPC.downedPlantBoss;
	}
}
