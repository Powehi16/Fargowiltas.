using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadPlant : SwarmSummonBase
{
	public OverloadPlant()
		: base(262, "OverloadPlant", 25, "PlanterasFruit")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
