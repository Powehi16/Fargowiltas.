using Fargowiltas.Items.Summons.Abom;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadedSlimeRain : ModItem
{
	public override string Texture => "Fargowiltas/Items/Summons/Abom/SlimyBarometer";

	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 1;
		base.Item.value = 1000;
		base.Item.rare = 1;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 4;
		base.Item.consumable = false;
	}

	public override bool? UseItem(Player player)
	{
		if (FargoWorld.OverloadedSlimeRain)
		{
			Main.StopSlimeRain();
			FargoWorld.OverloadedSlimeRain = false;
		}
		else
		{
			if (Main.netMode != 1)
			{
				Main.StartSlimeRain();
				Main.slimeWarningDelay = 1;
				Main.slimeWarningTime = 1;
				Main.slimeRainKillCount = -10000;
			}
			else
			{
				NetMessage.SendData(61, -1, -1, null, player.whoAmI, -1f);
			}
			FargoWorld.OverloadedSlimeRain = true;
			SoundEngine.PlaySound(in SoundID.Roar, player.position);
		}
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(ModContent.ItemType<SlimyBarometer>()).AddIngredient(null, "Overloader", 10).AddTile(125)
			.Register();
	}
}
