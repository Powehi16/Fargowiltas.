using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadBrain : SwarmSummonBase
{
	public OverloadBrain()
		: base(266, "OverloadBrain", 25, "GoreySpine")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
