using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.Chat;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadFrostMoon : ModItem
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 1;
		base.Item.value = 1000;
		base.Item.rare = 1;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 4;
		base.Item.consumable = false;
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}

	public override bool? UseItem(Player player)
	{
		if (FargoWorld.OverloadFrostMoon)
		{
			Main.snowMoon = false;
			FargoWorld.OverloadFrostMoon = false;
			if (Main.netMode == 2)
			{
				ChatHelper.BroadcastChatMessage(NetworkText.FromKey("Mods.Fargowiltas.MessageInfo.OverloadFrostMoonStop"), new Color(175, 75, 255));
			}
			else
			{
				Main.NewText(Language.GetTextValue("Mods.Fargowiltas.MessageInfo.OverloadFrostMoonStop"), 175, 75);
			}
		}
		else
		{
			if (Main.netMode == 2)
			{
				ChatHelper.BroadcastChatMessage(NetworkText.FromKey("Mods.Fargowiltas.MessageInfo.OverloadFrostMoonStart"), new Color(50, 255, 130));
			}
			else
			{
				Main.NewText(Language.GetTextValue("Mods.Fargowiltas.MessageInfo.OverloadFrostMoonStart"), 50, byte.MaxValue, 130);
			}
			Main.snowMoon = true;
			Main.pumpkinMoon = false;
			Main.bloodMoon = false;
			if (Main.netMode != 1)
			{
				NPC.waveKills = 0f;
				NPC.waveNumber = 20;
				if (Main.netMode == 2)
				{
					ChatHelper.BroadcastChatMessage(NetworkText.FromKey("Mods.Fargowiltas.MessageInfo.OverloadFrostMoonWave20"), new Color(175, 75, 255));
				}
				else
				{
					Main.NewText(Language.GetTextValue("Mods.Fargowiltas.MessageInfo.OverloadFrostMoonWave20"), 175, 75);
				}
			}
			else
			{
				NetMessage.SendData(61, -1, -1, null, player.whoAmI, -5f);
			}
			FargoWorld.OverloadFrostMoon = true;
			SoundEngine.PlaySound(in SoundID.Roar, player.position);
		}
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(1958).AddIngredient(null, "Overloader", 10).AddTile(125)
			.Register();
	}
}
