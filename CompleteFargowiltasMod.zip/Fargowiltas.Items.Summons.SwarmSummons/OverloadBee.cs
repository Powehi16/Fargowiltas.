using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadBee : SwarmSummonBase
{
	public OverloadBee()
		: base(222, "OverloadBee", 50, "Abeemination2")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
