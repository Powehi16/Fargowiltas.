using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadTwins : SwarmSummonBase
{
	public OverloadTwins()
		: base(125, "OverloadTwins", 25, "MechEye")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive && !Main.dayTime;
	}
}
