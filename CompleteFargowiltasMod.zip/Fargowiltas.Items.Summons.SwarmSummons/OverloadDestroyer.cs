using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadDestroyer : SwarmSummonBase
{
	public OverloadDestroyer()
		: base(134, "OverloadDestroyer", 10, "MechWorm")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive && !Main.dayTime;
	}
}
