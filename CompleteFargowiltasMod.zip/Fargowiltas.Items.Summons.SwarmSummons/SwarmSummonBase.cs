using Fargowiltas.NPCs;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.Chat;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public abstract class SwarmSummonBase : ModItem
{
	private int counter = 0;

	private int npcType;

	private readonly int maxSpawn;

	private readonly string spawnMessageKey;

	private readonly string material;

	protected SwarmSummonBase(int npcType, string spawnMessageKey, int maxSpawn, string material)
	{
		this.npcType = npcType;
		this.spawnMessageKey = spawnMessageKey;
		this.maxSpawn = maxSpawn;
		this.material = material;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 100;
		base.Item.value = 10000;
		base.Item.rare = 1;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
		if (npcType == 113)
		{
			base.Item.useAnimation = 20;
			base.Item.useTime = 2;
			base.Item.consumable = false;
		}
	}

	public override bool? UseItem(Player player)
	{
		Fargowiltas.SwarmActive = true;
		Fargowiltas.SwarmTotal = 10 * player.inventory[player.selectedItem].stack;
		Fargowiltas.SwarmKills = 0;
		if (Fargowiltas.SwarmTotal < 100)
		{
			Fargowiltas.SwarmSpawned = 10;
		}
		else
		{
			Fargowiltas.SwarmSpawned = maxSpawn;
		}
		if (npcType == 35 && Main.dayTime)
		{
			npcType = 68;
		}
		else if (npcType == 125)
		{
			Fargowiltas.SwarmTotal *= 2;
		}
		if (npcType == 113)
		{
			FargoGlobalNPC.SpawnWalls(player);
			counter++;
			if (counter < 10)
			{
				return true;
			}
		}
		else
		{
			for (int i = 0; i < Fargowiltas.SwarmSpawned; i++)
			{
				int boss = NPC.NewNPC(NPC.GetBossSpawnSource(player.whoAmI), (int)player.position.X + Main.rand.Next(-1000, 1000), (int)player.position.Y + Main.rand.Next(-1000, -400), npcType);
				Main.npc[boss].GetGlobalNPC<FargoGlobalNPC>().SwarmActive = true;
				if (npcType == 125)
				{
					int twin = NPC.NewNPC(NPC.GetBossSpawnSource(player.whoAmI), (int)player.position.X + Main.rand.Next(-1000, 1000), (int)player.position.Y + Main.rand.Next(-1000, -400), 126);
					Main.npc[twin].GetGlobalNPC<FargoGlobalNPC>().SwarmActive = true;
				}
				else if (npcType != 134)
				{
				}
			}
		}
		player.inventory[player.selectedItem].stack = 0;
		if (Main.netMode == 2)
		{
			ChatHelper.BroadcastChatMessage(NetworkText.FromKey("Mods.Fargowiltas.MessageInfo." + spawnMessageKey), new Color(175, 75, 255));
			NetMessage.SendData(7);
		}
		else if (Main.netMode == 0)
		{
			Main.NewText(Language.GetTextValue("Mods.Fargowiltas.MessageInfo." + spawnMessageKey), 175, 75);
		}
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(null, material).AddIngredient(null, "Overloader").AddTile(26)
			.Register();
	}
}
