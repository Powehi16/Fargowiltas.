using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.Chat;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadMartians : ModItem
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 1;
		base.Item.value = 1000;
		base.Item.rare = 1;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 4;
		base.Item.consumable = false;
	}

	public override bool? UseItem(Player player)
	{
		if (FargoWorld.OverloadMartians)
		{
			Main.invasionSize = 1;
			FargoWorld.OverloadMartians = false;
			if (Main.netMode == 2)
			{
				ChatHelper.BroadcastChatMessage(NetworkText.FromKey("Mods.Fargowiltas.MessageInfo.OverloadMartiansStop"), new Color(175, 75, 255));
			}
			else
			{
				Main.NewText(Language.GetTextValue("Mods.Fargowiltas.MessageInfo.OverloadMartiansStop"), 175, 75);
			}
		}
		else
		{
			if (Main.netMode != 1)
			{
				Main.invasionDelay = 0;
				Main.StartInvasion(4);
				Main.invasionSize = 15000;
				Main.invasionSizeStart = 15000;
			}
			else
			{
				NetMessage.SendData(61, -1, -1, null, player.whoAmI, -7f);
			}
			FargoWorld.OverloadMartians = true;
			SoundEngine.PlaySound(in SoundID.Roar, player.position);
		}
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(null, "RunawayProbe").AddIngredient(null, "Overloader", 10).AddTile(125)
			.Register();
	}
}
