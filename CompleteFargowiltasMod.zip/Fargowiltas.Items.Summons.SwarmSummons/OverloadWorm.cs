using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadWorm : SwarmSummonBase
{
	public OverloadWorm()
		: base(13, "OverloadWorm", 25, "WormyFood")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
