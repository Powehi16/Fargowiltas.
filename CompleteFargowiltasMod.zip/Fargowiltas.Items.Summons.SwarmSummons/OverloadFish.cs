using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadFish : SwarmSummonBase
{
	public OverloadFish()
		: base(370, "OverloadFish", 25, "TruffleWorm2")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
