using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadDarkMage : SwarmSummonBase
{
	public OverloadDarkMage()
		: base(564, "OverloadDarkMage", 50, "ForbiddenTome")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
