using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadEye : SwarmSummonBase
{
	public OverloadEye()
		: base(4, "OverloadEye", 50, "SuspiciousEye")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive && !Main.dayTime;
	}
}
