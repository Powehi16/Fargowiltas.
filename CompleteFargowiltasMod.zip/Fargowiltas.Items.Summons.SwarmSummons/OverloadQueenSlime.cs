using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadQueenSlime : SwarmSummonBase
{
	public OverloadQueenSlime()
		: base(657, "OverloadQueenSlime", 25, "JellyCrystal")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
