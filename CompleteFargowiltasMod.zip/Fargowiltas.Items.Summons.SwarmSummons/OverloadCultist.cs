using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadCultist : SwarmSummonBase
{
	public OverloadCultist()
		: base(439, "OverloadCultist", 25, "CultistSummon")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
