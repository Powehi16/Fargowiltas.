using Terraria;

namespace Fargowiltas.Items.Summons.SwarmSummons;

public class OverloadMoon : SwarmSummonBase
{
	public OverloadMoon()
		: base(398, "OverloadMoon", 20, "CelestialSigil2")
	{
	}

	public override void SetStaticDefaults()
	{
	}

	public override bool CanUseItem(Player player)
	{
		return !Fargowiltas.SwarmActive;
	}
}
