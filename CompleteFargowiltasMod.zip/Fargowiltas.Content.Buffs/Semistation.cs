using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Content.Buffs;

public class Semistation : ModBuff
{
	public override void SetStaticDefaults()
	{
		Main.buffNoSave[base.Type] = true;
		Main.buffNoTimeDisplay[base.Type] = true;
	}

	public override void Update(Player player, ref int buffIndex)
	{
		if (player.whoAmI == Main.myPlayer)
		{
			Main.SceneMetrics.HasSunflower = false;
			player.buffImmune[146] = true;
			player.moveSpeed += 0.1f;
			player.moveSpeed *= 1.1f;
			player.sunflower = true;
			Main.SceneMetrics.HasCampfire = true;
			player.buffImmune[87] = true;
			Main.SceneMetrics.HasHeartLantern = false;
			player.buffImmune[89] = true;
			player.lifeRegen += 2;
			Main.SceneMetrics.HasStarInBottle = false;
			player.buffImmune[158] = true;
			player.manaRegenBonus += 2;
		}
	}
}
