using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.Chat;
using Terraria.DataStructures;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Mutant;

public class AncientSeal : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
		Main.RegisterItemAnimation(base.Item.type, new DrawAnimationVertical(6, 8));
		ItemID.Sets.AnimatesAsSoul[base.Item.type] = true;
		ItemID.Sets.ItemNoGravity[base.Type] = true;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = 1000;
		base.Item.rare = 11;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
		base.Item.shoot = ModContent.ProjectileType<SpawnProj>();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Projectile.NewProjectile(position: new Vector2((int)player.position.X + Main.rand.Next(-800, 800), (int)player.position.Y + Main.rand.Next(-1000, -250)), spawnSource: player.GetSource_ItemUse(source.Item), velocity: Vector2.Zero, Type: ModContent.ProjectileType<SpawnProj>(), Damage: 0, KnockBack: 0f, Owner: Main.myPlayer, ai0: 1f, ai1: 3f);
		for (int i = NPCID.Count; i < NPCLoader.NPCCount; i++)
		{
			NPC npc = new NPC();
			npc.SetDefaults(i);
			if (npc.boss)
			{
				string name = ((npc.ModNPC != null) ? npc.ModNPC.DisplayName.Value : Lang.GetNPCNameValue(npc.netID));
				SpawnBoss(player, i, name);
			}
		}
		if (Main.netMode == 2)
		{
			ChatHelper.BroadcastChatMessage(NetworkText.FromKey("Mods.Fargowiltas.MessageInfo.AncientSeal"), new Color(175, 75, 255));
		}
		else
		{
			Main.NewText(Language.GetTextValue("Mods.Fargowiltas.MessageInfo.AncientSeal"), new Color(175, 75, 255));
		}
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return false;
	}

	public static int SpawnBoss(Player player, int npcID, string name)
	{
		Main.NewText(Language.GetTextValue("Announcement.HasAwoken", name), new Color(175, 75, 255));
		return NPC.NewNPC(NPC.GetBossSpawnSource(player.whoAmI), (int)player.position.X + Main.rand.Next(-800, 800), (int)player.position.Y + Main.rand.Next(-1000, -250), npcID);
	}
}
