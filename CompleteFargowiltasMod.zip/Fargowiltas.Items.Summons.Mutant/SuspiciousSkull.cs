using Terraria;

namespace Fargowiltas.Items.Summons.Mutant;

public class SuspiciousSkull : BaseSummon
{
	public override int NPCType => Main.dayTime ? 68 : 35;

	public override bool ResetTimeWhenUsed => !Main.dayTime && !NPC.downedBoss3;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(1307).AddTile(18).Register();
	}
}
