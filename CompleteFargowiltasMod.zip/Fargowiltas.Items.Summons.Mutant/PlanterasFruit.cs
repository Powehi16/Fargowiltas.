namespace Fargowiltas.Items.Summons.Mutant;

public class PlanterasFruit : BaseSummon
{
	public override int NPCType => 262;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(1006, 2).AddIngredient(314, 5).AddIngredient(315, 5)
			.AddTile(26)
			.DisableDecraft()
			.Register();
	}
}
