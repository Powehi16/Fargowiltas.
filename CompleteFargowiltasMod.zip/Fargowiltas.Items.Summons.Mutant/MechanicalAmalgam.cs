using Terraria;
using Terraria.Audio;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Mutant;

public class MechanicalAmalgam : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.rare = 4;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}

	public override bool? UseItem(Player player)
	{
		NPC.SpawnOnPlayer(player.whoAmI, 134);
		NPC.SpawnOnPlayer(player.whoAmI, 127);
		NPC.SpawnOnPlayer(player.whoAmI, 125);
		NPC.SpawnOnPlayer(player.whoAmI, 126);
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return true;
	}
}
