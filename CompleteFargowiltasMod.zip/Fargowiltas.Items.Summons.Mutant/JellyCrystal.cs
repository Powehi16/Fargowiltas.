namespace Fargowiltas.Items.Summons.Mutant;

public class JellyCrystal : BaseSummon
{
	public override string Texture => "Terraria/Images/Item_4988";

	public override int NPCType => 657;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(4988).AddTile(18).Register();
		CreateRecipe().AddIngredient(502, 5).AddIngredient(520, 3).AddTile(134)
			.Register();
	}
}
