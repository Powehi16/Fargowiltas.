using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;

namespace Fargowiltas.Items.Summons.Mutant;

public class PrismaticPrimrose : BaseSummon
{
	public override int NPCType => 636;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(4961).AddTile(18).Register();
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		if (!NPC.downedEmpressOfLight)
		{
			Main.SkipToTime(0, Main.dayTime);
			if (Main.netMode == 2)
			{
				NetMessage.SendData(7);
			}
		}
		return base.Shoot(player, source, position, velocity, type, damage, knockback);
	}
}
