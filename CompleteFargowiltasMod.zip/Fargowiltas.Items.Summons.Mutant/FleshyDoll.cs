using Terraria;
using Terraria.Audio;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Mutant;

public class FleshyDoll : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
	}

	public override bool CanUseItem(Player player)
	{
		return player.position.Y / 16f > (float)(Main.maxTilesY - 200) && !NPC.AnyNPCs(113);
	}

	public override bool? UseItem(Player player)
	{
		NPC.SpawnWOF(player.Center);
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return true;
	}

	public override void PostUpdate()
	{
		if (base.Item.lavaWet && !NPC.AnyNPCs(113))
		{
			NPC.SpawnWOF(base.Item.position);
			base.Item.TurnToAir();
		}
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(267).AddTile(18).Register();
	}
}
