namespace Fargowiltas.Items.Summons.Mutant;

public class CultistSummon : BaseSummon
{
	public override int NPCType => 439;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
