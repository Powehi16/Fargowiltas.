using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Renewals;

public class DirtRenewal : BaseRenewalItem
{
	public DirtRenewal()
		: base("Forest Renewal", "Dirts a large radius", 5392)
	{
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), position, velocity, ModContent.ProjectileType<DirtNukeProj>(), 0, 0f, Main.myPlayer);
		return false;
	}
}
