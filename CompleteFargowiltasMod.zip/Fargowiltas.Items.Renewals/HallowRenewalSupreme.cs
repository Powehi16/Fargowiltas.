using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Renewals;

public class HallowRenewalSupreme : BaseRenewalItem
{
	public HallowRenewalSupreme()
		: base("Hallowed Renewal Supreme", "Hallows the entire world", -1, supreme: true, ModContent.ItemType<HallowRenewal>())
	{
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), position, velocity, ModContent.ProjectileType<HallowNukeSupremeProj>(), 0, 0f, Main.myPlayer);
		return false;
	}
}
