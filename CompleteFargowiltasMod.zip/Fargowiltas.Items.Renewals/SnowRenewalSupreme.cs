using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Renewals;

public class SnowRenewalSupreme : BaseRenewalItem
{
	public SnowRenewalSupreme()
		: base("Snow Renewal Supreme", "Snows the entire world", -1, supreme: true, ModContent.ItemType<SnowRenewal>())
	{
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), position, velocity, ModContent.ProjectileType<SnowNukeSupremeProj>(), 0, 0f, Main.myPlayer);
		return false;
	}
}
