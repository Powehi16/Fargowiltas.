using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Renewals;

public class DirtRenewalSupreme : BaseRenewalItem
{
	public DirtRenewalSupreme()
		: base("Forest Renewal Supreme", "Dirts the entire world", -1, supreme: true, ModContent.ItemType<DirtRenewal>())
	{
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), position, velocity, ModContent.ProjectileType<DirtNukeSupremeProj>(), 0, 0f, Main.myPlayer);
		return false;
	}
}
