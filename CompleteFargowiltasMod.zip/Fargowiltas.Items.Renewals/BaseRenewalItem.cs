using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Renewals;

public abstract class BaseRenewalItem : ModItem
{
	private readonly string name;

	private readonly string tooltip;

	private readonly int material;

	private readonly bool supreme;

	private readonly int supremeMaterial;

	protected BaseRenewalItem(string name, string tooltip, int material, bool supreme = false, int supremeMaterial = -1)
	{
		this.name = name;
		this.tooltip = tooltip;
		this.material = material;
		this.supreme = supreme;
		this.supremeMaterial = supremeMaterial;
	}

	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 10;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 26;
		base.Item.maxStack = 99;
		base.Item.consumable = true;
		base.Item.useStyle = 1;
		base.Item.rare = 3;
		base.Item.UseSound = SoundID.Item1;
		base.Item.useAnimation = 20;
		base.Item.useTime = 20;
		base.Item.value = Item.buyPrice(0, 0, 3);
		base.Item.noUseGraphic = true;
		base.Item.noMelee = true;
		base.Item.shoot = 1;
		base.Item.shootSpeed = 5f;
	}

	public override void AddRecipes()
	{
		Recipe recipe = Recipe.Create(base.Type);
		if (supreme)
		{
			recipe.AddIngredient(supremeMaterial, 10);
			recipe.AddIngredient(1006, 5);
			recipe.AddTile(355);
		}
		else
		{
			recipe.AddIngredient(31);
			recipe.AddIngredient(material, 100);
			recipe.AddTile(13);
		}
		recipe.Register();
	}
}
