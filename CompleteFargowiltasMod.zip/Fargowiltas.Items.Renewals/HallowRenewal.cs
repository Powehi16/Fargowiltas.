using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Renewals;

public class HallowRenewal : BaseRenewalItem
{
	public HallowRenewal()
		: base("Hallowed Renewal", "Hallows a large radius", 781)
	{
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), position, velocity, ModContent.ProjectileType<HallowNukeProj>(), 0, 0f, Main.myPlayer);
		return false;
	}
}
