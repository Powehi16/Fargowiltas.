using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Renewals;

public class MushroomRenewal : BaseRenewalItem
{
	public MushroomRenewal()
		: base("Mushroom Renewal", "Shroomifies a large radius", 783)
	{
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), position, velocity, ModContent.ProjectileType<MushroomNukeProj>(), 0, 0f, Main.myPlayer);
		return false;
	}
}
