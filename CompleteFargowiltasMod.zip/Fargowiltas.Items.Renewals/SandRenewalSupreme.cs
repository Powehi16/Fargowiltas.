using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Renewals;

public class SandRenewalSupreme : BaseRenewalItem
{
	public SandRenewalSupreme()
		: base("Desert Renewal Supreme", "Sands the entire world", -1, supreme: true, ModContent.ItemType<SandRenewal>())
	{
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), position, velocity, ModContent.ProjectileType<SandNukeSupremeProj>(), 0, 0f, Main.myPlayer);
		return false;
	}
}
