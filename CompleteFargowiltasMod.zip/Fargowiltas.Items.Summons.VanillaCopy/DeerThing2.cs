namespace Fargowiltas.Items.Summons.VanillaCopy;

public class DeerThing2 : BaseSummon
{
	public override int NPCType => 668;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(5120).AddTile(18).Register();
	}
}
