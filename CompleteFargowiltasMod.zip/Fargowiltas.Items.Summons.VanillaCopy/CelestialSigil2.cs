using Terraria.Localization;

namespace Fargowiltas.Items.Summons.VanillaCopy;

public class CelestialSigil2 : BaseSummon
{
	public override string Texture => "Terraria/Images/Item_3601";

	public override string NPCName => Language.GetTextValue("Enemies.MoonLord");

	public override int NPCType => 398;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(3601).AddTile(18).Register();
	}
}
