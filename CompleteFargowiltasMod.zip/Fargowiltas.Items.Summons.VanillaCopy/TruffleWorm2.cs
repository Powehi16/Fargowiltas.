namespace Fargowiltas.Items.Summons.VanillaCopy;

public class TruffleWorm2 : BaseSummon
{
	public override string Texture => "Terraria/Images/Item_2673";

	public override int NPCType => 370;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(2673).AddTile(18).Register();
	}
}
