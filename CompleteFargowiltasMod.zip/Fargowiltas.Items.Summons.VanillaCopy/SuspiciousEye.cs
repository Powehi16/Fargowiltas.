using Terraria;

namespace Fargowiltas.Items.Summons.VanillaCopy;

public class SuspiciousEye : BaseSummon
{
	public override int NPCType => 4;

	public override bool ResetTimeWhenUsed => !NPC.downedBoss1;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(43).AddTile(18).Register();
	}
}
