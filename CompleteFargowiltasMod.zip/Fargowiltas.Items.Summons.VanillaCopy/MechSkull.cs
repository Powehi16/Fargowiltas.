using Terraria;

namespace Fargowiltas.Items.Summons.VanillaCopy;

public class MechSkull : BaseSummon
{
	public override int NPCType => 127;

	public override bool ResetTimeWhenUsed => !NPC.downedMechBoss3;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(557).AddTile(18).Register();
	}
}
