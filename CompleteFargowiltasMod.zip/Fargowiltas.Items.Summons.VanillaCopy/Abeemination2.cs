namespace Fargowiltas.Items.Summons.VanillaCopy;

public class Abeemination2 : BaseSummon
{
	public override int NPCType => 222;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(1133).AddTile(18).Register();
	}
}
