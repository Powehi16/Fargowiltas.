using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.Chat;
using Terraria.DataStructures;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.VanillaCopy;

public class MechEye : ModItem
{
	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = 1000;
		base.Item.rare = 3;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 4;
		base.Item.consumable = true;
		base.Item.shoot = ModContent.ProjectileType<SpawnProj>();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Vector2 pos = new Vector2((int)player.position.X + Main.rand.Next(-800, 800), (int)player.position.Y + Main.rand.Next(-1000, -250));
		if (!Main.dayTime)
		{
			if (!NPC.downedMechBoss2)
			{
				Main.dayTime = false;
				Main.time = 0.0;
				if (Main.netMode == 2)
				{
					NetMessage.SendData(7);
				}
			}
			Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), pos, Vector2.Zero, ModContent.ProjectileType<SpawnProj>(), 0, 0f, Main.myPlayer, 125f);
			Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), pos, Vector2.Zero, ModContent.ProjectileType<SpawnProj>(), 0, 0f, Main.myPlayer, 126f);
			if (Main.netMode == 2)
			{
				ChatHelper.BroadcastChatMessage(NetworkText.FromKey("LegacyMisc.48"), new Color(175, 75, 255));
			}
			else
			{
				Main.NewText(Language.GetTextValue("LegacyMisc.48"), new Color(175, 75, 255));
			}
		}
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return false;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(544).AddTile(18).Register();
	}
}
