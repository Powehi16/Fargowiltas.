using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;

namespace Fargowiltas.Items.Summons.VanillaCopy;

public class WormyFood : BaseSummon
{
	public override int NPCType => 13;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !NPC.AnyNPCs(NPCType);
	}

	public override bool? UseItem(Player player)
	{
		FargoUtils.SpawnBossNetcoded(player, NPCType);
		return true;
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		return false;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(70).AddTile(18).Register();
	}
}
