namespace Fargowiltas.Items.Summons.VanillaCopy;

public class SlimyCrown : BaseSummon
{
	public override int NPCType => 50;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(560).AddTile(18).Register();
	}
}
