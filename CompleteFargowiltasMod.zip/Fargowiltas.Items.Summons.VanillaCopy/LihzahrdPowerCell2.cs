using Terraria;

namespace Fargowiltas.Items.Summons.VanillaCopy;

public class LihzahrdPowerCell2 : BaseSummon
{
	public override int NPCType => 245;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return NPC.downedPlantBoss;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(1293).AddTile(18).Register();
	}
}
