namespace Fargowiltas.Items.Summons.VanillaCopy;

public class GoreySpine : BaseSummon
{
	public override int NPCType => 266;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(1331).AddTile(18).Register();
	}
}
