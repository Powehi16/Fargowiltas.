namespace Fargowiltas.Items.Ammos.Rockets;

internal class LavaRocketBox : RocketBox
{
	public override int AmmunitionItem => 4448;

	public override int RocketProjectile => 787;

	public override int SnowmanProjectile => 806;

	public override int GrenadeProjectile => 788;

	public override int MineProjectile => 789;
}
