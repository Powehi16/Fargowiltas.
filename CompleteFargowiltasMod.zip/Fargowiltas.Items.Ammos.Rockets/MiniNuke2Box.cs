namespace Fargowiltas.Items.Ammos.Rockets;

internal class MiniNuke2Box : RocketBox
{
	public override int AmmunitionItem => 4458;

	public override int RocketProjectile => 796;

	public override int SnowmanProjectile => 809;

	public override int GrenadeProjectile => 797;

	public override int MineProjectile => 798;
}
