namespace Fargowiltas.Items.Ammos.Rockets;

internal class ClusterRocket1Box : RocketBox
{
	public override int AmmunitionItem => 4445;

	public override int RocketProjectile => 776;

	public override int SnowmanProjectile => 803;

	public override int GrenadeProjectile => 777;

	public override int MineProjectile => 778;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
