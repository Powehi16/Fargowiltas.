namespace Fargowiltas.Items.Ammos.Rockets;

internal class ClusterRocket2Box : RocketBox
{
	public override int AmmunitionItem => 4446;

	public override int RocketProjectile => 780;

	public override int SnowmanProjectile => 804;

	public override int GrenadeProjectile => 781;

	public override int MineProjectile => 782;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
