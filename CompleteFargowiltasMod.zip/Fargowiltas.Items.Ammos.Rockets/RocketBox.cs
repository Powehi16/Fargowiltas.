using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Ammos.Rockets;

public abstract class RocketBox : BaseAmmo
{
	public abstract int RocketProjectile { get; }

	public abstract int SnowmanProjectile { get; }

	public abstract int GrenadeProjectile { get; }

	public abstract int MineProjectile { get; }

	public override void PickAmmo(Item weapon, Player player, ref int type, ref float speed, ref StatModifier damage, ref float knockback)
	{
		switch (weapon.type)
		{
		case 759:
			type = RocketProjectile;
			break;
		case 1946:
			type = SnowmanProjectile;
			break;
		case 758:
			type = GrenadeProjectile;
			break;
		case 760:
			type = MineProjectile;
			break;
		}
	}
}
