namespace Fargowiltas.Items.Ammos.Rockets;

internal class Rocket1Box : RocketBox
{
	public override int AmmunitionItem => 771;

	public override int RocketProjectile => 134;

	public override int SnowmanProjectile => 338;

	public override int GrenadeProjectile => 133;

	public override int MineProjectile => 135;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
