namespace Fargowiltas.Items.Ammos.Rockets;

internal class Rocket2Box : RocketBox
{
	public override int AmmunitionItem => 772;

	public override int RocketProjectile => 137;

	public override int SnowmanProjectile => 339;

	public override int GrenadeProjectile => 136;

	public override int MineProjectile => 138;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
