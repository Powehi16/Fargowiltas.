namespace Fargowiltas.Items.Ammos.Rockets;

internal class WetRocketBox : RocketBox
{
	public override int AmmunitionItem => 4447;

	public override int RocketProjectile => 784;

	public override int SnowmanProjectile => 805;

	public override int GrenadeProjectile => 785;

	public override int MineProjectile => 786;
}
