namespace Fargowiltas.Items.Ammos.Rockets;

internal class Rocket4Box : RocketBox
{
	public override int AmmunitionItem => 774;

	public override int RocketProjectile => 143;

	public override int SnowmanProjectile => 341;

	public override int GrenadeProjectile => 142;

	public override int MineProjectile => 144;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
