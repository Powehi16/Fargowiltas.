namespace Fargowiltas.Items.Ammos.Rockets;

internal class HoneyRocketBox : RocketBox
{
	public override int AmmunitionItem => 4449;

	public override int RocketProjectile => 790;

	public override int SnowmanProjectile => 807;

	public override int GrenadeProjectile => 791;

	public override int MineProjectile => 792;
}
