namespace Fargowiltas.Items.Ammos.Rockets;

internal class DryRocketBox : RocketBox
{
	public override int AmmunitionItem => 4459;

	public override int RocketProjectile => 799;

	public override int SnowmanProjectile => 810;

	public override int GrenadeProjectile => 800;

	public override int MineProjectile => 801;
}
