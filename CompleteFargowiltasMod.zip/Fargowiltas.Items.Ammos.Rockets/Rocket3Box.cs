namespace Fargowiltas.Items.Ammos.Rockets;

internal class Rocket3Box : RocketBox
{
	public override int AmmunitionItem => 773;

	public override int RocketProjectile => 140;

	public override int SnowmanProjectile => 340;

	public override int GrenadeProjectile => 139;

	public override int MineProjectile => 141;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
