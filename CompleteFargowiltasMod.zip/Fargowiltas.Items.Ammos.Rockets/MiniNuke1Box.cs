namespace Fargowiltas.Items.Ammos.Rockets;

internal class MiniNuke1Box : RocketBox
{
	public override int AmmunitionItem => 4457;

	public override int RocketProjectile => 793;

	public override int SnowmanProjectile => 808;

	public override int GrenadeProjectile => 794;

	public override int MineProjectile => 795;
}
