using Fargowiltas.Common.Systems;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Explosives;

public class AutoHouse : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.Item.width = 10;
		base.Item.height = 32;
		base.Item.maxStack = 99;
		base.Item.consumable = true;
		base.Item.useStyle = 1;
		base.Item.rare = 1;
		base.Item.UseSound = SoundID.Item1;
		base.Item.useAnimation = 20;
		base.Item.useTime = 20;
		base.Item.value = Item.buyPrice(0, 0, 3);
		base.Item.createTile = ModContent.TileType<AutoHouseTile>();
	}

	public override void HoldItem(Player player)
	{
		if (player.whoAmI == Main.myPlayer)
		{
			Vector2 mouse = Main.MouseWorld - Vector2.UnitY * 16f;
			InstaVisual.DrawOrigin origin = ((mouse.X - player.Center.X > 0f) ? InstaVisual.DrawOrigin.Left : InstaVisual.DrawOrigin.Right);
			InstaVisual.DrawInstaVisual(player, mouse, new Vector2(10f, 6f), origin);
		}
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddRecipeGroup("Wood", 50).AddIngredient(8).AddTile(18)
			.Register();
	}
}
