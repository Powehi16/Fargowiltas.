using System.Collections.Generic;
using Fargowiltas.Projectiles.Explosives;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Explosives;

public class LihzahrdInstactuationBomb : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 10;
	}

	public override void SetDefaults()
	{
		base.Item.width = 10;
		base.Item.height = 32;
		base.Item.maxStack = 99;
		base.Item.consumable = true;
		base.Item.useStyle = 1;
		base.Item.rare = 8;
		base.Item.UseSound = SoundID.Item1;
		base.Item.useAnimation = 20;
		base.Item.useTime = 20;
		base.Item.value = Item.buyPrice(0, 0, 3);
		base.Item.noUseGraphic = true;
		base.Item.noMelee = true;
		base.Item.shoot = ModContent.ProjectileType<LihzahrdInstactuationBombProj>();
	}

	private static Vector2 NearbyAltar(Player player)
	{
		Vector2 startPos = player.Bottom;
		startPos.Y -= 8f;
		List<Vector2> positions = new List<Vector2>();
		for (int i = 0; i <= 2; i++)
		{
			for (int j = -1; j <= 1; j += 2)
			{
				Vector2 pos = startPos;
				pos.X += 16 * i * j;
				Tile tile = Framing.GetTileSafely(pos);
				if (tile.TileType == 237 && tile.WallType == 87 && Collision.CanHitLine(player.Center, 0, 0, pos, 0, 0))
				{
					positions.Add(pos);
				}
				if (positions.Count != 3)
				{
					continue;
				}
				Vector2 center = Vector2.Zero;
				foreach (Vector2 p in positions)
				{
					center += p;
				}
				return center / positions.Count;
			}
		}
		return default(Vector2);
	}

	public override bool CanUseItem(Player player)
	{
		return NPC.downedPlantBoss && NearbyAltar(player) != default(Vector2);
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Vector2 altarPos = NearbyAltar(player);
		if (altarPos != default(Vector2))
		{
			Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), altarPos, Vector2.Zero, type, 0, 0f, player.whoAmI);
		}
		return false;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(849, 500).AddIngredient(167, 25).AddIngredient(2766, 10)
			.AddTile(134)
			.Register();
	}
}
