using Fargowiltas.Projectiles.Explosives;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Explosives;

public class AltarExterminator : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.Item.width = 10;
		base.Item.height = 32;
		base.Item.maxStack = 99;
		base.Item.consumable = true;
		base.Item.useStyle = 1;
		base.Item.rare = 1;
		base.Item.UseSound = SoundID.Item1;
		base.Item.useAnimation = 20;
		base.Item.useTime = 20;
		base.Item.value = Item.buyPrice(0, 0, 3);
		base.Item.noUseGraphic = true;
		base.Item.noMelee = true;
		base.Item.shoot = ModContent.ProjectileType<AltarExterminatorProj>();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(57, 10).AddIngredient(86, 5).AddIngredient(367)
			.AddTile(16)
			.Register();
		CreateRecipe().AddIngredient(1257, 10).AddIngredient(1329, 5).AddIngredient(367)
			.AddTile(16)
			.Register();
	}
}
