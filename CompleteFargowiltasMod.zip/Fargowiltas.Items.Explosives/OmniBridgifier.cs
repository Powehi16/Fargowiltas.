using System.Linq;
using Fargowiltas.Items.Tiles;
using Fargowiltas.Projectiles.Explosives;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Explosives;

public class OmniBridgifier : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 10;
		base.Item.height = 32;
		base.Item.maxStack = 1;
		base.Item.consumable = false;
		base.Item.useStyle = 1;
		base.Item.rare = 2;
		base.Item.UseSound = SoundID.Item1;
		base.Item.useAnimation = 20;
		base.Item.useTime = 20;
		base.Item.value = Item.buyPrice(0, 0, 3);
		base.Item.noUseGraphic = true;
		base.Item.noMelee = true;
		base.Item.shoot = ModContent.ProjectileType<OmniBridgifierProj>();
		base.Item.shootSpeed = 5f;
	}

	public override void ModifyShootStats(Player player, ref Vector2 position, ref Vector2 velocity, ref int type, ref int damage, ref float knockback)
	{
		position = player.Bottom;
		position.Y += 8f;
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		float ai0 = -1f;
		if (player.inventory.Any((Item i) => !i.IsAir && i.type == ModContent.ItemType<Omnistation>()))
		{
			ai0 = 0f;
		}
		if (player.inventory.Any((Item i) => !i.IsAir && i.type == ModContent.ItemType<Omnistation2>()))
		{
			ai0 = ((ai0 != 0f) ? 1 : Main.rand.Next(2));
		}
		if (ai0 == -1f)
		{
			ai0 = Main.rand.Next(2);
		}
		Projectile.NewProjectile(source, position, velocity, type, damage, knockback, player.whoAmI, ai0);
		return false;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(ModContent.ItemType<InstaBridge>()).AddTile(ModContent.TileType<OmnistationSheet>()).Register();
		CreateRecipe().AddIngredient(ModContent.ItemType<InstaBridge>()).AddTile(ModContent.TileType<OmnistationSheet2>()).Register();
	}
}
