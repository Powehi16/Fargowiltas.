using Fargowiltas.Projectiles.Explosives;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Explosives;

public class BoomShuriken : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 999;
	}

	public override void SetDefaults()
	{
		base.Item.width = 11;
		base.Item.height = 11;
		base.Item.damage = 16;
		base.Item.noMelee = true;
		base.Item.consumable = true;
		base.Item.noUseGraphic = true;
		base.Item.scale = 0.75f;
		base.Item.useStyle = 1;
		base.Item.useTime = 10;
		base.Item.useAnimation = 10;
		base.Item.knockBack = 3f;
		base.Item.UseSound = SoundID.Item1;
		base.Item.autoReuse = true;
		base.Item.maxStack = 999;
		base.Item.rare = 1;
		base.Item.shoot = ModContent.ProjectileType<ShurikenProj>();
		base.Item.shootSpeed = 11f;
	}

	public override void AddRecipes()
	{
		CreateRecipe(20).AddIngredient(42, 20).AddIngredient(167).AddTile(16)
			.Register();
	}
}
