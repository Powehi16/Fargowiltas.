using Fargowiltas.Common.Systems;
using Fargowiltas.Projectiles.Explosives;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Explosives;

public class InstaPond : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 10;
	}

	public override void SetDefaults()
	{
		base.Item.width = 46;
		base.Item.height = 48;
		base.Item.maxStack = 99;
		base.Item.consumable = true;
		base.Item.useStyle = 1;
		base.Item.rare = 2;
		base.Item.UseSound = SoundID.Item1;
		base.Item.useAnimation = 20;
		base.Item.useTime = 20;
		base.Item.value = Item.buyPrice(0, 0, 3);
		base.Item.noUseGraphic = true;
		base.Item.noMelee = true;
		base.Item.shoot = ModContent.ProjectileType<InstaPondProj>();
		base.Item.shootSpeed = 5f;
	}

	public override void HoldItem(Player player)
	{
		if (player.whoAmI == Main.myPlayer)
		{
			Vector2 mouse = Main.MouseWorld;
			InstaVisual.DrawOrigin drawOrigin = InstaVisual.DrawOrigin.Top;
			InstaVisual.DrawInstaVisual(player, mouse, new Vector2(1000f, 5f), drawOrigin);
		}
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(167, 25).AddIngredient(4824, 3).AddTile(16)
			.Register();
	}
}
