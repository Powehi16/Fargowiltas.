using Fargowiltas.Projectiles.Explosives;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Explosives;

public class CityBuster : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 10;
	}

	public override void SetDefaults()
	{
		base.Item.width = 30;
		base.Item.height = 26;
		base.Item.maxStack = 99;
		base.Item.consumable = true;
		base.Item.useStyle = 1;
		base.Item.rare = 2;
		base.Item.UseSound = SoundID.Item1;
		base.Item.useAnimation = 20;
		base.Item.useTime = 20;
		base.Item.value = Item.buyPrice(0, 0, 1);
		base.Item.noUseGraphic = true;
		base.Item.noMelee = true;
		base.Item.shoot = ModContent.ProjectileType<global::Fargowiltas.Projectiles.Explosives.CityBuster>();
		base.Item.shootSpeed = 5f;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(167, 50).AddIngredient(75).AddTile(16)
			.Register();
	}
}
