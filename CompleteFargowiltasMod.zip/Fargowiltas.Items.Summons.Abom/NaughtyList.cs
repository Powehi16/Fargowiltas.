using Terraria;

namespace Fargowiltas.Items.Summons.Abom;

public class NaughtyList : BaseSummon
{
	public override int NPCType => 346;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}
}
