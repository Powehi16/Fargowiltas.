namespace Fargowiltas.Items.Summons.Abom;

public class ForbiddenTome : BaseSummon
{
	public override int NPCType => 564;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
