using Terraria;

namespace Fargowiltas.Items.Summons.Abom;

public class FestiveOrnament : BaseSummon
{
	public override int NPCType => 344;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}
}
