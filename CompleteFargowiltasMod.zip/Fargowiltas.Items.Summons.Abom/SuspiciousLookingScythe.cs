using Terraria;

namespace Fargowiltas.Items.Summons.Abom;

public class SuspiciousLookingScythe : BaseSummon
{
	public override int NPCType => 327;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}
}
