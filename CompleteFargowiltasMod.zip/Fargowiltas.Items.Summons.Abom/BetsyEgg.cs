namespace Fargowiltas.Items.Summons.Abom;

public class BetsyEgg : BaseSummon
{
	public override int NPCType => 551;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
