using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Abom;

public class PillarSummon : ModItem
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.rare = 9;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
		base.Item.shoot = ModContent.ProjectileType<SpawnProj>();
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		int[] pillars = new int[4] { 507, 517, 493, 422 };
		if (!NPC.AnyNPCs(517))
		{
			NPC.ShieldStrengthTowerSolar = 0;
		}
		if (!NPC.AnyNPCs(422))
		{
			NPC.ShieldStrengthTowerVortex = 0;
		}
		if (!NPC.AnyNPCs(507))
		{
			NPC.ShieldStrengthTowerNebula = 0;
		}
		if (!NPC.AnyNPCs(493))
		{
			NPC.ShieldStrengthTowerStardust = 0;
		}
		for (int i = 0; i < pillars.Length; i++)
		{
			Projectile.NewProjectile(position: new Vector2((int)player.position.X + 400 * i - 600, (int)player.position.Y - 200), spawnSource: player.GetSource_ItemUse(source.Item), velocity: Vector2.Zero, Type: type, Damage: 0, KnockBack: 0f, Owner: Main.myPlayer, ai0: pillars[i]);
		}
		FargoUtils.PrintLocalization("MessageInfo.StartLunarEvent", new Color(175, 75, 255));
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return false;
	}
}
