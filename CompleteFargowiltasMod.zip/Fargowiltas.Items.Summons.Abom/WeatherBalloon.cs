using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent.Creative;
using Terraria.GameContent.Events;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Abom;

public class WeatherBalloon : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.rare = 1;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.IsItRaining && !Main.IsItStorming;
	}

	public override bool? UseItem(Player player)
	{
		LanternNight.GenuineLanterns = false;
		LanternNight.ManualLanterns = false;
		int day = 86400;
		int hour = day / 24;
		Main.rainTime = hour * 12;
		Main.raining = true;
		Main.maxRaining = (Main.cloudAlpha = 0.9f);
		if (Main.netMode == 2)
		{
			NetMessage.SendData(7);
			Main.SyncRain();
		}
		FargoUtils.PrintLocalization("MessageInfo.StartRain", new Color(175, 75, 255));
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return true;
	}
}
