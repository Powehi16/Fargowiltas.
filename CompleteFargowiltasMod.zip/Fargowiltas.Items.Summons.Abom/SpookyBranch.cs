using Terraria;

namespace Fargowiltas.Items.Summons.Abom;

public class SpookyBranch : BaseSummon
{
	public override int NPCType => 325;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}
}
