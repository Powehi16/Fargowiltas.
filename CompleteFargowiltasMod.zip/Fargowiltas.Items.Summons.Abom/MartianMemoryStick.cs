namespace Fargowiltas.Items.Summons.Abom;

public class MartianMemoryStick : BaseSummon
{
	public override int NPCType => 395;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
