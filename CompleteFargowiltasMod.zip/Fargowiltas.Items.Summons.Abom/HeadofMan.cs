using Terraria;

namespace Fargowiltas.Items.Summons.Abom;

public class HeadofMan : BaseSummon
{
	public override int NPCType => 315;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}
}
