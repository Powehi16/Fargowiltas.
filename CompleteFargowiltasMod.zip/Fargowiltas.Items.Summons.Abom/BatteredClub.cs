namespace Fargowiltas.Items.Summons.Abom;

public class BatteredClub : BaseSummon
{
	public override int NPCType => 576;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
