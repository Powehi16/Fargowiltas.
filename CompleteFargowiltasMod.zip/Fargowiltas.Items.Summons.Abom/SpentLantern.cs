using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Abom;

public class SpentLantern : MatsuriLantern
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.SetDefaults();
		base.Item.consumable = false;
	}

	public override bool CanUseItem(Player player)
	{
		return FargoWorld.Matsuri;
	}

	public override bool? UseItem(Player player)
	{
		FargoWorld.Matsuri = false;
		FargoUtils.PrintLocalization("MessageInfo.StopLanternNight", new Color(175, 75, 255));
		if (Main.netMode == 2)
		{
			NetMessage.SendData(7);
		}
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(ModContent.ItemType<MatsuriLantern>()).AddCondition(Condition.NearWater).Register();
	}
}
