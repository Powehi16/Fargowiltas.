using System.Linq;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.GameContent.Events;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Abom;

public class PartyInvite : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.rare = 1;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
	}

	public override bool CanUseItem(Player player)
	{
		return Main.dayTime && !BirthdayParty.PartyIsUp && Main.npc.Count((NPC n) => n.active && n.townNPC && n.aiStyle != 0 && n.type != 37 && n.type != 453 && n.type != 441 && !NPCID.Sets.IsTownPet[n.type]) >= 5;
	}

	public override bool? UseItem(Player player)
	{
		if (!NPC.AnyNPCs(208))
		{
			NPC.SpawnOnPlayer(player.whoAmI, 208);
		}
		BirthdayParty.PartyDaysOnCooldown = 0;
		if (Main.netMode != 1)
		{
			for (int i = 0; i < 100; i++)
			{
				if (BirthdayParty.PartyIsUp)
				{
					break;
				}
				BirthdayParty.CheckMorning();
			}
		}
		if (Main.netMode == 2)
		{
			NetMessage.SendData(7);
		}
		return true;
	}
}
