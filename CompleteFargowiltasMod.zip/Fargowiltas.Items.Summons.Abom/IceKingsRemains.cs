using Terraria;

namespace Fargowiltas.Items.Summons.Abom;

public class IceKingsRemains : BaseSummon
{
	public override int NPCType => 345;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}
}
