namespace Fargowiltas.Items.Ammos;

public class StarPouch : BaseAmmo
{
	public override int AmmunitionItem => 75;
}
