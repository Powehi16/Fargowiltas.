namespace Fargowiltas.Items.Ammos;

public class GelPack : BaseAmmo
{
	public override int AmmunitionItem => 23;
}
