using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Ammos;

public class BrittleBone : ModItem
{
	public override string Texture => "Terraria/Images/Item_154";

	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 99;
	}

	public override void SetDefaults()
	{
		base.Item.CloneDefaults(154);
		base.Item.shoot = 0;
		base.Item.useAnimation = 0;
		base.Item.useTime = 0;
		base.Item.useStyle = 0;
	}
}
