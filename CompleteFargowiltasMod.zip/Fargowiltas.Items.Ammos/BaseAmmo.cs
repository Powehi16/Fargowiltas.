using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Ammos;

public abstract class BaseAmmo : ModItem
{
	public abstract int AmmunitionItem { get; }

	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.CloneDefaults(AmmunitionItem);
		base.Item.width = 26;
		base.Item.height = 26;
		base.Item.consumable = false;
		base.Item.maxStack = 1;
		base.Item.value *= 3996;
		base.Item.rare++;
	}

	public override void AddRecipes()
	{
		int amount = 1;
		CreateRecipe(amount).AddIngredient(AmmunitionItem, 3996).AddTile(125).Register();
	}
}
