using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.Chat;
using Terraria.DataStructures;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons;

public abstract class BaseSummon : ModItem
{
	public abstract int NPCType { get; }

	public virtual string NPCName { get; }

	public virtual bool ResetTimeWhenUsed => false;

	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.rare = 1;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
		base.Item.shoot = ModContent.ProjectileType<SpawnProj>();
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		if (ResetTimeWhenUsed)
		{
			Main.time = 0.0;
			if (Main.netMode == 2)
			{
				NetMessage.SendData(7);
			}
		}
		Vector2 pos = new Vector2((int)player.position.X + Main.rand.Next(-800, 800), (int)player.position.Y + Main.rand.Next(-800, -250));
		if (NPCType == 245)
		{
			pos = player.Center;
			for (int i = 0; i < 30; i++)
			{
				pos.Y -= 16f;
				if (pos.Y <= 0f || WorldGen.SolidTile((int)pos.X / 16, (int)pos.Y / 16))
				{
					pos.Y += 16f;
					break;
				}
			}
		}
		Projectile.NewProjectile(player.GetSource_ItemUse(source.Item), pos, Vector2.Zero, ModContent.ProjectileType<SpawnProj>(), 0, 0f, Main.myPlayer, NPCType);
		LocalizedText text = Language.GetText("Announcement.HasAwoken");
		string npcName = NPCName ?? ((ModContent.GetModNPC(NPCType) == null) ? Lang.GetNPCNameValue(NPCType) : ModContent.GetModNPC(NPCType).DisplayName.Value);
		if (Main.netMode == 2)
		{
			ChatHelper.BroadcastChatMessage(text.ToNetworkText(npcName), new Color(175, 75, 255));
		}
		else if (NPCType != 50)
		{
			Main.NewText(text.Format(npcName), new Color(175, 75, 255));
		}
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return false;
	}
}
