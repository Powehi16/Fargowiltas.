using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Vanity;

[AutoloadEquip(new EquipType[] { EquipType.HandsOff })]
public class AbominationnScythe : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 18;
		base.Item.height = 18;
		base.Item.vanity = true;
		base.Item.accessory = true;
		base.Item.rare = 1;
	}
}
