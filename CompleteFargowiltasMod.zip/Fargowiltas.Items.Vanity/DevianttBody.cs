using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Vanity;

[AutoloadEquip(new EquipType[] { EquipType.Body })]
public class DevianttBody : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 18;
		base.Item.height = 18;
		base.Item.vanity = true;
		base.Item.rare = 1;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(262).AddIngredient(3111).AddIngredient(3783)
			.AddTile(114)
			.Register();
	}
}
