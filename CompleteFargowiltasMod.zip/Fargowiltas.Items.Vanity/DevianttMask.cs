using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Vanity;

[AutoloadEquip(new EquipType[] { EquipType.Head })]
public class DevianttMask : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 18;
		base.Item.height = 18;
		base.Item.rare = 1;
		base.Item.vanity = true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(754).AddIngredient(3102).AddTile(114)
			.Register();
	}
}
