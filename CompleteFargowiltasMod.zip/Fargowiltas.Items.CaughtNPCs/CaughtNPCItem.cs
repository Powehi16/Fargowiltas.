using System.Collections.Generic;
using Fargowiltas.NPCs;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.CaughtNPCs;

public class CaughtNPCItem : ModItem
{
	internal static Dictionary<int, int> CaughtTownies = new Dictionary<int, int>();

	public string _name;

	public int AssociatedNpcId;

	public string NpcQuote;

	public override string Name => _name;

	protected override bool CloneNewInstances => true;

	public override bool IsCloneable => true;

	public override string Texture => (AssociatedNpcId < NPCID.Count) ? $"Terraria/Images/NPC_{AssociatedNpcId}" : NPCLoader.GetNPC(AssociatedNpcId).Texture;

	public CaughtNPCItem()
	{
		_name = base.Name;
		AssociatedNpcId = 0;
		NpcQuote = "";
	}

	public CaughtNPCItem(string internalName, int associatedNpcId, string npcQuote = "")
	{
		_name = internalName;
		AssociatedNpcId = associatedNpcId;
		NpcQuote = npcQuote;
	}

	public override bool IsLoadingEnabled(Mod mod)
	{
		return AssociatedNpcId != 0;
	}

	public override ModItem Clone(Item item)
	{
		CaughtNPCItem clone = base.Clone(item) as CaughtNPCItem;
		clone._name = _name;
		clone.AssociatedNpcId = AssociatedNpcId;
		clone.NpcQuote = NpcQuote;
		return clone;
	}

	public override void Unload()
	{
		CaughtTownies.Clear();
	}

	public override void SetStaticDefaults()
	{
		Main.RegisterItemAnimation(base.Type, new DrawAnimationVertical(6, Main.npcFrameCount[AssociatedNpcId]));
		ItemID.Sets.AnimatesAsSoul[base.Type] = true;
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 5;
	}

	public override void SetDefaults()
	{
		base.Item.DefaultToCapturedCritter(AssociatedNpcId);
		base.Item.rare = 1;
		base.Item.UseSound = SoundID.Item44;
		if (AssociatedNpcId == 369)
		{
			base.Item.bait = 15;
		}
	}

	public override void PostUpdate()
	{
		if (AssociatedNpcId == 22 && base.Item.lavaWet && !NPC.AnyNPCs(113))
		{
			NPC.SpawnWOF(base.Item.position);
			base.Item.TurnToAir();
		}
	}

	public override bool CanUseItem(Player player)
	{
		return player.Distance(Main.MouseWorld) < 64f && !Collision.SolidCollision(Main.MouseWorld - player.DefaultSize / 2f, (int)player.DefaultSize.X, (int)player.DefaultSize.Y) && NPC.CountNPCS(AssociatedNpcId) < 5;
	}

	public override bool? UseItem(Player player)
	{
		return true;
	}

	public static void RegisterItems()
	{
		CaughtTownies = new Dictionary<int, int>();
		Add("Abominationn", ModContent.NPCType<Abominationn>(), "'I sure wish I was a boss.'");
		Add("Angler", 369, "'You'd be a great helper minion!'");
		Add("ArmsDealer", 19, "'Keep your hands off my gun, buddy!'");
		Add("Clothier", 54, "'Thanks again for freeing me from my curse.'");
		Add("Cyborg", 209, "'My expedition efficiency was critically reduced when a projectile impacted my locomotive actuator.'");
		Add("Demolitionist", 38, "'It's a good day to die!'");
		Add("Deviantt", ModContent.NPCType<Deviantt>(), "'Embrace suffering... and while you're at it, embrace another purchase!'");
		Add("Dryad", 20, "'Be safe; Terraria needs you!'");
		Add("DyeTrader", 207, "'My dear, what you're wearing is much too drab.'");
		Add("GoblinTinkerer", 107, "'Looking for a gadgets expert? I'm your goblin!'");
		Add("Golfer", 588, "'An early bird catches the worm, but an early hole catches the birdie.'");
		Add("Guide", 22, "'They say there is a person who will tell you how to survive in this land.'");
		Add("LumberJack", ModContent.NPCType<LumberJack>(), "'I eat a bowl of woodchips for breakfast... without any milk.'");
		Add("Mechanic", 124, "'Always buy more wire than you need!'");
		Add("Merchant", 17, "'Did you say gold? I'll take that off of ya.'");
		Add("Mutant", ModContent.NPCType<Mutant>(), "'You're lucky I'm on your side.'");
		Add("Nurse", 18, "'Show me where it hurts.'");
		Add("Painter", 227, "'I know the difference between turquoise and blue-green. But I won't tell you.'");
		Add("PartyGirl", 208, "'We have to talk. It's... it's about parties.'");
		Add("Pirate", 229, "'Stay off me booty, ya scallywag!'");
		Add("SantaClaus", 142, "'What? You thought I wasn't real?'");
		Add("SkeletonMerchant", 453, "'You would not believe some of the things people throw at me... Wanna buy some of it?'");
		Add("Squirrel", ModContent.NPCType<Squirrel>(), "*squeak*");
		Add("Steampunker", 178, "'Show me some gears!'");
		Add("Stylist", 353, "'Did you even try to brush your hair today?'");
		Add("Tavernkeep", 550, "'What am I doing here...'");
		Add("TaxCollector", 441, "'You again? Suppose you want more money!?'");
		Add("TravellingMerchant", 368, "'I sell wares from places that might not even exist!'");
		Add("Truffle", 160, "'Everyone in this town feels a bit off.'");
		Add("WitchDoctor", 228, "'Which doctor am I? The Witch Doctor am I.'");
		Add("Wizard", 108, "'Want me to pull a coin from behind your ear? No? Ok.'");
		Add("Zoologist", 633, "'I love animals, like, a lot!'");
		Add("Princess", 663, "'Pink is the best color anyone could ask for!'");
		Add("TownDog", 638, "'Woof!'");
		Add("TownCat", 637, "'Meow!'");
		Add("TownBunny", 656, "'*Bunny noises*'");
	}

	public static void Add(string internalName, int id, string quote)
	{
		CaughtNPCItem item = new CaughtNPCItem(internalName, id, quote);
		Fargowiltas.Instance.AddContent(item);
		CaughtTownies.Add(id, item.Type);
	}
}
