using System.Collections.Generic;
using System.Linq;
using Fargowiltas.Common.Configs;
using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Items.CaughtNPCs;

public class CaughtGlobalNPC : GlobalNPC
{
	private static HashSet<int> npcCatchableWasFalse;

	public override void Load()
	{
		npcCatchableWasFalse = new HashSet<int>();
	}

	public override void Unload()
	{
		if (npcCatchableWasFalse == null)
		{
			return;
		}
		foreach (int type in npcCatchableWasFalse)
		{
			Main.npcCatchable[type] = false;
		}
		npcCatchableWasFalse = null;
	}

	public override void SetDefaults(NPC npc)
	{
		int type = npc.type;
		if (CaughtNPCItem.CaughtTownies.ContainsKey(type) && FargoServerConfig.Instance.CatchNPCs)
		{
			npc.catchItem = (short)CaughtNPCItem.CaughtTownies.FirstOrDefault((KeyValuePair<int, int> x) => x.Key.Equals(type)).Value;
			if (!Main.npcCatchable[type])
			{
				npcCatchableWasFalse.Add(type);
				Main.npcCatchable[type] = true;
			}
		}
	}
}
