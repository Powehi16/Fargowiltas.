namespace Fargowiltas.Items.Ammos.Bullets;

public class CrystalPouch : BaseAmmo
{
	public override int AmmunitionItem => 515;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
