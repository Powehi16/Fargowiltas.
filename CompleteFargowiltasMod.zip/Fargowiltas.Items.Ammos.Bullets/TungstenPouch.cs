namespace Fargowiltas.Items.Ammos.Bullets;

public class TungstenPouch : BaseAmmo
{
	public override int AmmunitionItem => 4915;
}
