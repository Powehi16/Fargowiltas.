namespace Fargowiltas.Items.Ammos.Bullets;

public class VelocityPouch : BaseAmmo
{
	public override int AmmunitionItem => 1302;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void SetDefaults()
	{
		base.SetDefaults();
		base.Item.shootSpeed = 28f;
	}
}
