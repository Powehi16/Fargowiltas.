namespace Fargowiltas.Items.Ammos.Bullets;

public class VenomPouch : BaseAmmo
{
	public override int AmmunitionItem => 1342;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
