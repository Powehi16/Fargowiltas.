namespace Fargowiltas.Items.Ammos.Bullets;

public class LuminitePouch : BaseAmmo
{
	public override int AmmunitionItem => 3567;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
