namespace Fargowiltas.Items.Ammos.Bullets;

public class GoldenPouch : BaseAmmo
{
	public override int AmmunitionItem => 1352;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
