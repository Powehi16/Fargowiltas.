namespace Fargowiltas.Items.Ammos.Bullets;

public class PartyPouch : BaseAmmo
{
	public override int AmmunitionItem => 1349;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
