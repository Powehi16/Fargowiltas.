namespace Fargowiltas.Items.Ammos.Bullets;

public class CursedPouch : BaseAmmo
{
	public override int AmmunitionItem => 546;
}
