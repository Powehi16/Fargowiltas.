namespace Fargowiltas.Items.Ammos.Bullets;

public class MeteorPouch : BaseAmmo
{
	public override int AmmunitionItem => 234;
}
