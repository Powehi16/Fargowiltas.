namespace Fargowiltas.Items.Ammos.Bullets;

public class ExplosivePouch : BaseAmmo
{
	public override int AmmunitionItem => 1351;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
