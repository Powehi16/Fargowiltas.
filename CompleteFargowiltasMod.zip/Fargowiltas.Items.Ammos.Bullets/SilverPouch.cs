namespace Fargowiltas.Items.Ammos.Bullets;

public class SilverPouch : BaseAmmo
{
	public override int AmmunitionItem => 278;
}
