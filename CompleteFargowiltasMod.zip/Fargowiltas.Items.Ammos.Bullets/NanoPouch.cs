namespace Fargowiltas.Items.Ammos.Bullets;

public class NanoPouch : BaseAmmo
{
	public override int AmmunitionItem => 1350;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
