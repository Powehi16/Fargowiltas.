namespace Fargowiltas.Items.Ammos.Bullets;

public class ChlorophytePouch : BaseAmmo
{
	public override int AmmunitionItem => 1179;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
