namespace Fargowiltas.Items.Ammos.Bullets;

public class IchorPouch : BaseAmmo
{
	public override int AmmunitionItem => 1335;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
