namespace Fargowiltas.Items.Ammos.Coins;

internal abstract class CoinBag : BaseAmmo
{
	public override void SetDefaults()
	{
		base.SetDefaults();
		base.Item.notAmmo = false;
		base.Item.useStyle = 0;
		base.Item.useTime = 0;
		base.Item.useAnimation = 0;
		base.Item.createTile = -1;
		base.Item.shoot = 0;
	}
}
