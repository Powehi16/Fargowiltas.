namespace Fargowiltas.Items.Ammos.Coins;

internal class GoldCoinBag : CoinBag
{
	public override int AmmunitionItem => 73;
}
