namespace Fargowiltas.Items.Ammos.Coins;

internal class SilverCoinBag : CoinBag
{
	public override int AmmunitionItem => 72;
}
