namespace Fargowiltas.Items.Ammos.Coins;

internal class CopperCoinBag : CoinBag
{
	public override int AmmunitionItem => 71;
}
