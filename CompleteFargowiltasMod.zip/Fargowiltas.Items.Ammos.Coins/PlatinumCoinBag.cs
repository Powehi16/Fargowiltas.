namespace Fargowiltas.Items.Ammos.Coins;

internal class PlatinumCoinBag : CoinBag
{
	public override int AmmunitionItem => 74;
}
