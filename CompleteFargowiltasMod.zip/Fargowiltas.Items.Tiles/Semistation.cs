using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public class Semistation : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.useTurn = true;
		base.Item.autoReuse = true;
		base.Item.useAnimation = 15;
		base.Item.useTime = 10;
		base.Item.useStyle = 1;
		base.Item.rare = 1;
		base.Item.value = Item.buyPrice(0, 1);
		base.Item.createTile = ModContent.TileType<SemistationSheet>();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(63, 5).AddIngredient(966, 5).AddIngredient(1859, 5)
			.AddIngredient(1431, 5)
			.AddTile(16)
			.Register();
	}
}
