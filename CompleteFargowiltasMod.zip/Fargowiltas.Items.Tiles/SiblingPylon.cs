using Terraria;
using Terraria.Enums;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public class SiblingPylon : ModItem
{
	public override void SetDefaults()
	{
		base.Item.DefaultToPlaceableTile(ModContent.TileType<SiblingPylonTile>());
		base.Item.SetShopValues(ItemRarityColor.Blue1, Item.buyPrice(0, 10));
	}
}
