using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public class Omnistation2 : BaseOmnistation
{
	public Omnistation2()
		: base(1198)
	{
	}

	public override void SetDefaults()
	{
		base.SetDefaults();
		base.Item.createTile = ModContent.TileType<OmnistationSheet2>();
	}
}
