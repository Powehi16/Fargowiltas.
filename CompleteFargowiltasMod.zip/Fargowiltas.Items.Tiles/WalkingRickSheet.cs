using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace Fargowiltas.Items.Tiles;

public class WalkingRickSheet : ModTile
{
	public override void SetStaticDefaults()
	{
		Main.tileFrameImportant[base.Type] = true;
		Main.tileLavaDeath[base.Type] = true;
		Main.tileSpelunker[base.Type] = true;
		TileObjectData.newTile.CopyFrom(TileObjectData.Style3x3Wall);
		TileObjectData.newTile.StyleHorizontal = true;
		TileObjectData.newTile.StyleWrapLimit = 36;
		TileObjectData.addTile(base.Type);
		base.DustType = 7;
		TileID.Sets.DisableSmartCursor[base.Type] = true;
	}

	public override void KillMultiTile(int i, int j, int frameX, int frameY)
	{
	}
}
