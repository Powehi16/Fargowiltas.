using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public class MutantToilet : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.DefaultToPlaceableTile(ModContent.TileType<MutantToiletSheet>());
		base.Item.maxStack = 99;
		base.Item.width = 16;
		base.Item.height = 24;
		base.Item.value = Item.sellPrice(1, 50);
		base.Item.rare = 11;
	}

	public override void AddRecipes()
	{
		if (ModContent.TryFind<ModItem>("Fargowiltas/Mutant", out var modItem))
		{
			CreateRecipe().AddIngredient(3467, 6).AddIngredient(modItem.Type).AddTile(ModContent.TileType<CrucibleCosmosSheet>())
				.Register();
		}
	}
}
