using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public abstract class BaseOmnistation : ModItem
{
	protected int bar;

	public BaseOmnistation(int bar)
	{
		this.bar = bar;
	}

	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.useTurn = true;
		base.Item.autoReuse = true;
		base.Item.useAnimation = 15;
		base.Item.useTime = 10;
		base.Item.useStyle = 1;
		base.Item.rare = 1;
		base.Item.value = Item.buyPrice(0, 50);
		base.Item.createTile = ModContent.TileType<OmnistationSheet>();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(ModContent.ItemType<Semistation>()).AddIngredient(1128, 5).AddIngredient(3750, 3)
			.AddIngredient(4609, 3)
			.AddIngredient(4276, 3)
			.AddIngredient(4362, 3)
			.AddIngredient(bar, 10)
			.AddTile(134)
			.Register();
	}
}
