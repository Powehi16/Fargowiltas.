namespace Fargowiltas.Items.Tiles;

public class UnsafePinkBrickWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{140}";

	public UnsafePinkBrickWall()
		: base("Unsafe Pink Brick Wall", 9)
	{
	}
}
