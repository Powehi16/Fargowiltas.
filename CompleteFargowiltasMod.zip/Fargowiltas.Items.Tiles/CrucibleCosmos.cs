using System.Collections.Generic;
using Fargowiltas.Common.Systems.Recipes;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public class CrucibleCosmos : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void ModifyTooltips(List<TooltipLine> list)
	{
		foreach (TooltipLine tooltipLine in list)
		{
			if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
			{
				tooltipLine.OverrideColor = new Color(Main.DiscoR, Main.DiscoG, Main.DiscoB);
			}
		}
	}

	public override void SetDefaults()
	{
		base.Item.width = 28;
		base.Item.height = 14;
		base.Item.rare = 10;
		base.Item.maxStack = 99;
		base.Item.useTurn = true;
		base.Item.autoReuse = true;
		base.Item.useAnimation = 15;
		base.Item.useTime = 10;
		base.Item.useStyle = 1;
		base.Item.consumable = true;
		base.Item.value = Item.buyPrice(2);
		base.Item.createTile = ModContent.TileType<CrucibleCosmosSheet>();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(ModContent.ItemType<MultitaskCenter>()).AddIngredient(ModContent.ItemType<ElementalAssembler>()).AddIngredient(ModContent.ItemType<GoldenDippingVat>())
			.AddRecipeGroup(RecipeGroups.AnyForge)
			.AddRecipeGroup(RecipeGroups.AnyHMAnvil)
			.AddRecipeGroup(RecipeGroups.AnyBookcase)
			.AddIngredient(487)
			.AddIngredient(1551)
			.AddIngredient(995)
			.AddIngredient(996)
			.AddIngredient(2203)
			.AddIngredient(4142)
			.AddIngredient(2193)
			.AddIngredient(2195)
			.AddIngredient(3549)
			.AddIngredient(3467, 25)
			.AddTile(26)
			.Register();
		if (ModLoader.TryGetMod("MagicStorage", out var magicStorage))
		{
			CreateRecipe().AddIngredient(magicStorage.Find<ModItem>("CombinedStations4Item").Type).AddIngredient(3467, 25).AddTile(26)
				.Register();
		}
	}
}
