using Fargowiltas.Common.Systems.Recipes;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public class GoldenDippingVat : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 99;
		base.Item.useTurn = true;
		base.Item.autoReuse = true;
		base.Item.rare = 8;
		base.Item.value = Item.sellPrice(0, 10);
		base.Item.useAnimation = 15;
		base.Item.useTime = 15;
		base.Item.useStyle = 1;
		base.Item.consumable = true;
		base.Item.createTile = ModContent.TileType<GoldenDippingVatSheet>();
	}

	public override void AddRecipes()
	{
		AddCritter(2015, 2889);
		AddCritter(2019, 2890);
		AddCritter(2121, 2892);
		AddCritter(261, 4274);
		AddCritter(2740, 2893);
		AddCritter(4361, 4362);
		AddCritter(2003, 2894);
		AddCritter(4480, 4482);
		AddCritter(4418, 4419);
		AddCritter(2002, 2895);
		AddCritterFromGroup(RecipeGroups.AnySquirrel, 3564);
		AddCritterFromGroup(RecipeGroups.AnyButterfly, 2891);
		AddCritterFromGroup(RecipeGroups.AnyCommonFish, 2308);
		AddCritterFromGroup(RecipeGroups.AnyDragonfly, 4340);
	}

	private static void AddCritter(int critterID, int goldCritterID)
	{
		Recipe.Create(goldCritterID).AddIngredient(critterID).AddIngredient(1348, 100)
			.AddTile(ModContent.TileType<GoldenDippingVatSheet>())
			.Register();
	}

	private static void AddCritterFromGroup(int critterGroup, int goldCritterID)
	{
		Recipe.Create(goldCritterID).AddRecipeGroup(critterGroup).AddIngredient(1348, 100)
			.AddTile(ModContent.TileType<GoldenDippingVatSheet>())
			.Register();
	}
}
