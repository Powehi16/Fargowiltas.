using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace Fargowiltas.Items.Tiles;

public class MultitaskCenterSheet : ModTile
{
	public override void SetStaticDefaults()
	{
		Main.tileLighted[base.Type] = true;
		Main.tileSolidTop[base.Type] = true;
		Main.tileTable[base.Type] = true;
		Main.tileFrameImportant[base.Type] = true;
		TileObjectData.newTile.CopyFrom(TileObjectData.Style3x3);
		TileObjectData.newTile.Width = 4;
		Main.tileNoAttach[base.Type] = false;
		TileObjectData.newTile.CoordinateHeights = new int[3] { 16, 16, 16 };
		TileObjectData.addTile(base.Type);
		LocalizedText name = CreateMapEntryName();
		AddMapEntry(new Color(200, 200, 200), name);
		TileID.Sets.DisableSmartCursor[base.Type] = true;
		base.AdjTiles = new int[12]
		{
			18, 283, 17, 16, 13, 106, 86, 14, 15, 96,
			172, 94
		};
		TileID.Sets.CountsAsWaterSource[base.Type] = true;
		base.AnimationFrameHeight = 54;
	}

	public override void ModifyLight(int i, int j, ref float r, ref float g, ref float b)
	{
		r = 0.93f;
		g = 0.11f;
		b = 0.12f;
	}

	public override void NumDust(int i, int j, bool fail, ref int num)
	{
		num = (fail ? 1 : 3);
	}

	public override void AnimateTile(ref int frame, ref int frameCounter)
	{
		frameCounter++;
		if (frameCounter >= 10)
		{
			frameCounter = 0;
			frame++;
			frame %= 7;
		}
	}
}
