using System.Linq;
using Fargowiltas.NPCs;
using Fargowiltas.TileEntities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.GameContent;
using Terraria.GameContent.ObjectInteractions;
using Terraria.ID;
using Terraria.Localization;
using Terraria.Map;
using Terraria.ModLoader;
using Terraria.ModLoader.Default;
using Terraria.ObjectData;

namespace Fargowiltas.Items.Tiles;

public class SiblingPylonTile : ModPylon
{
	public const int CrystalVerticalFrameCount = 8;

	public Asset<Texture2D> crystalTexture;

	public Asset<Texture2D> crystalHighlightTexture;

	public Asset<Texture2D> mapIcon;

	public override void Load()
	{
		crystalTexture = ModContent.Request<Texture2D>(Texture + "_Crystal");
		crystalHighlightTexture = ModContent.Request<Texture2D>(Texture + "_CrystalHighlight");
		mapIcon = ModContent.Request<Texture2D>(Texture + "_MapIcon");
	}

	public override void SetStaticDefaults()
	{
		Main.tileLighted[base.Type] = true;
		Main.tileFrameImportant[base.Type] = true;
		TileObjectData.newTile.CopyFrom(TileObjectData.Style3x4);
		TileObjectData.newTile.LavaDeath = false;
		TileObjectData.newTile.DrawYOffset = 2;
		TileObjectData.newTile.StyleHorizontal = true;
		TEModdedPylon moddedPylon = ModContent.GetInstance<SiblingPylonTileEntity>();
		TileObjectData.newTile.HookCheckIfCanPlace = new PlacementHook(moddedPylon.PlacementPreviewHook_CheckIfCanPlace, 1, 0, processedCoordinates: true);
		TileObjectData.newTile.HookPostPlaceMyPlayer = new PlacementHook(moddedPylon.Hook_AfterPlacement, -1, 0, processedCoordinates: false);
		TileObjectData.addTile(base.Type);
		TileID.Sets.InteractibleByNPCs[base.Type] = true;
		TileID.Sets.PreventsSandfall[base.Type] = true;
		AddToArray(ref TileID.Sets.CountsAsPylon);
		LocalizedText pylonName = CreateMapEntryName();
		AddMapEntry(Color.White, pylonName);
	}

	public override NPCShop.Entry GetNPCShopEntry()
	{
		return null;
	}

	public override bool HasSmartInteract(int i, int j, SmartInteractScanSettings settings)
	{
		return true;
	}

	public override bool RightClick(int i, int j)
	{
		Main.mapFullscreen = true;
		SoundEngine.PlaySound(in SoundID.MenuOpen);
		return true;
	}

	public override void MouseOver(int i, int j)
	{
		Main.LocalPlayer.cursorItemIconEnabled = true;
		Main.LocalPlayer.cursorItemIconID = ModContent.ItemType<SiblingPylon>();
	}

	public override void KillMultiTile(int i, int j, int frameX, int frameY)
	{
		ModContent.GetInstance<SiblingPylonTileEntity>().Kill(i, j);
	}

	private bool NearNPC(Vector2 tilePos, int npcType)
	{
		return Main.npc.Any((NPC n) => n.active && n.type == npcType && n.Distance(tilePos) < 1000f);
	}

	private bool NearEnoughSiblings(Vector2 tilePos)
	{
		int siblingsNearby = 0;
		if (NearNPC(tilePos, ModContent.NPCType<Mutant>()))
		{
			siblingsNearby++;
		}
		if (NearNPC(tilePos, ModContent.NPCType<Abominationn>()))
		{
			siblingsNearby++;
		}
		if (NearNPC(tilePos, ModContent.NPCType<Deviantt>()))
		{
			siblingsNearby++;
		}
		return siblingsNearby >= 2;
	}

	public override void ValidTeleportCheck_DestinationPostCheck(TeleportPylonInfo destinationPylonInfo, ref bool destinationPylonValid, ref string errorKey)
	{
		Vector2 tilePos = destinationPylonInfo.PositionInTiles.ToWorldCoordinates();
		if (!NearEnoughSiblings(tilePos))
		{
			destinationPylonValid = false;
			errorKey = "Mods.Fargowiltas.MessageInfo.SiblingPylonNotNearSiblings";
		}
	}

	public override void ValidTeleportCheck_NearbyPostCheck(TeleportPylonInfo nearbyPylonInfo, ref bool destinationPylonValid, ref bool anyNearbyValidPylon, ref string errorKey)
	{
		Vector2 tilePos = nearbyPylonInfo.PositionInTiles.ToWorldCoordinates();
		if (!NearEnoughSiblings(tilePos))
		{
			destinationPylonValid = false;
			errorKey = "Mods.Fargowiltas.MessageInfo.NearbySiblingPylonNotNearSiblings";
		}
	}

	public override void ModifyLight(int i, int j, ref float r, ref float g, ref float b)
	{
		r = 0.15f;
		g = 0.75f;
		b = 0.5617647f;
	}

	public override bool AutoSelect(int i, int j, Item item)
	{
		return base.AutoSelect(i, j, item);
	}

	public override void SpecialDraw(int i, int j, SpriteBatch spriteBatch)
	{
		DefaultDrawPylonCrystal(spriteBatch, i, j, crystalTexture, crystalHighlightTexture, Vector2.UnitX * -1f + Vector2.UnitY * -12f, Color.White * 0.1f, Color.White, 4, 8);
	}

	public override void DrawMapIcon(ref MapOverlayDrawContext context, ref string mouseOverText, TeleportPylonInfo pylonInfo, bool isNearPylon, Color drawColor, float deselectedScale, float selectedScale)
	{
		bool mouseOver = DefaultDrawMapIcon(ref context, mapIcon, pylonInfo.PositionInTiles.ToVector2() + new Vector2(1.5f, 2f), drawColor, deselectedScale, selectedScale);
		DefaultMapClickHandle(mouseOver, pylonInfo, "Mods.Fargowiltas.Items.SiblingPylon.DisplayName", ref mouseOverText);
	}
}
