using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace Fargowiltas.Items.Tiles;

public class CrucibleCosmosSheet : ModTile
{
	public override void SetStaticDefaults()
	{
		Main.tileFrameImportant[base.Type] = true;
		TileObjectData.newTile.CopyFrom(TileObjectData.Style3x3);
		TileObjectData.newTile.Width = 4;
		Main.tileNoAttach[base.Type] = true;
		TileObjectData.newTile.CoordinateHeights = new int[3] { 16, 16, 16 };
		TileObjectData.addTile(base.Type);
		LocalizedText name = CreateMapEntryName();
		AddMapEntry(new Color(200, 200, 200), name);
		TileID.Sets.DisableSmartCursor[base.Type] = true;
		int[] obj = new int[39]
		{
			18, 283, 17, 16, 13, 106, 86, 14, 15, 96,
			172, 94, 77, 355, 114, 243, 228, 304, 302, 306,
			308, 305, 220, 300, 134, 133, 26, 101, 125, 247,
			412, 499, 301, 303, 307, 217, 218, 85, 0
		};
		obj[38] = ModContent.TileType<GoldenDippingVatSheet>();
		base.AdjTiles = obj;
		TileID.Sets.CountsAsHoneySource[base.Type] = true;
		TileID.Sets.CountsAsLavaSource[base.Type] = true;
		TileID.Sets.CountsAsWaterSource[base.Type] = true;
		base.AnimationFrameHeight = 54;
	}

	public override void NumDust(int i, int j, bool fail, ref int num)
	{
		num = (fail ? 1 : 3);
	}

	public override void AnimateTile(ref int frame, ref int frameCounter)
	{
		frameCounter++;
		if (frameCounter >= 5)
		{
			frameCounter = 0;
			frame++;
			frame %= 8;
		}
	}

	public override void NearbyEffects(int i, int j, bool closer)
	{
		if (Main.LocalPlayer.Distance(new Vector2(i * 16 + 8, j * 16 + 8)) < 80f)
		{
			Main.LocalPlayer.GetModPlayer<FargoPlayer>().ElementalAssemblerNearby = 6f;
		}
	}
}
