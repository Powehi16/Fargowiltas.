namespace Fargowiltas.Items.Tiles;

public class UnsafeLihzahrdBrickWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{1102}";

	public UnsafeLihzahrdBrickWall()
		: base("Unsafe Lihzahrd Brick Wall", 87, 1102, 1101)
	{
	}
}
