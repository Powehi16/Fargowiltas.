using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace Fargowiltas.Items.Tiles;

public class CrimsonAltarSheet : ModTile
{
	public override void SetStaticDefaults()
	{
		Main.tileLighted[base.Type] = true;
		Main.tileFrameImportant[base.Type] = true;
		TileObjectData.newTile.CopyFrom(TileObjectData.Style3x2);
		Main.tileNoAttach[base.Type] = true;
		TileObjectData.newTile.CoordinateHeights = new int[2] { 16, 16 };
		TileObjectData.addTile(base.Type);
		LocalizedText name = CreateMapEntryName();
		AddMapEntry(new Color(200, 200, 200), name);
		TileID.Sets.DisableSmartCursor[base.Type] = true;
		base.AdjTiles = new int[1] { 26 };
	}

	public override void NumDust(int i, int j, bool fail, ref int num)
	{
		num = (fail ? 1 : 3);
	}
}
