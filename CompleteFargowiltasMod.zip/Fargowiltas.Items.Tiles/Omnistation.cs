namespace Fargowiltas.Items.Tiles;

public class Omnistation : BaseOmnistation
{
	public Omnistation()
		: base(391)
	{
	}
}
