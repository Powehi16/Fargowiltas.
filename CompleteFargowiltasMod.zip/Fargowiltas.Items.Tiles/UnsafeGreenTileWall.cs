namespace Fargowiltas.Items.Tiles;

public class UnsafeGreenTileWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{1383}";

	public UnsafeGreenTileWall()
		: base("Unsafe Green Tile Wall", 99)
	{
	}
}
