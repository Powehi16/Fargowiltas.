namespace Fargowiltas.Items.Tiles;

public class UnsafeMarbleWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{3082}";

	public UnsafeMarbleWall()
		: base("Unsafe Marble Wall", 178, 3082, 3081)
	{
	}
}
