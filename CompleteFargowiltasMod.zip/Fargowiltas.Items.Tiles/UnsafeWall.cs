using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public abstract class UnsafeWall : ModItem
{
	private readonly string name;

	private readonly int createWall;

	private readonly int wall;

	private readonly int tile;

	protected UnsafeWall(string name, int createWall, int wall = -1, int tile = -1)
	{
		this.name = name;
		this.createWall = createWall;
		this.wall = wall;
		this.tile = tile;
	}

	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 400;
	}

	public override void SetDefaults()
	{
		base.Item.width = 28;
		base.Item.height = 14;
		base.Item.rare = 0;
		base.Item.maxStack = 999;
		base.Item.useTurn = true;
		base.Item.autoReuse = true;
		base.Item.useAnimation = 15;
		base.Item.useTime = 15;
		base.Item.useStyle = 1;
		base.Item.consumable = true;
		base.Item.createWall = createWall;
	}

	public override void AddRecipes()
	{
		if (wall != -1)
		{
			Recipe.Create(base.Type).AddIngredient(wall).AddTile(18)
				.Register();
		}
		if (tile != -1)
		{
			Recipe.Create(base.Type, 4).AddIngredient(tile).AddTile(18)
				.Register();
		}
	}
}
