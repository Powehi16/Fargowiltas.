namespace Fargowiltas.Items.Tiles;

public class UnsafeBlueBrickWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{135}";

	public UnsafeBlueBrickWall()
		: base("Unsafe Blue Brick Wall", 7)
	{
	}
}
