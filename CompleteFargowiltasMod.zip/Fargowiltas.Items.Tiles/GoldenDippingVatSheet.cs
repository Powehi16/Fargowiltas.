using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace Fargowiltas.Items.Tiles;

public class GoldenDippingVatSheet : ModTile
{
	public override void SetStaticDefaults()
	{
		Main.tileFrameImportant[base.Type] = true;
		Main.tileObsidianKill[base.Type] = true;
		Main.tileNoAttach[base.Type] = true;
		TileObjectData.newTile.CopyFrom(TileObjectData.Style3x3);
		TileObjectData.newTile.LavaDeath = true;
		TileObjectData.addTile(base.Type);
		LocalizedText name = CreateMapEntryName();
		AddMapEntry(new Color(255, 215, 0), name);
		base.AnimationFrameHeight = 54;
	}

	public override void AnimateTile(ref int frame, ref int frameCounter)
	{
		frameCounter++;
		if (frameCounter >= 10)
		{
			frameCounter = 0;
			frame++;
			frame %= 12;
		}
	}
}
