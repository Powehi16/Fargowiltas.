namespace Fargowiltas.Items.Tiles;

public class UnsafeGraniteWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{3088}";

	public UnsafeGraniteWall()
		: base("Unsafe Granite Wall", 180, 3088, 3086)
	{
	}
}
