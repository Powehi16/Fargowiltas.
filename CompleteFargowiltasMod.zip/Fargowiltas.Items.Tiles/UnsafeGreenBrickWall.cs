namespace Fargowiltas.Items.Tiles;

public class UnsafeGreenBrickWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{138}";

	public UnsafeGreenBrickWall()
		: base("Unsafe Green Brick Wall", 8)
	{
	}
}
