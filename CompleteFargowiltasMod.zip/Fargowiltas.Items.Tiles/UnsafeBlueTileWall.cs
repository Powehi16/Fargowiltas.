namespace Fargowiltas.Items.Tiles;

public class UnsafeBlueTileWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{1379}";

	public UnsafeBlueTileWall()
		: base("Unsafe Blue Tile Wall", 95)
	{
	}
}
