using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace Fargowiltas.Items.Tiles;

public class ElementalAssemblerSheet : ModTile
{
	public override void SetStaticDefaults()
	{
		Main.tileLighted[base.Type] = true;
		Main.tileFrameImportant[base.Type] = true;
		TileObjectData.newTile.CopyFrom(TileObjectData.Style3x3);
		TileObjectData.newTile.Width = 4;
		Main.tileNoAttach[base.Type] = true;
		TileObjectData.newTile.CoordinateHeights = new int[3] { 16, 16, 16 };
		TileObjectData.addTile(base.Type);
		LocalizedText name = CreateMapEntryName();
		AddMapEntry(new Color(200, 200, 200), name);
		TileID.Sets.DisableSmartCursor[base.Type] = true;
		base.AdjTiles = new int[17]
		{
			77, 17, 355, 114, 243, 228, 304, 302, 306, 308,
			305, 220, 300, 13, 26, 85, 622
		};
		TileID.Sets.CountsAsHoneySource[base.Type] = true;
		TileID.Sets.CountsAsLavaSource[base.Type] = true;
		base.AnimationFrameHeight = 54;
	}

	public override void ModifyLight(int i, int j, ref float r, ref float g, ref float b)
	{
		float strength = Main.rand.NextFloat(0.9f, 1f);
		r = (g = (b = strength));
	}

	public override void NumDust(int i, int j, bool fail, ref int num)
	{
		num = (fail ? 1 : 3);
	}

	public override void AnimateTile(ref int frame, ref int frameCounter)
	{
		frameCounter++;
		if (frameCounter >= 8)
		{
			frameCounter = 0;
			frame++;
			frame %= 8;
		}
		Main.tileLighted[base.Type] = true;
	}

	public override void NearbyEffects(int i, int j, bool closer)
	{
		if (Main.LocalPlayer.Distance(new Vector2(i * 16 + 8, j * 16 + 8)) < 80f)
		{
			Main.LocalPlayer.GetModPlayer<FargoPlayer>().ElementalAssemblerNearby = 6f;
		}
	}
}
