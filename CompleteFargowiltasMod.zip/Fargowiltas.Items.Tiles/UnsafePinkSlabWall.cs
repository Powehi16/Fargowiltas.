namespace Fargowiltas.Items.Tiles;

public class UnsafePinkSlabWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{140}";

	public UnsafePinkSlabWall()
		: base("Unsafe Pink Slab Wall", 96)
	{
	}
}
