namespace Fargowiltas.Items.Tiles;

public class UnsafeGreenSlabWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{138}";

	public UnsafeGreenSlabWall()
		: base("Unsafe Green Slab Wall", 98)
	{
	}
}
