using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.Enums;
using Terraria.GameContent.ObjectInteractions;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace Fargowiltas.Items.Tiles;

public class MutantToiletSheet : ModTile
{
	public const int NextStyleHeight = 40;

	public override void SetStaticDefaults()
	{
		Main.tileFrameImportant[base.Type] = true;
		Main.tileNoAttach[base.Type] = true;
		Main.tileLavaDeath[base.Type] = true;
		TileID.Sets.HasOutlines[base.Type] = true;
		TileID.Sets.CanBeSatOnForNPCs[base.Type] = true;
		TileID.Sets.CanBeSatOnForPlayers[base.Type] = true;
		TileID.Sets.DisableSmartCursor[base.Type] = true;
		AddToArray(ref TileID.Sets.RoomNeeds.CountsAsChair);
		base.DustType = 265;
		base.AdjTiles = new int[2] { 15, 497 };
		AddMapEntry(new Color(200, 200, 200), Language.GetText("MapObject.Toilet"));
		TileObjectData.newTile.CopyFrom(TileObjectData.Style1x2);
		TileObjectData.newTile.CoordinateHeights = new int[2] { 16, 18 };
		TileObjectData.newTile.CoordinatePaddingFix = new Point16(0, 2);
		TileObjectData.newTile.Direction = TileObjectDirection.PlaceLeft;
		TileObjectData.newTile.StyleWrapLimit = 2;
		TileObjectData.newTile.StyleMultiplier = 2;
		TileObjectData.newTile.StyleHorizontal = true;
		TileObjectData.newAlternate.CopyFrom(TileObjectData.newTile);
		TileObjectData.newAlternate.Direction = TileObjectDirection.PlaceRight;
		TileObjectData.addAlternate(1);
		TileObjectData.addTile(base.Type);
	}

	public override void NumDust(int i, int j, bool fail, ref int num)
	{
		num = (fail ? 1 : 3);
	}

	public override bool HasSmartInteract(int i, int j, SmartInteractScanSettings settings)
	{
		return settings.player.IsWithinSnappngRangeToTile(i, j, 40);
	}

	public override void ModifySittingTargetInfo(int i, int j, ref TileRestingInfo info)
	{
		Tile tile = Framing.GetTileSafely(i, j);
		info.TargetDirection = -1;
		if (tile.TileFrameX != 0)
		{
			info.TargetDirection = 1;
		}
		info.AnchorTilePosition.X = i;
		info.AnchorTilePosition.Y = j;
		if (tile.TileFrameY % 40 == 0)
		{
			info.AnchorTilePosition.Y++;
		}
		if (info.RestingEntity is Player player && Fargowiltas.ModLoaded["FargowiltasSouls"] && ModContent.TryFind<ModBuff>("FargowiltasSouls/MutantPresenceBuff", out var modBuff))
		{
			player.AddBuff(modBuff.Type, 2);
		}
	}

	public override bool RightClick(int i, int j)
	{
		Player player = Main.LocalPlayer;
		if (player.IsWithinSnappngRangeToTile(i, j, 40))
		{
			player.GamepadEnableGrappleCooldown();
			player.sitting.SitDown(player, i, j);
		}
		return true;
	}

	public override void MouseOver(int i, int j)
	{
		Player player = Main.LocalPlayer;
		if (player.IsWithinSnappngRangeToTile(i, j, 40))
		{
			player.noThrow = 2;
			player.cursorItemIconEnabled = true;
			player.cursorItemIconID = ModContent.ItemType<MutantToilet>();
			if (Main.tile[i, j].TileFrameX / 18 < 1)
			{
				player.cursorItemIconReversed = true;
			}
		}
	}

	public override void HitWire(int i, int j)
	{
		Tile tile = Main.tile[i, j];
		int spawnY = j - tile.TileFrameY % 40 / 18;
		Wiring.SkipWire(i, spawnY);
		Wiring.SkipWire(i, spawnY + 1);
		if (Wiring.CheckMech(i, spawnY, 60))
		{
			Projectile.NewProjectile(Wiring.GetProjectileSource(i, spawnY), i * 16 + 8, spawnY * 16 + 12, 0f, 0f, 733, 0, 0f, Main.myPlayer);
		}
		if (Main.rand.NextBool(10) && Fargowiltas.ModLoaded["FargowiltasSouls"] && ModContent.TryFind<ModNPC>("FargowiltasSouls/MutantBoss", out var modNPC) && Main.netMode != 1)
		{
			int p = Player.FindClosest(new Vector2(i * 16 + 8, spawnY * 16 + 12), 0, 0);
			if (p != -1 && !NPC.AnyNPCs(modNPC.Type))
			{
				NPC.SpawnOnPlayer(p, modNPC.Type);
			}
		}
	}
}
