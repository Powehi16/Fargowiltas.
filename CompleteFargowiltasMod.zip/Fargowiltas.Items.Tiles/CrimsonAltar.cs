using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public class CrimsonAltar : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 28;
		base.Item.height = 14;
		base.Item.rare = 2;
		base.Item.maxStack = 99;
		base.Item.useTurn = true;
		base.Item.autoReuse = true;
		base.Item.useAnimation = 15;
		base.Item.useTime = 10;
		base.Item.useStyle = 1;
		base.Item.consumable = true;
		base.Item.createTile = ModContent.TileType<CrimsonAltarSheet>();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(1257, 10).AddIngredient(1329, 5).AddTile(16)
			.Register();
	}
}
