namespace Fargowiltas.Items.Tiles;

public class UnsafeBlueSlabWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{135}";

	public UnsafeBlueSlabWall()
		: base("Unsafe Blue Slab Wall", 94)
	{
	}
}
