namespace Fargowiltas.Items.Tiles;

public class UnsafePinkTileWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{1381}";

	public UnsafePinkTileWall()
		: base("Unsafe Pink Tile Wall", 97)
	{
	}
}
