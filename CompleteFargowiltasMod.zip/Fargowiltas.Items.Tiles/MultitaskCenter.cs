using Fargowiltas.Common.Systems.Recipes;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public class MultitaskCenter : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 28;
		base.Item.height = 14;
		base.Item.maxStack = 99;
		base.Item.useTurn = true;
		base.Item.autoReuse = true;
		base.Item.useAnimation = 15;
		base.Item.useTime = 10;
		base.Item.useStyle = 1;
		base.Item.consumable = true;
		base.Item.value = Item.buyPrice(0, 30);
		base.Item.createTile = ModContent.TileType<MultitaskCenterSheet>();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(36).AddIngredient(2172).AddIngredient(33)
			.AddRecipeGroup(RecipeGroups.AnyAnvil)
			.AddIngredient(31)
			.AddIngredient(363)
			.AddIngredient(332)
			.AddRecipeGroup(RecipeGroups.AnyWoodenTable)
			.AddRecipeGroup(RecipeGroups.AnyWoodenChair)
			.AddRecipeGroup(RecipeGroups.AnyCookingPot)
			.AddRecipeGroup(RecipeGroups.AnyWoodenSink)
			.AddIngredient(352)
			.Register();
	}
}
