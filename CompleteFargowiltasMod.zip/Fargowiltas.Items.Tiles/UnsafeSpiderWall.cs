namespace Fargowiltas.Items.Tiles;

public class UnsafeSpiderWall : UnsafeWall
{
	public override string Texture => $"Terraria/Images/Item_{4503}";

	public UnsafeSpiderWall()
		: base("Unsafe Spider Wall", 62, 4503)
	{
	}
}
