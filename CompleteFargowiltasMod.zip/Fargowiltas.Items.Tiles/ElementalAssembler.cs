using Fargowiltas.Common.Systems.Recipes;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Tiles;

public class ElementalAssembler : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 28;
		base.Item.height = 14;
		base.Item.maxStack = 99;
		base.Item.useTurn = true;
		base.Item.autoReuse = true;
		base.Item.useAnimation = 15;
		base.Item.useTime = 10;
		base.Item.useStyle = 1;
		base.Item.consumable = true;
		base.Item.value = Item.buyPrice(0, 50);
		base.Item.createTile = ModContent.TileType<ElementalAssemblerSheet>();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(221).AddIngredient(3000).AddIngredient(398)
			.AddIngredient(1430)
			.AddIngredient(1120)
			.AddIngredient(2196)
			.AddIngredient(2194)
			.AddIngredient(2198)
			.AddIngredient(2204)
			.AddIngredient(2197)
			.AddIngredient(998)
			.AddIngredient(2192)
			.AddIngredient(207)
			.AddIngredient(1128)
			.AddIngredient(5008)
			.AddRecipeGroup(RecipeGroups.AnyTombstone)
			.AddRecipeGroup(RecipeGroups.AnyDemonAltar)
			.AddTile(18)
			.Register();
	}
}
