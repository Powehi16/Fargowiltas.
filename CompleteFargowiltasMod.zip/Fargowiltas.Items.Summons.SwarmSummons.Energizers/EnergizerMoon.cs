using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.SwarmSummons.Energizers;

public class EnergizerMoon : ModItem
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 999;
		base.Item.rare = 1;
		base.Item.value = 100000;
	}
}
