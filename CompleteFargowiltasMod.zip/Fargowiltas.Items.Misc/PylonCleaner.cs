using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class PylonCleaner : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override void SetDefaults()
	{
		base.Item.width = 18;
		base.Item.height = 18;
		base.Item.maxStack = 99;
		base.Item.consumable = true;
		base.Item.useStyle = 1;
		base.Item.rare = 1;
		base.Item.UseSound = SoundID.Item1;
		base.Item.useAnimation = 20;
		base.Item.useTime = 20;
	}

	public override bool? UseItem(Player player)
	{
		if (player.itemAnimation > 0 && player.itemTime == 0 && player.whoAmI == Main.myPlayer)
		{
			foreach (TeleportPylonInfo pylonInfo in Main.PylonSystem.Pylons)
			{
				Vector2 pos = pylonInfo.PositionInTiles.ToWorldCoordinates();
				int projType = ModContent.ProjectileType<PurityNukeProj>();
				if (pylonInfo.TypeOfPylon == TeleportPylonType.Hallow)
				{
					projType = ModContent.ProjectileType<HallowNukeProj>();
				}
				int p = Projectile.NewProjectile(player.GetSource_ItemUse(base.Item), pos, Vector2.Zero, projType, 0, 0f, Main.myPlayer);
				if (p != Main.maxProjectiles)
				{
					Main.projectile[p].timeLeft = 2;
				}
				if (pylonInfo.TypeOfPylon == TeleportPylonType.GlowingMushroom)
				{
					projType = ModContent.ProjectileType<MushroomNukeProj>();
					p = Projectile.NewProjectile(player.GetSource_ItemUse(base.Item), pos, Vector2.Zero, projType, 0, 0f, Main.myPlayer);
					if (p != Main.maxProjectiles)
					{
						Main.projectile[p].timeLeft = 6;
					}
				}
			}
		}
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(66).AddTile(134).Register();
	}
}
