using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class MapViewer : ModItem
{
	public override string Texture => "Terraria/Images/Map_4";

	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.rare = 0;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
	}

	public override bool? UseItem(Player player)
	{
		if (Main.netMode != 1)
		{
			for (int i = 0; i < Main.maxTilesX; i++)
			{
				for (int j = 0; j < Main.maxTilesY; j++)
				{
					if (WorldGen.InWorld(i, j))
					{
						Main.Map.Update(i, j, byte.MaxValue);
					}
				}
			}
			Main.refreshMap = true;
		}
		else
		{
			Point center = Main.LocalPlayer.Center.ToTileCoordinates();
			int range = 300;
			for (int i = center.X - range / 2; i < center.X + range / 2; i++)
			{
				for (int j = center.Y - range / 2; j < center.Y + range / 2; j++)
				{
					if (WorldGen.InWorld(i, j))
					{
						Main.Map.Update(i, j, byte.MaxValue);
					}
				}
			}
			Main.refreshMap = true;
		}
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(893).AddIngredient(37).AddIngredient(237)
			.AddIngredient(43)
			.AddIngredient(544)
			.AddTile(18)
			.Register();
	}
}
