using Fargowiltas.Content.Buffs;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class BigSuckPotion : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 20;
	}

	public override void SetDefaults()
	{
		base.Item.width = 14;
		base.Item.height = 24;
		base.Item.maxStack = 30;
		base.Item.rare = 1;
		base.Item.useStyle = 9;
		base.Item.useAnimation = 17;
		base.Item.useTime = 17;
		base.Item.consumable = true;
		base.Item.useTurn = true;
		base.Item.UseSound = SoundID.Item3;
		base.Item.value = Item.buyPrice(0, 0, 2);
	}

	public override bool? UseItem(Player player)
	{
		player.AddBuff(ModContent.BuffType<BigSuckBuff>(), 180);
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(126).AddIngredient(116).AddIngredient(75)
			.AddTile(13)
			.DisableDecraft()
			.Register();
	}
}
