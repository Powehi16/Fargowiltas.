using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class DeathFruit : ModItem
{
	private SoundStyle DeathFruitSound = new SoundStyle("Fargowiltas/Assets/Sounds/DeathFruit");

	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Item.width = 18;
		base.Item.height = 18;
		base.Item.maxStack = 99;
		base.Item.rare = 1;
		base.Item.useStyle = 4;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.consumable = true;
		base.Item.UseSound = SoundID.Item27;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(1291).AddCondition(Condition.NearShimmer).Register();
	}

	public override bool AltFunctionUse(Player player)
	{
		return true;
	}

	public override bool CanUseItem(Player player)
	{
		if (!CanUse(player) && player.altFunctionUse != 2)
		{
			return false;
		}
		if (!CanUse(player, rightClick: true) && player.altFunctionUse == 2)
		{
			return false;
		}
		return true;
	}

	public override void HoldItem(Player player)
	{
		if (player.ConsumedLifeCrystals > 0)
		{
			base.Item.UseSound = DeathFruitSound;
		}
		else
		{
			base.Item.UseSound = SoundID.Item27;
		}
	}

	public override bool? UseItem(Player player)
	{
		if (player.ConsumedLifeFruit > 0)
		{
			if (player.altFunctionUse != 2)
			{
				player.ConsumedLifeFruit--;
			}
		}
		else if (player.ConsumedLifeCrystals > 0)
		{
			if (player.altFunctionUse != 2)
			{
				player.ConsumedLifeCrystals--;
			}
		}
		else
		{
			int effect;
			if (player.altFunctionUse == 2)
			{
				if (!CanUse(player, rightClick: true))
				{
					return false;
				}
				effect = 20;
				if (player.GetModPlayer<FargoPlayer>().DeathFruitHealth < 20)
				{
					effect = player.GetModPlayer<FargoPlayer>().DeathFruitHealth;
				}
			}
			else
			{
				if (!CanUse(player))
				{
					return false;
				}
				effect = -20;
			}
			player.GetModPlayer<FargoPlayer>().DeathFruitHealth -= effect;
			if (player.statLife > -effect)
			{
				player.statLife += effect;
				if (Main.myPlayer == player.whoAmI)
				{
					player.HealEffect(effect);
				}
			}
		}
		return true;
	}

	private bool CanUse(Player player, bool rightClick = false)
	{
		if (!rightClick && GetLife(player) > 20)
		{
			return true;
		}
		if (rightClick && player.GetModPlayer<FargoPlayer>().DeathFruitHealth > 0)
		{
			return true;
		}
		return false;
	}

	private int GetLife(Player player)
	{
		return player.statLifeMax - player.ConsumedLifeFruit * 5;
	}
}
