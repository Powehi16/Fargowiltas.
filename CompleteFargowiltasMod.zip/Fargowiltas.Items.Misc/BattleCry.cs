using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent.Creative;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class BattleCry : ModItem
{
	private int drawTimer = 0;

	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 28;
		base.Item.height = 38;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.rare = 5;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
	}

	public override bool AltFunctionUse(Player player)
	{
		return true;
	}

	public static void GenerateText(bool isBattle, Player player, bool cry)
	{
		string cryToggled = Language.GetTextValue("Mods.Fargowiltas.Items.BattleCry." + (isBattle ? "Battle" : "Calming"));
		string toggle = Language.GetTextValue("Mods.Fargowiltas.Items.BattleCry." + (cry ? "Activated" : "Deactivated"));
		string punctuation = Language.GetTextValue("Mods.Fargowiltas.MessageInfo.Common." + (isBattle ? "Exclamation" : "Period"));
		string text = Language.GetTextValue("Mods.Fargowiltas.Items.BattleCry.CryText", cryToggled, toggle, player.name, punctuation);
		Color color = (isBattle ? new Color(255, 0, 0) : new Color(0, 255, 255));
		FargoUtils.PrintText(text, color);
	}

	public static void SyncCry(Player player)
	{
		if (player.whoAmI == Main.myPlayer && Main.netMode == 1)
		{
			FargoPlayer modPlayer = player.GetModPlayer<FargoPlayer>();
			ModPacket packet = modPlayer.Mod.GetPacket();
			packet.Write((byte)8);
			packet.Write(player.whoAmI);
			packet.Write(modPlayer.BattleCry);
			packet.Write(modPlayer.CalmingCry);
			packet.Send();
		}
	}

	private void ToggleCry(bool isBattle, Player player, ref bool cry)
	{
		cry = !cry;
		if (Main.netMode == 0)
		{
			GenerateText(isBattle, player, cry);
		}
		else if (Main.netMode == 1 && player.whoAmI == Main.myPlayer)
		{
			ModPacket packet = base.Mod.GetPacket();
			packet.Write((byte)7);
			packet.Write(isBattle);
			packet.Write(player.whoAmI);
			packet.Write(cry);
			packet.Send();
			SyncCry(player);
		}
	}

	public override bool? UseItem(Player player)
	{
		if (player.whoAmI == Main.myPlayer)
		{
			FargoPlayer modPlayer = player.GetFargoPlayer();
			if (player.altFunctionUse == 2)
			{
				if (modPlayer.BattleCry)
				{
					ToggleCry(isBattle: true, player, ref modPlayer.BattleCry);
				}
				ToggleCry(isBattle: false, player, ref modPlayer.CalmingCry);
			}
			else
			{
				if (modPlayer.CalmingCry)
				{
					ToggleCry(isBattle: false, player, ref modPlayer.CalmingCry);
				}
				ToggleCry(isBattle: true, player, ref modPlayer.BattleCry);
			}
		}
		if (!Main.dedServ)
		{
			SoundStyle style = new SoundStyle("Fargowiltas/Assets/Sounds/Horn");
			SoundEngine.PlaySound(in style, player.Center);
		}
		return true;
	}

	public override bool PreDrawInInventory(SpriteBatch spriteBatch, Vector2 position, Rectangle frame, Color drawColor, Color itemColor, Vector2 origin, float scale)
	{
		Player player = Main.LocalPlayer;
		FargoPlayer modPlayer = player.GetFargoPlayer();
		float glowscale = ((float)(int)Main.mouseTextColor / 400f - 0.35f) * 0.3f + 0.9f;
		glowscale *= scale;
		float modifier = 0.5f + (float)Math.Sin((float)drawTimer / 30f) / 3f;
		Texture2D texture = ModContent.Request<Texture2D>("Fargowiltas/Items/Misc/BattleCry_Glow").Value;
		if (player.whoAmI == Main.myPlayer)
		{
			if (modPlayer.CalmingCry)
			{
				for (int j = 0; j < 12; j++)
				{
					Vector2 afterimageOffset = ((float)Math.PI * 2f * (float)j / 12f).ToRotationVector2() * 2f;
					Color glowColor = Color.Lerp(Color.SkyBlue, Color.CornflowerBlue, modifier) * 0.5f;
					Main.EntitySpriteDraw(texture, position + afterimageOffset, frame, glowColor, 0f, texture.Size() * 0.55f, glowscale, SpriteEffects.None);
				}
			}
			else if (modPlayer.BattleCry)
			{
				for (int j = 0; j < 12; j++)
				{
					Vector2 afterimageOffset = ((float)Math.PI * 2f * (float)j / 12f).ToRotationVector2() * 2f;
					Color glowColor = Color.Lerp(Color.Red, Color.PaleVioletRed, modifier) * 0.5f;
					Main.EntitySpriteDraw(texture, position + afterimageOffset, frame, glowColor, 0f, texture.Size() * 0.55f, glowscale, SpriteEffects.None);
				}
			}
		}
		drawTimer++;
		return base.PreDrawInInventory(spriteBatch, position, frame, drawColor, itemColor, origin, scale);
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(300, 15).AddIngredient(148, 5).AddIngredient(2324, 15)
			.AddIngredient(3117, 5)
			.AddTile(26)
			.Register();
	}
}
