using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.Audio;
using Terraria.Chat;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class ModeToggle : ModItem
{
	public override string Texture => "Fargowiltas/Items/Misc/ModeToggle_0";

	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 32;
		base.Item.height = 32;
		base.Item.value = Item.buyPrice(1);
		base.Item.rare = 1;
		base.Item.useAnimation = 20;
		base.Item.useTime = 20;
		base.Item.useStyle = 10;
		base.Item.noUseGraphic = true;
		base.Item.consumable = false;
		base.Item.shoot = ModContent.ProjectileType<WorldTokenProj>();
	}

	public override bool AltFunctionUse(Player player)
	{
		return true;
	}

	public override bool CanUseItem(Player player)
	{
		for (int i = 0; i < Main.maxNPCs; i++)
		{
			if (Main.npc[i].active && Main.npc[i].boss)
			{
				return false;
			}
		}
		return true;
	}

	public override bool? UseItem(Player player)
	{
		string text;
		if (player.altFunctionUse == 2)
		{
			if (Main.GameMode == 3)
			{
				Main.GameMode = 1;
				ChangeAllPlayerDifficulty(0);
				text = DiffText("Expert");
			}
			else
			{
				Main.GameMode = 3;
				ChangeAllPlayerDifficulty(3);
				text = DiffText("Journey");
			}
		}
		else
		{
			switch (Main.GameMode)
			{
			case 0:
				Main.GameMode = 1;
				ChangeAllPlayerDifficulty(0);
				text = DiffText("Expert");
				break;
			case 1:
				Main.GameMode = 2;
				ChangeAllPlayerDifficulty(0);
				text = DiffText("Master");
				break;
			default:
				Main.GameMode = 0;
				ChangeAllPlayerDifficulty(0);
				text = DiffText("Normal");
				break;
			}
		}
		if (Main.netMode == 0)
		{
			Main.NewText(text, new Color(175, 75, 255));
		}
		else if (Main.netMode == 2)
		{
			ChatHelper.BroadcastChatMessage(NetworkText.FromLiteral(text), new Color(175, 75, 255));
			NetMessage.SendData(7);
		}
		SoundEngine.PlaySound(in SoundID.Roar, player.Center);
		return true;
		static string DiffText(string difficulty)
		{
			return Language.GetTextValue("Mods.Fargowiltas.Items.ModeToggle." + difficulty);
		}
	}

	private static void ChangeAllPlayerDifficulty(byte diff)
	{
		for (int i = 0; i < 255; i++)
		{
			Player player = Main.player[i];
			if (player.active)
			{
				player.difficulty = diff;
				NetMessage.SendData(4, -1, -1, null, player.whoAmI);
			}
		}
	}

	public override bool PreDrawInInventory(SpriteBatch spriteBatch, Vector2 position, Rectangle frame, Color drawColor, Color itemColor, Vector2 origin, float scale)
	{
		Texture2D texture = (Texture2D)ModContent.Request<Texture2D>($"Fargowiltas/Items/Misc/ModeToggle_{Main.GameMode}");
		spriteBatch.Draw(texture, position, frame, drawColor, 0f, origin, scale, SpriteEffects.None, 0f);
		return false;
	}

	public override bool PreDrawInWorld(SpriteBatch spriteBatch, Color lightColor, Color alphaColor, ref float rotation, ref float scale, int whoAmI)
	{
		Texture2D texture = (Texture2D)ModContent.Request<Texture2D>($"Fargowiltas/Items/Misc/ModeToggle_{Main.GameMode}");
		Vector2 position = base.Item.position - Main.screenPosition + new Vector2(16f, 16f);
		Rectangle frame = new Rectangle(0, 0, 32, 32);
		spriteBatch.Draw(texture, position, frame, lightColor, rotation, new Vector2(16f, 16f), scale, SpriteEffects.None, 0f);
		return false;
	}
}
