using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class InstantResearch : ModItem
{
	public override string Texture => "Fargowiltas/Items/Placeholder";

	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Item.width = 18;
		base.Item.height = 18;
		base.Item.maxStack = 1;
		base.Item.rare = 1;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 4;
	}

	public override bool? UseItem(Player player)
	{
		if (player.itemAnimation > 0 && player.itemTime == 0)
		{
			int count = 0;
			for (int i = 0; i < ItemLoader.ItemCount; i++)
			{
				if (CreativeItemSacrificesCatalog.Instance.TryGetSacrificeCountCapToUnlockInfiniteItems(i, out var amountNeeded))
				{
					int diff = amountNeeded - player.creativeTracker.ItemSacrifices.GetSacrificeCount(i);
					if (diff > 0)
					{
						player.creativeTracker.ItemSacrifices.RegisterItemSacrifice(i, diff);
						count++;
					}
				}
			}
			FargoUtils.PrintLocalization("Items.InstantResearch.ResearchText", count);
		}
		return true;
	}
}
