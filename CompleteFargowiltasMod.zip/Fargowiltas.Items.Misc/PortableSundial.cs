using System.Linq;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent.Creative;
using Terraria.GameContent.Events;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class PortableSundial : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.value = Item.sellPrice(0, 5);
		base.Item.rare = 4;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.mana = 15;
		base.Item.UseSound = SoundID.Item4;
	}

	public override bool AltFunctionUse(Player player)
	{
		return true;
	}

	public override bool CanUseItem(Player player)
	{
		if (Main.npc.Any((NPC n) => n.active && n.boss))
		{
			base.Item.useAnimation = 120;
			base.Item.useTime = 120;
		}
		else
		{
			base.Item.useAnimation = 30;
			base.Item.useTime = 30;
		}
		return !Main.IsFastForwardingTime();
	}

	public override bool? UseItem(Player player)
	{
		if (player.altFunctionUse == 2)
		{
			Main.sundialCooldown = 0;
			SoundEngine.PlaySound(in SoundID.Item4, player.position);
			if (Main.netMode == 1)
			{
				NetMessage.SendData(51, -1, -1, null, Main.myPlayer, 3f);
				return true;
			}
			if (Main.dayTime)
			{
				Main.fastForwardTimeToDusk = true;
			}
			else
			{
				Main.fastForwardTimeToDawn = true;
			}
		}
		else
		{
			int noon = 27000;
			int midnight = 16200;
			if (Main.dayTime && Main.time < (double)noon)
			{
				Main.time = noon;
			}
			else if (Main.time < (double)midnight)
			{
				Main.time = midnight;
			}
			else
			{
				Main.dayTime = !Main.dayTime;
				Main.time = 0.0;
				if (Main.dayTime)
				{
					BirthdayParty.CheckMorning();
					Chest.SetupTravelShop();
				}
				else
				{
					BirthdayParty.CheckNight();
					if (!Main.dayTime && ++Main.moonPhase > 7)
					{
						Main.moonPhase = 0;
					}
				}
			}
		}
		NetMessage.SendData(7);
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(3064).AddIngredient(5381).AddTile(305)
			.Register();
	}
}
