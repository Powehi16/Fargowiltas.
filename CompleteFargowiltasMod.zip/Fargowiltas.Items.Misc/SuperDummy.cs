using Fargowiltas.NPCs;
using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class SuperDummy : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 30;
		base.Item.useTime = 15;
		base.Item.useAnimation = 15;
		base.Item.useStyle = 1;
		base.Item.useTurn = true;
		base.Item.rare = 1;
	}

	public override bool AltFunctionUse(Player player)
	{
		return true;
	}

	public override bool? UseItem(Player player)
	{
		if (player.altFunctionUse == 2)
		{
			if (player.whoAmI == Main.myPlayer)
			{
				if (Main.netMode == 0)
				{
					for (int i = 0; i < Main.maxNPCs; i++)
					{
						if (Main.npc[i].active && Main.npc[i].type == ModContent.NPCType<global::Fargowiltas.NPCs.SuperDummy>())
						{
							NPC npc = Main.npc[i];
							npc.life = 0;
							npc.HitEffect();
							Main.npc[i].SimpleStrikeNPC(int.MaxValue, 0, crit: false, 0f, null, damageVariation: false, 0f, noPlayerInteraction: true);
						}
					}
				}
				else if (Main.netMode == 1)
				{
					ModPacket netMessage = base.Mod.GetPacket();
					netMessage.Write((byte)5);
					netMessage.Send();
				}
			}
		}
		else if (NPC.CountNPCS(ModContent.NPCType<global::Fargowiltas.NPCs.SuperDummy>()) < 50)
		{
			Projectile.NewProjectile(position: new Vector2((int)Main.MouseWorld.X - 9, (int)Main.MouseWorld.Y - 20), spawnSource: player.GetSource_ItemUse(base.Item), velocity: Vector2.Zero, Type: ModContent.ProjectileType<SpawnProj>(), Damage: 0, KnockBack: 0f, Owner: player.whoAmI, ai0: ModContent.NPCType<global::Fargowiltas.NPCs.SuperDummy>());
		}
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(3202).AddIngredient(75).AddTile(96)
			.Register();
	}
}
