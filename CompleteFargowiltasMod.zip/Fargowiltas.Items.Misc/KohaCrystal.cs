using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Misc;

public class KohaCrystal : ModItem
{
	private SoundStyle DeathFruitSound = new SoundStyle("Fargowiltas/Assets/Sounds/DeathFruit");

	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Item.width = 18;
		base.Item.height = 18;
		base.Item.maxStack = 99;
		base.Item.rare = 1;
		base.Item.useStyle = 4;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.consumable = true;
		base.Item.UseSound = SoundID.Item27;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(109).AddCondition(Condition.NearShimmer).Register();
	}

	public override void HoldItem(Player player)
	{
		if (player.ConsumedManaCrystals > 0)
		{
			base.Item.UseSound = DeathFruitSound;
		}
		else
		{
			base.Item.UseSound = SoundID.Item27;
		}
	}

	public override bool? UseItem(Player player)
	{
		if (player.ConsumedManaCrystals > 0 && player.altFunctionUse != 2)
		{
			player.ManaEffect(-20);
			player.ConsumedManaCrystals--;
		}
		return true;
	}

	public override bool CanUseItem(Player player)
	{
		return player.ConsumedManaCrystals > 0;
	}
}
