namespace Fargowiltas.NPCs;

public enum SquirrelShopGroup
{
	Enchant,
	Essence,
	Force,
	Soul,
	Potion,
	Other,
	Acorn,
	End
}
