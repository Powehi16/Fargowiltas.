using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Fargowiltas.Common.Configs;
using Fargowiltas.Items.CaughtNPCs;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent;
using Terraria.GameContent.Bestiary;
using Terraria.GameContent.Personalities;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.NPCs;

[AutoloadHead]
public class Squirrel : ModNPC
{
	private static int shopNum;

	private static bool showCycleShop;

	private static Profiles.DefaultNPCProfile NPCProfile;

	private const string ShopName = "Shop";

	public static List<(string, string)> SquirrelSellsModded;

	public static List<(string, string)> SquirrelSellsMaterialsModded;

	private Asset<Texture2D> GlowAsset => ModContent.Request<Texture2D>(Texture + "_Glow");

	private Asset<Texture2D> EyesAsset => ModContent.Request<Texture2D>(Texture + "_Eyes");

	public static int MaxItems => ModLoader.HasMod("ShopExpander") ? 38 : 40;

	public override void SetStaticDefaults()
	{
		Main.npcFrameCount[base.Type] = 6;
		NPCID.Sets.ExtraFramesCount[base.Type] = 9;
		NPCID.Sets.AttackFrameCount[base.Type] = 4;
		NPCID.Sets.DangerDetectRange[base.Type] = 700;
		NPCID.Sets.AttackType[base.Type] = 0;
		NPCID.Sets.AttackTime[base.Type] = 90;
		NPCID.Sets.AttackAverageChance[base.Type] = 30;
		NPCID.Sets.HatOffsetY[base.Type] = 4;
		NPCID.Sets.CannotSitOnFurniture[base.Type] = true;
		NPCID.Sets.NPCBestiaryDrawModifiers nPCBestiaryDrawModifiers = new NPCID.Sets.NPCBestiaryDrawModifiers();
		nPCBestiaryDrawModifiers.Velocity = -1f;
		nPCBestiaryDrawModifiers.Direction = -1;
		NPCID.Sets.NPCBestiaryDrawModifiers drawModifiers = nPCBestiaryDrawModifiers;
		NPCID.Sets.NPCBestiaryDrawOffset.Add(base.Type, drawModifiers);
		base.NPC.Happiness.SetBiomeAffection<ForestBiome>(AffectionLevel.Love);
		base.NPC.Happiness.SetBiomeAffection<UndergroundBiome>(AffectionLevel.Hate);
		base.NPC.Happiness.SetNPCAffection<LumberJack>(AffectionLevel.Like);
		NPCProfile = new Profiles.DefaultNPCProfile(Texture, NPCHeadLoader.GetHeadSlot(HeadTexture), Texture + "_Party");
	}

	public override void SetDefaults()
	{
		base.NPC.townNPC = true;
		base.NPC.friendly = true;
		base.NPC.width = 34;
		base.NPC.height = 42;
		base.NPC.damage = 0;
		base.NPC.defense = 0;
		base.NPC.lifeMax = 100;
		base.NPC.HitSound = SoundID.NPCHit1;
		base.NPC.DeathSound = SoundID.NPCDeath1;
		base.NPC.knockBackResist = 0.25f;
		base.AnimationType = 299;
		base.NPC.aiStyle = 7;
	}

	public override void ChatBubblePosition(ref Vector2 position, ref SpriteEffects spriteffects)
	{
		position.Y += 17f;
	}

	public override ITownNPCProfile TownNPCProfile()
	{
		return NPCProfile;
	}

	public override void SetBestiary(BestiaryDatabase database, BestiaryEntry bestiaryEntry)
	{
		bestiaryEntry.Info.AddRange(new IBestiaryInfoElement[2]
		{
			BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Biomes.Surface,
			new FlavorTextBestiaryInfoElement("Mods.Fargowiltas.Bestiary.Squirrel")
		});
	}

	public override List<string> SetNPCNameList()
	{
		return new List<string> { "Rick", "Acorn", "Puff", "Coco", "Truffle", "Furgo", "Squeaks" };
	}

	public override void OnSpawn(IEntitySource source)
	{
		FargoWorld.DownedBools["squirrel"] = true;
		base.OnSpawn(source);
	}

	public override void AI()
	{
		base.NPC.dontTakeDamage = Main.bloodMoon;
		base.DrawOffsetY = -2f;
	}

	public override bool CanTownNPCSpawn(int numTownNPCs)
	{
		if (FargoGlobalNPC.AnyBossAlive() || !FargoServerConfig.Instance.Squirrel)
		{
			return false;
		}
		if (FargoWorld.DownedBools["squirrel"])
		{
			return true;
		}
		if (!Fargowiltas.ModLoaded["FargowiltasSouls"] && NPC.downedSlimeKing)
		{
			return true;
		}
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && ModContent.TryFind<ModItem>("FargowiltasSouls", "TopHatSquirrelCaught", out var modItem) && Main.player.Any((Player p) => p.active && p.HasItem(modItem.Type)))
		{
			return true;
		}
		return false;
	}

	public override string GetChat()
	{
		showCycleShop = GetSellableItems().Count / MaxItems > 0;
		if (Main.bloodMoon)
		{
			return SquirrelChat("BloodMoon");
		}
		int num = Main.rand.Next(3);
		if (1 == 0)
		{
		}
		string result = num switch
		{
			0 => SquirrelChat("Normal1"), 
			1 => SquirrelChat("Normal2"), 
			_ => SquirrelChat("Normal3"), 
		};
		if (1 == 0)
		{
		}
		return result;
	}

	public override void SetChatButtons(ref string button, ref string button2)
	{
		button = Language.GetTextValue("LegacyInterface.28");
		if (showCycleShop)
		{
			button += $" {shopNum + 1}";
			button2 = Language.GetTextValue("Mods.Fargowiltas.NPCs.Mutant.CycleShop");
		}
	}

	public override void OnChatButtonClicked(bool firstButton, ref string shopName)
	{
		if (firstButton)
		{
			shopName = "Shop";
		}
		else
		{
			shopNum++;
		}
		if (shopNum > GetSellableItems().Count / MaxItems)
		{
			shopNum = 0;
		}
	}

	public static SquirrelShopGroup SquirrelSells(Item item, out SquirrelSellType sellType)
	{
		if (item.type == 4956)
		{
			sellType = SquirrelSellType.CraftableMaterialsSold;
			return SquirrelShopGroup.Other;
		}
		if (item.makeNPC != 0 || FargoSets.Items.SquirrelSellsDirectly[item.type])
		{
			sellType = SquirrelSellType.SoldBySquirrel;
			return SquirrelShopGroup.Other;
		}
		if (((item.buffType != 0 && item.type != 4024) || FargoSets.Items.NonBuffPotion[item.type]) && item.maxStack >= 30)
		{
			sellType = SquirrelSellType.SoldAtThirtyStack;
			return SquirrelShopGroup.Potion;
		}
		Mod soulsMod;
		bool soulsEnabled = ModLoader.TryGetMod("FargowiltasSouls", out soulsMod);
		if (IsFargoSoulsItem(item))
		{
			if (item.ModItem.Name.EndsWith("Enchant"))
			{
				sellType = SquirrelSellType.SoldBySquirrel;
				return SquirrelShopGroup.Enchant;
			}
			if (item.ModItem.Name.EndsWith("Essence"))
			{
				sellType = SquirrelSellType.SoldBySquirrel;
				return SquirrelShopGroup.Essence;
			}
			if (soulsEnabled && SquirrelSellsModded.Any(((string, string) s) => ModContent.TryFind<ModItem>(s.Item1, s.Item2, out var value2) && value2.Type == item.type))
			{
				sellType = SquirrelSellType.SoldBySquirrel;
				return SquirrelShopGroup.Other;
			}
			if (item.ModItem.Name.EndsWith("Force"))
			{
				sellType = SquirrelSellType.SomeMaterialsSold;
				return SquirrelShopGroup.Enchant;
			}
			if (soulsEnabled && SquirrelSellsMaterialsModded.Any(((string, string) s) => ModContent.TryFind<ModItem>(s.Item1, s.Item2, out var value) && value.Type == item.type))
			{
				sellType = SquirrelSellType.CraftableMaterialsSold;
				return SquirrelShopGroup.Other;
			}
			if (item.ModItem.Name.EndsWith("Soul"))
			{
				foreach (Recipe recipe in Main.recipe.Where((Recipe recipe) => recipe.HasResult(item.type)))
				{
					foreach (Item material in recipe.requiredItem)
					{
						if (material.type != 0 && material.ModItem != null)
						{
							if (material.ModItem.Name.EndsWith("Essence"))
							{
								sellType = SquirrelSellType.SomeMaterialsSold;
								return SquirrelShopGroup.Essence;
							}
							if (material.ModItem.Name.EndsWith("Force"))
							{
								sellType = SquirrelSellType.SomeMaterialsSold;
								return SquirrelShopGroup.Force;
							}
							if (material.ModItem.Name.EndsWith("Soul"))
							{
								sellType = SquirrelSellType.SomeMaterialsSold;
								return SquirrelShopGroup.Soul;
							}
						}
					}
				}
				sellType = SquirrelSellType.SoldBySquirrel;
				return SquirrelShopGroup.Soul;
			}
		}
		sellType = SquirrelSellType.End;
		return SquirrelShopGroup.End;
	}

	public void TryAddItem(Item item, Dictionary<SquirrelShopGroup, SortedSet<int>> itemCollections)
	{
		SquirrelSellType sellType;
		SquirrelShopGroup shopGroup = SquirrelSells(item, out sellType);
		switch (sellType)
		{
		case SquirrelSellType.SoldBySquirrel:
			itemCollections[shopGroup].Add(item.type);
			break;
		case SquirrelSellType.SomeMaterialsSold:
		{
			foreach (Recipe recipe in Main.recipe.Where((Recipe recipe) => recipe.HasResult(item.type)))
			{
				foreach (Item material in recipe.requiredItem)
				{
					if (material.ModItem != null && material.ModItem.Name.EndsWith(shopGroup.ToString()))
					{
						itemCollections[shopGroup].Add(material.type);
					}
				}
			}
			break;
		}
		case SquirrelSellType.CraftableMaterialsSold:
		{
			foreach (Recipe recipe in Main.recipe.Where((Recipe recipe) => recipe.HasResult(item.type)))
			{
				foreach (Item material in recipe.requiredItem)
				{
					if (material.type != 0 && Main.recipe.Any((Recipe r) => r.HasResult(material.type)))
					{
						itemCollections[shopGroup].Add(material.type);
					}
				}
			}
			break;
		}
		case SquirrelSellType.SoldAtThirtyStack:
		{
			foreach (Player player in Main.player.Where((Player p) => p.active))
			{
				if (player.GetFargoPlayer().ItemHasBeenOwnedAtThirtyStack[item.type])
				{
					itemCollections[shopGroup].Add(item.type);
				}
			}
			break;
		}
		}
	}

	private List<int> GetSellableItems()
	{
		Dictionary<SquirrelShopGroup, SortedSet<int>> itemCollections = new Dictionary<SquirrelShopGroup, SortedSet<int>>();
		for (int i = 0; i < 7; i++)
		{
			itemCollections[(SquirrelShopGroup)i] = new SortedSet<int>();
		}
		foreach (Player player in Main.player.Where((Player p) => p.active))
		{
			FargoPlayer modPlayer = player.GetFargoPlayer();
			Item[] inventory = player.inventory;
			SquirrelSellType sellType;
			foreach (Item item in inventory)
			{
				if (SquirrelSells(item, out sellType) != SquirrelShopGroup.End)
				{
					modPlayer.ItemHasBeenOwned[item.type] = true;
					if (item.stack >= 30)
					{
						modPlayer.ItemHasBeenOwnedAtThirtyStack[item.type] = true;
					}
				}
			}
			Item[] item2 = player.bank.item;
			foreach (Item item in item2)
			{
				if (SquirrelSells(item, out sellType) != SquirrelShopGroup.End)
				{
					modPlayer.ItemHasBeenOwned[item.type] = true;
					if (item.stack >= 30)
					{
						modPlayer.ItemHasBeenOwnedAtThirtyStack[item.type] = true;
					}
				}
			}
			Item[] armor = player.armor;
			foreach (Item item in armor)
			{
				if (SquirrelSells(item, out sellType) != SquirrelShopGroup.End)
				{
					modPlayer.ItemHasBeenOwned[item.type] = true;
					if (item.stack >= 30)
					{
						modPlayer.ItemHasBeenOwnedAtThirtyStack[item.type] = true;
					}
				}
			}
			foreach (KeyValuePair<int, Item> item in ContentSamples.ItemsByType)
			{
				if (modPlayer.ItemHasBeenOwned[item.Key])
				{
					TryAddItem(item.Value, itemCollections);
				}
			}
			if (player.unlockedBiomeTorches)
			{
				itemCollections[SquirrelShopGroup.Other].Add(5043);
			}
		}
		foreach (NPC npc in Main.npc.Where((NPC n) => n.active && n.townNPC && CaughtNPCItem.CaughtTownies.ContainsKey(n.type)))
		{
			itemCollections[SquirrelShopGroup.Other].Add(CaughtNPCItem.CaughtTownies[npc.type]);
		}
		itemCollections[SquirrelShopGroup.Acorn].Add(27);
		itemCollections[SquirrelShopGroup.Acorn].Add(4857);
		itemCollections[SquirrelShopGroup.Acorn].Add(4852);
		itemCollections[SquirrelShopGroup.Acorn].Add(4856);
		itemCollections[SquirrelShopGroup.Acorn].Add(4854);
		itemCollections[SquirrelShopGroup.Acorn].Add(4855);
		itemCollections[SquirrelShopGroup.Acorn].Add(4853);
		itemCollections[SquirrelShopGroup.Acorn].Add(4851);
		return itemCollections.OrderBy((KeyValuePair<SquirrelShopGroup, SortedSet<int>> kv) => kv.Key).SelectMany((KeyValuePair<SquirrelShopGroup, SortedSet<int>> kv) => kv.Value).ToList();
	}

	public static bool IsFargoSoulsItem(Item item)
	{
		if (item.ModItem != null)
		{
			string modName = item.ModItem.Mod.Name;
			return modName.Equals("FargowiltasSouls") || modName.Equals("FargowiltasSoulsDLC");
		}
		return false;
	}

	public override void AddShops()
	{
		NPCShop npcShop = new NPCShop(base.Type);
		npcShop.Register();
	}

	public override void ModifyActiveShop(string shopName, Item[] items)
	{
		int nextSlot = 0;
		int index = 0;
		int startOffset = shopNum * MaxItems;
		List<int> sellableItems = GetSellableItems();
		if (shopNum == 0 && ModContent.TryFind<ModItem>("FargowiltasSouls", "TopHatSquirrelCaught", out var modItem))
		{
			items[nextSlot] = new Item(modItem.Type)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			};
			nextSlot++;
		}
		foreach (int type in sellableItems)
		{
			if (++index < startOffset)
			{
				continue;
			}
			if (nextSlot >= MaxItems)
			{
				break;
			}
			Item item = new Item(type);
			bool medals = false;
			int price;
			if (item.makeNPC != 0)
			{
				price = Item.buyPrice(0, 10);
				int[] pricier = new int[15]
				{
					2673, 4961, 2889, 2890, 2891, 4340, 2892, 4274, 2893, 4362,
					2894, 4482, 3564, 4419, 2895
				};
				if (pricier.Contains(item.type))
				{
					price *= 5;
				}
				else if (item.ModItem is CaughtNPCItem)
				{
					price *= 2;
				}
			}
			else if (type == 1326)
			{
				price = 250;
				medals = true;
			}
			else
			{
				price = item.value * 2;
			}
			if (medals)
			{
				items[nextSlot] = new Item(type)
				{
					shopCustomPrice = Item.buyPrice(0, 0, 0, price),
					shopSpecialCurrency = CustomCurrencyID.DefenderMedals
				};
			}
			else
			{
				items[nextSlot] = new Item(type)
				{
					shopCustomPrice = Item.buyPrice(0, 0, 0, price)
				};
			}
			nextSlot++;
		}
	}

	public override bool CanGoToStatue(bool toKingStatue)
	{
		return toKingStatue;
	}

	public override bool UsesPartyHat()
	{
		return false;
	}

	public override bool PreDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
	{
		if (!Main.bloodMoon)
		{
			return true;
		}
		Rectangle frame = base.NPC.frame;
		SpriteEffects effects = ((base.NPC.spriteDirection >= 0) ? SpriteEffects.FlipHorizontally : SpriteEffects.None);
		float scale = ((float)(int)Main.mouseTextColor / 200f - 0.35f) * 0.3f + 0.9f;
		for (int j = 0; j < 12; j++)
		{
			Vector2 afterimageOffset = ((float)Math.PI * 2f * (float)j / 12f).ToRotationVector2() * 4f + Vector2.UnitY * 3f;
			Color red = Color.Red;
			red.A = 0;
			Color glowColor = red;
			Texture2D texture = ModContent.Request<Texture2D>(Texture).Value;
			Main.EntitySpriteDraw(texture, base.NPC.Center + afterimageOffset - screenPos + Vector2.UnitY * (base.NPC.gfxOffY - 1f), base.NPC.frame, glowColor, base.NPC.rotation, new Vector2(texture.Width / 2, texture.Height / 2 / Main.npcFrameCount[base.NPC.type]), base.NPC.scale, effects);
		}
		return true;
	}

	public override void PostDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
	{
		if (Main.bloodMoon)
		{
			Rectangle frame = base.NPC.frame;
			SpriteEffects effects = ((base.NPC.spriteDirection >= 0) ? SpriteEffects.FlipHorizontally : SpriteEffects.None);
			Vector2 position = base.NPC.Center - screenPos + new Vector2(0f, base.NPC.gfxOffY + 2f);
			spriteBatch.Draw(EyesAsset.Value, position, frame, Color.White * base.NPC.Opacity, base.NPC.rotation, frame.Size() / 2f, base.NPC.scale, effects, 0f);
		}
	}

	private static string SquirrelChat(string key)
	{
		return Language.GetTextValue("Mods.Fargowiltas.NPCs.Squirrel.Chat." + key);
	}

	static Squirrel()
	{
		List<(string, string)> list = new List<(string, string)>();
		CollectionsMarshal.SetCount(list, 7);
		Span<(string, string)> span = CollectionsMarshal.AsSpan(list);
		int num = 0;
		span[num] = ("FargowiltasSouls", "BionomicCluster");
		num++;
		span[num] = ("FargowiltasSouls", "HeartoftheMasochist");
		num++;
		span[num] = ("FargowiltasSouls", "ChaliceoftheMoon");
		num++;
		span[num] = ("FargowiltasSouls", "DubiousCircuitry");
		num++;
		span[num] = ("FargowiltasSouls", "LumpOfFlesh");
		num++;
		span[num] = ("FargowiltasSouls", "PureHeart");
		num++;
		span[num] = ("FargowiltasSouls", "SupremeDeathbringerFairy");
		num++;
		SquirrelSellsModded = list;
		List<(string, string)> list2 = new List<(string, string)>();
		CollectionsMarshal.SetCount(list2, 3);
		span = CollectionsMarshal.AsSpan(list2);
		num = 0;
		span[num] = ("FargowiltasSouls", "MasochistSoul");
		num++;
		span[num] = ("FargowiltasSouls", "AeolusBoots");
		num++;
		span[num] = ("FargowiltasSouls", "ZephyrBoots");
		num++;
		SquirrelSellsMaterialsModded = list2;
	}
}
