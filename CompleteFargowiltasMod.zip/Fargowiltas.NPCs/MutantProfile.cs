using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using Terraria;
using Terraria.GameContent;
using Terraria.ModLoader;

namespace Fargowiltas.NPCs;

public class MutantProfile : ITownNPCProfile
{
	public int RollVariation()
	{
		return 0;
	}

	public string GetNameForVariant(NPC npc)
	{
		return npc.getNewNPCName();
	}

	public Asset<Texture2D> GetTextureNPCShouldUse(NPC npc)
	{
		if (npc.IsABestiaryIconDummy)
		{
			return ModContent.Request<Texture2D>("Fargowiltas/NPCs/Mutant");
		}
		if (npc.IsShimmerVariant)
		{
			if (npc.altTexture == 1)
			{
				return ModContent.Request<Texture2D>("Fargowiltas/NPCs/Mutant_Shimmer_Party");
			}
			return ModContent.Request<Texture2D>("Fargowiltas/NPCs/Mutant_Shimmer");
		}
		return ModContent.Request<Texture2D>("Fargowiltas/NPCs/Mutant");
	}

	public int GetHeadTextureIndex(NPC npc)
	{
		return ModContent.GetModHeadSlot("Fargowiltas/NPCs/Mutant_Head");
	}
}
