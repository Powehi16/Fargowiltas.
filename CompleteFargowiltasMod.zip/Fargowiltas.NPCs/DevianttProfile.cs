using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using Terraria;
using Terraria.GameContent;
using Terraria.ModLoader;

namespace Fargowiltas.NPCs;

public class DevianttProfile : ITownNPCProfile
{
	public int RollVariation()
	{
		return 0;
	}

	public string GetNameForVariant(NPC npc)
	{
		return npc.getNewNPCName();
	}

	public Asset<Texture2D> GetTextureNPCShouldUse(NPC npc)
	{
		if (npc.IsABestiaryIconDummy)
		{
			return ModContent.Request<Texture2D>("Fargowiltas/NPCs/Deviantt");
		}
		if (npc.IsShimmerVariant)
		{
			return ModContent.Request<Texture2D>("Fargowiltas/NPCs/Deviantt_Shimmer");
		}
		return ModContent.Request<Texture2D>("Fargowiltas/NPCs/Deviantt");
	}

	public int GetHeadTextureIndex(NPC npc)
	{
		return ModContent.GetModHeadSlot("Fargowiltas/NPCs/Deviantt_Head");
	}
}
