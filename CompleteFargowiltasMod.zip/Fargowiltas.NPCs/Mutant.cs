using System.Collections.Generic;
using System.Linq;
using Fargowiltas.Common.Configs;
using Fargowiltas.Content.Biomes;
using Fargowiltas.Items.Misc;
using Fargowiltas.Items.Summons.Mutant;
using Fargowiltas.Items.Summons.SwarmSummons;
using Fargowiltas.Items.Tiles;
using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;
using Terraria.GameContent.Bestiary;
using Terraria.GameContent.Events;
using Terraria.GameContent.Personalities;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.NPCs;

[AutoloadHead]
public class Mutant : ModNPC
{
	private static int shopNum = 1;

	internal bool spawned;

	private bool canSayDefeatQuote = true;

	private int defeatQuoteTimer = 900;

	public const string ShopName1 = "Pre Hardmode Shop";

	public const string ShopName2 = "Hardmode Shop";

	public const string ShopName3 = "Post Moon Lord Shop";

	private const int SquirrelFrameCount = 6;

	private int SquirrelFrame = 0;

	private bool AnyHardmodeSummon => Main.hardMode || Fargowiltas.summonTracker.SortedSummons.Any((MutantSummonInfo s) => s.progression >= 7f && s.downed());

	private bool AnyPostMLSummon => NPC.downedMoonlord || Fargowiltas.summonTracker.SortedSummons.Any((MutantSummonInfo s) => s.progression >= 18f && s.downed());

	public override ITownNPCProfile TownNPCProfile()
	{
		return new MutantProfile();
	}

	public override void SetStaticDefaults()
	{
		Main.npcFrameCount[base.NPC.type] = 25;
		NPCID.Sets.ExtraFramesCount[base.NPC.type] = 9;
		NPCID.Sets.AttackFrameCount[base.NPC.type] = 4;
		NPCID.Sets.DangerDetectRange[base.NPC.type] = 700;
		NPCID.Sets.AttackType[base.NPC.type] = 0;
		NPCID.Sets.AttackTime[base.NPC.type] = 90;
		NPCID.Sets.AttackAverageChance[base.NPC.type] = 30;
		NPCID.Sets.ShimmerTownTransform[base.NPC.type] = true;
		NPCID.Sets.ShimmerTownTransform[base.Type] = true;
		NPCID.Sets.NPCBestiaryDrawModifiers nPCBestiaryDrawModifiers = new NPCID.Sets.NPCBestiaryDrawModifiers();
		nPCBestiaryDrawModifiers.Velocity = -1f;
		nPCBestiaryDrawModifiers.Direction = -1;
		NPCID.Sets.NPCBestiaryDrawModifiers drawModifiers = nPCBestiaryDrawModifiers;
		NPCID.Sets.NPCBestiaryDrawOffset.Add(base.Type, drawModifiers);
		base.NPC.Happiness.SetBiomeAffection<SkyBiome>(AffectionLevel.Love);
		base.NPC.Happiness.SetBiomeAffection<ForestBiome>(AffectionLevel.Like);
		base.NPC.Happiness.SetBiomeAffection<HallowBiome>(AffectionLevel.Dislike);
		base.NPC.Happiness.SetNPCAffection<Abominationn>(AffectionLevel.Love);
		base.NPC.Happiness.SetNPCAffection<Deviantt>(AffectionLevel.Like);
		base.NPC.Happiness.SetNPCAffection<LumberJack>(AffectionLevel.Dislike);
		base.NPC.AddDebuffImmunities(new List<int> { 68 });
	}

	public override void SetBestiary(BestiaryDatabase database, BestiaryEntry bestiaryEntry)
	{
		bestiaryEntry.Info.AddRange(new IBestiaryInfoElement[2]
		{
			BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Biomes.Sky,
			new FlavorTextBestiaryInfoElement("Mods.Fargowiltas.Bestiary.Mutant")
		});
	}

	public override void SetDefaults()
	{
		base.NPC.townNPC = true;
		base.NPC.friendly = true;
		base.NPC.width = 18;
		base.NPC.height = 40;
		base.NPC.aiStyle = 7;
		base.NPC.damage = 10;
		base.NPC.defense = (NPC.downedMoonlord ? 50 : 15);
		base.NPC.lifeMax = (NPC.downedMoonlord ? 5000 : 250);
		base.NPC.HitSound = SoundID.NPCHit1;
		base.NPC.DeathSound = SoundID.NPCDeath1;
		base.NPC.knockBackResist = 0.5f;
		base.AnimationType = 22;
		if (FargoServerConfig.Instance.CatchNPCs)
		{
			Main.npcCatchable[base.NPC.type] = true;
		}
		base.NPC.buffImmune[68] = true;
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedMutant"))
		{
			base.NPC.lifeMax = 77000;
			base.NPC.defense = 360;
		}
	}

	public override bool CanGoToStatue(bool toKingStatue)
	{
		return true;
	}

	public override void AI()
	{
		base.NPC.breath = 200;
		if (defeatQuoteTimer > 0)
		{
			defeatQuoteTimer--;
		}
		else
		{
			canSayDefeatQuote = false;
		}
		if (!spawned)
		{
			spawned = true;
			if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedMutant"))
			{
				base.NPC.lifeMax = 77000;
				base.NPC.life = base.NPC.lifeMax;
				base.NPC.defense = 360;
			}
		}
		base.AnimationType = (base.NPC.IsShimmerVariant ? (-1) : 22);
		NPCID.Sets.CannotSitOnFurniture[base.NPC.type] = NPC.ShimmeredTownNPCs[base.NPC.type];
	}

	public override bool UsesPartyHat()
	{
		return !base.NPC.IsShimmerVariant;
	}

	public override bool CanTownNPCSpawn(int numTownNPCs)
	{
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("MutantAlive"))
		{
			return false;
		}
		return FargoServerConfig.Instance.Mutant && FargoWorld.DownedBools["boss"] && !FargoGlobalNPC.AnyBossAlive();
	}

	public override List<string> SetNPCNameList()
	{
		string[] names = new string[13]
		{
			"Flacken", "Dorf", "Bingo", "Hans", "Fargo", "Grim", "Mike", "Fargu", "Terrance", "Catty N. Pem",
			"Tom", "Weirdus", "Polly"
		};
		return new List<string>(names);
	}

	public override string GetChat()
	{
		if (base.NPC.homeless && canSayDefeatQuote && Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedMutant"))
		{
			canSayDefeatQuote = false;
			if ((bool)ModLoader.GetMod("FargowiltasSouls").Call("EternityMode"))
			{
				return MutantChat("EternityDefeat");
			}
			return MutantChat("Defeat");
		}
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && Main.rand.NextBool(4) && (bool)ModLoader.GetMod("FargowiltasSouls").Call("MutantArmor"))
		{
			return MutantChat("MutantArmor");
		}
		List<string> dialogue = (from item in Language.FindAll(Lang.CreateDialogFilter("Mods.Fargowiltas.NPCs.Mutant.Chat.Normal"))
			select item.Value).ToList();
		if (Fargowiltas.ModLoaded["FargowiltasSouls"])
		{
			dialogue.AddWithCondition(MutantChat("SoulsPostML"), NPC.downedMoonlord);
			if ((bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedMutant"))
			{
				dialogue.Add(MutantChat("DefeatCommon"));
			}
			else if ((bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedFishronEX") || (bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedAbom"))
			{
				dialogue.Add(MutantChat("DefeatAbom"));
			}
		}
		else
		{
			dialogue.Add(MutantChat("SoulsModDisabled"));
		}
		dialogue.AddWithCondition(MutantChat("PumpkinMoon"), Main.pumpkinMoon);
		dialogue.AddWithCondition(MutantChat("FrostMoon"), Main.snowMoon);
		dialogue.AddWithCondition(MutantChat("SlimeRain"), Main.slimeRain);
		dialogue.AddWithCondition(MutantChat("BloodMoon1"), Main.bloodMoon);
		dialogue.AddWithCondition(MutantChat("BloodMoon2"), Main.bloodMoon);
		dialogue.AddWithCondition(MutantChat("NightTime"), !Main.dayTime);
		int partyGirl = NPC.FindFirstNPC(208);
		if (BirthdayParty.PartyIsUp)
		{
			if (partyGirl >= 0)
			{
				dialogue.Add(MutantChat("Party", Main.npc[partyGirl].GivenName));
			}
			dialogue.Add(MutantChat("PartyWithoutPartyGirl"));
		}
		int nurse = NPC.FindFirstNPC(18);
		if (nurse >= 0)
		{
			dialogue.Add(MutantChat("Nurse", Main.npc[nurse].GivenName));
		}
		int witchDoctor = NPC.FindFirstNPC(228);
		if (witchDoctor >= 0)
		{
			dialogue.Add(MutantChat("WitchDoctor", Main.npc[witchDoctor].GivenName));
		}
		int dryad = NPC.FindFirstNPC(20);
		if (dryad >= 0)
		{
			dialogue.Add(MutantChat("Dryad", Main.npc[dryad].GivenName));
		}
		int stylist = NPC.FindFirstNPC(353);
		if (stylist >= 0)
		{
			dialogue.Add(MutantChat("Stylist", Main.npc[stylist].GivenName));
		}
		int truffle = NPC.FindFirstNPC(160);
		if (truffle >= 0)
		{
			dialogue.Add(MutantChat("Truffle"));
		}
		int tax = NPC.FindFirstNPC(441);
		if (tax >= 0)
		{
			dialogue.Add(MutantChat("TaxCollector", Main.npc[tax].GivenName));
		}
		int guide = NPC.FindFirstNPC(22);
		if (guide >= 0)
		{
			dialogue.Add(MutantChat("Guide", Main.npc[guide].GivenName));
		}
		int cyborg = NPC.FindFirstNPC(209);
		if (truffle >= 0 && witchDoctor >= 0 && cyborg >= 0 && Main.rand.NextBool(52))
		{
			dialogue.Add(MutantChat("WitchDoctorTruffleCyborg", Main.npc[witchDoctor].GivenName, Main.npc[truffle].GivenName, Main.npc[cyborg].GivenName));
		}
		if (partyGirl >= 0)
		{
			dialogue.Add(MutantChat("PartyGirl", Main.npc[partyGirl].GivenName));
		}
		int demoman = NPC.FindFirstNPC(38);
		if (demoman >= 0)
		{
			dialogue.Add(MutantChat("Demolitionist", Main.npc[demoman].GivenName));
		}
		int tavernkeep = NPC.FindFirstNPC(550);
		if (tavernkeep >= 0)
		{
			dialogue.Add(MutantChat("Tavernkeep", Main.npc[tavernkeep].GivenName));
		}
		int dyeTrader = NPC.FindFirstNPC(207);
		if (dyeTrader >= 0)
		{
			dialogue.Add(MutantChat("DyeTrader", Main.npc[dyeTrader].GivenName));
		}
		return Main.rand.Next(dialogue);
	}

	private static string GetLocalization(string line)
	{
		return Language.GetTextValue("Mods.Fargowiltas.NPCs.Mutant." + line);
	}

	public override void SetChatButtons(ref string button, ref string button2)
	{
		if (AnyHardmodeSummon)
		{
			button2 = GetLocalization("CycleShop");
		}
		else
		{
			shopNum = 1;
		}
		switch (shopNum)
		{
		case 1:
			button = GetLocalization("PreHM");
			break;
		case 2:
			button = GetLocalization("HM");
			break;
		default:
			button = GetLocalization("PostML");
			break;
		}
		if (AnyPostMLSummon)
		{
			if (shopNum >= 4)
			{
				shopNum = 1;
			}
		}
		else if (shopNum >= 3)
		{
			shopNum = 1;
		}
	}

	public override void OnChatButtonClicked(bool firstButton, ref string shopName)
	{
		if (firstButton)
		{
			switch (shopNum)
			{
			case 1:
				shopName = "Pre Hardmode Shop";
				break;
			case 2:
				shopName = "Hardmode Shop";
				break;
			default:
				shopName = "Post Moon Lord Shop";
				break;
			}
		}
		else if (!firstButton && AnyHardmodeSummon)
		{
			shopNum++;
		}
	}

	public override void AddShops()
	{
		NPCShop npcShop1 = new NPCShop(base.Type, "Pre Hardmode Shop").Add(new Item(ModContent.ItemType<Overloader>())
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 400000)
		}, Condition.InExpertMode).Add(new Item(ModContent.ItemType<ModeToggle>()));
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && ModContent.TryFind<ModItem>("FargowiltasSouls", "Masochist", out var masochist))
		{
			npcShop1.Add(new Item(masochist.Type)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 10000)
			});
		}
		foreach (MutantSummonInfo summon in Fargowiltas.summonTracker.SortedSummons)
		{
			if (summon.progression <= 7f)
			{
				npcShop1.Add(new Item(summon.itemId)
				{
					shopCustomPrice = Item.buyPrice(0, 0, 0, summon.price)
				}, new Condition("Mods.Fargowiltas.Conditions.DownedTheBoss", summon.downed));
			}
		}
		NPCShop npcShop2 = new NPCShop(base.Type, "Hardmode Shop");
		foreach (MutantSummonInfo summon in Fargowiltas.summonTracker.SortedSummons)
		{
			if (summon.progression > 7f && summon.progression <= 18f)
			{
				npcShop2.Add(new Item(summon.itemId)
				{
					shopCustomPrice = Item.buyPrice(0, 0, 0, summon.price)
				}, new Condition("Mods.Fargowiltas.Conditions.DownedTheBoss", summon.downed));
			}
		}
		NPCShop npcShop3 = new NPCShop(base.Type, "Post Moon Lord Shop");
		foreach (MutantSummonInfo summon in Fargowiltas.summonTracker.SortedSummons)
		{
			if (summon.progression > 18f)
			{
				npcShop3.Add(new Item(summon.itemId)
				{
					shopCustomPrice = Item.buyPrice(0, 0, 0, summon.price)
				}, new Condition("Mods.Fargowiltas.Conditions.DownedTheBoss", summon.downed));
			}
		}
		npcShop3.Add(new Item(ModContent.ItemType<AncientSeal>())
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 100000000)
		});
		npcShop1.Add(new Item(ModContent.ItemType<SiblingPylon>()), Condition.HappyEnoughToSellPylons, Condition.NpcIsPresent(ModContent.NPCType<Abominationn>()), Condition.NpcIsPresent(ModContent.NPCType<Deviantt>()));
		npcShop2.Add(new Item(ModContent.ItemType<SiblingPylon>()), Condition.HappyEnoughToSellPylons, Condition.NpcIsPresent(ModContent.NPCType<Abominationn>()), Condition.NpcIsPresent(ModContent.NPCType<Deviantt>()));
		npcShop3.Add(new Item(ModContent.ItemType<SiblingPylon>()), Condition.HappyEnoughToSellPylons, Condition.NpcIsPresent(ModContent.NPCType<Abominationn>()), Condition.NpcIsPresent(ModContent.NPCType<Deviantt>()));
		npcShop1.Register();
		npcShop2.Register();
		npcShop3.Register();
	}

	public override void ModifyActiveShop(string shopName, Item[] items)
	{
		if (!ModLoader.TryGetMod("FargowiltasSouls", out var fargoSouls))
		{
			return;
		}
		bool flag;
		switch (shopName.Replace($"{base.Mod.Name}/{DisplayName}/", ""))
		{
		case "Pre Hardmode Shop":
		case "Hardmode Shop":
		case "Post Moon Lord Shop":
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (!flag)
		{
			return;
		}
		foreach (Item item in items)
		{
			if (item != null && !item.IsAir)
			{
				float modifier = 1f;
				if ((bool)fargoSouls.Call("MutantDiscountCard"))
				{
					modifier -= 0.2f;
				}
				if ((bool)fargoSouls.Call("MutantPact"))
				{
					modifier -= 0.3f;
				}
				item.shopCustomPrice = (int)((float)(item.shopCustomPrice ?? item.GetStoreValue()) * modifier);
			}
		}
	}

	public override void TownNPCAttackStrength(ref int damage, ref float knockback)
	{
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedMutant"))
		{
			damage = 700;
			knockback = 7f;
		}
		else if (NPC.downedMoonlord)
		{
			damage = 250;
			knockback = 6f;
		}
		else if (Main.hardMode)
		{
			damage = 60;
			knockback = 5f;
		}
		else
		{
			damage = 20;
			knockback = 4f;
		}
	}

	public override void TownNPCAttackCooldown(ref int cooldown, ref int randExtraCooldown)
	{
		if (NPC.downedMoonlord)
		{
			cooldown = 1;
		}
		else if (Main.hardMode)
		{
			cooldown = 20;
			randExtraCooldown = 25;
		}
		else
		{
			cooldown = 30;
			randExtraCooldown = 30;
		}
	}

	public override void TownNPCAttackProj(ref int projType, ref int attackDelay)
	{
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedMutant") && ModContent.TryFind<ModProjectile>("FargowiltasSouls", "MutantSpearThrownFriendly", out var penetrator))
		{
			projType = penetrator.Type;
		}
		else if (NPC.downedMoonlord)
		{
			projType = ModContent.ProjectileType<PhantasmalEyeProjectile>();
		}
		else if (Main.hardMode)
		{
			projType = ModContent.ProjectileType<MechEyeProjectile>();
		}
		else
		{
			projType = ModContent.ProjectileType<EyeProjectile>();
		}
		attackDelay = 1;
	}

	public override void TownNPCAttackProjSpeed(ref float multiplier, ref float gravityCorrection, ref float randomOffset)
	{
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedMutant"))
		{
			multiplier = 25f;
			randomOffset = 0f;
		}
		else
		{
			multiplier = 12f;
			randomOffset = 2f;
		}
	}

	public override void HitEffect(NPC.HitInfo hit)
	{
		if (base.NPC.life <= 0)
		{
			for (int k = 0; k < 8; k++)
			{
				Dust.NewDust(base.NPC.position, base.NPC.width, base.NPC.height, 5, 2.5f * (float)hit.HitDirection, -2.5f, 0, default(Color), 0.8f);
			}
			if (!Main.dedServ)
			{
				Vector2 pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "MutantGore3").Type);
				pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "MutantGore2").Type);
				pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "MutantGore1").Type);
			}
		}
		else
		{
			for (int k = 0; (double)k < (double)(hit.Damage / base.NPC.lifeMax) * 50.0; k++)
			{
				Dust.NewDust(base.NPC.position, base.NPC.width, base.NPC.height, 5, hit.HitDirection, -1f, 0, default(Color), 0.6f);
			}
		}
	}

	public override bool PreDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
	{
		Texture2D texture = (Texture2D)TownNPCProfile().GetTextureNPCShouldUse(base.NPC);
		Rectangle rectangle = base.NPC.frame;
		if (base.NPC.IsShimmerVariant)
		{
			base.NPC.spriteDirection = base.NPC.direction;
			int height = 56;
			if (base.NPC.velocity.X == 0f)
			{
				SquirrelFrame = 0;
			}
			else
			{
				base.NPC.frameCounter += 1.0;
				if (base.NPC.frameCounter >= 5.0)
				{
					base.NPC.frameCounter = 0.0;
					SquirrelFrame++;
					if (SquirrelFrame >= 6)
					{
						SquirrelFrame = 1;
					}
				}
			}
			rectangle.X = 0;
			rectangle.Y = height * SquirrelFrame;
			rectangle.Width = texture.Width;
			rectangle.Height = height;
		}
		Vector2 origin2 = base.NPC.frame.Size() / 2f;
		SpriteEffects effects = ((base.NPC.spriteDirection >= 0) ? SpriteEffects.FlipHorizontally : SpriteEffects.None);
		spriteBatch.Draw(texture, base.NPC.Center - screenPos + new Vector2(0f, base.NPC.gfxOffY - 4f), rectangle, base.NPC.GetAlpha(drawColor), base.NPC.rotation, origin2, base.NPC.scale, effects, 0f);
		return false;
	}

	private static string MutantChat(string key, params object[] args)
	{
		return Language.GetTextValue("Mods.Fargowiltas.NPCs.Mutant.Chat." + key, args);
	}
}
