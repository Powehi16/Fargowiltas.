using System.Collections.Generic;
using System.Linq;
using Fargowiltas.Common.Configs;
using Fargowiltas.Content.Biomes;
using Fargowiltas.Items.Summons.Deviantt;
using Fargowiltas.Items.Tiles;
using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;
using Terraria.GameContent.Bestiary;
using Terraria.GameContent.Personalities;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.NPCs;

[AutoloadHead]
public class Deviantt : ModNPC
{
	private bool canSayDefeatQuote = true;

	private int defeatQuoteTimer = 900;

	private int trolling;

	public const string ShopName = "Shop";

	public override ITownNPCProfile TownNPCProfile()
	{
		return new DevianttProfile();
	}

	public override void SetStaticDefaults()
	{
		Main.npcFrameCount[base.NPC.type] = 23;
		NPCID.Sets.ExtraFramesCount[base.NPC.type] = 9;
		NPCID.Sets.AttackFrameCount[base.NPC.type] = 4;
		NPCID.Sets.DangerDetectRange[base.NPC.type] = 700;
		NPCID.Sets.AttackType[base.NPC.type] = 0;
		NPCID.Sets.AttackTime[base.NPC.type] = 90;
		NPCID.Sets.AttackAverageChance[base.NPC.type] = 30;
		NPCID.Sets.ShimmerTownTransform[base.NPC.type] = true;
		NPCID.Sets.ShimmerTownTransform[base.Type] = true;
		NPCID.Sets.NPCBestiaryDrawModifiers nPCBestiaryDrawModifiers = new NPCID.Sets.NPCBestiaryDrawModifiers();
		nPCBestiaryDrawModifiers.Velocity = -1f;
		nPCBestiaryDrawModifiers.Direction = -1;
		NPCID.Sets.NPCBestiaryDrawModifiers drawModifiers = nPCBestiaryDrawModifiers;
		NPCID.Sets.NPCBestiaryDrawOffset.Add(base.Type, drawModifiers);
		base.NPC.Happiness.SetBiomeAffection<SkyBiome>(AffectionLevel.Love);
		base.NPC.Happiness.SetBiomeAffection<JungleBiome>(AffectionLevel.Like);
		base.NPC.Happiness.SetBiomeAffection<SnowBiome>(AffectionLevel.Dislike);
		base.NPC.Happiness.SetBiomeAffection<DesertBiome>(AffectionLevel.Hate);
		base.NPC.Happiness.SetNPCAffection<Mutant>(AffectionLevel.Love);
		base.NPC.Happiness.SetNPCAffection<Abominationn>(AffectionLevel.Like);
		base.NPC.Happiness.SetNPCAffection(633, AffectionLevel.Dislike);
		base.NPC.Happiness.SetNPCAffection(369, AffectionLevel.Hate);
		NPCID.Sets.SpecificDebuffImmunity[base.Type][68] = true;
		NPCID.Sets.SpecificDebuffImmunity[base.Type][119] = true;
		NPCID.Sets.SpecificDebuffImmunity[base.Type][120] = true;
		NPCID.Sets.SpecificDebuffImmunity[base.Type][24] = true;
		base.NPC.AddDebuffImmunities(new List<int> { 68, 119, 120, 24 });
	}

	public override void SetBestiary(BestiaryDatabase database, BestiaryEntry bestiaryEntry)
	{
		bestiaryEntry.Info.AddRange(new IBestiaryInfoElement[2]
		{
			BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Biomes.Sky,
			new FlavorTextBestiaryInfoElement("Mods.Fargowiltas.Bestiary.Deviantt")
		});
	}

	public override void SetDefaults()
	{
		base.NPC.townNPC = true;
		base.NPC.friendly = true;
		base.NPC.width = 18;
		base.NPC.height = 40;
		base.NPC.aiStyle = 7;
		base.NPC.damage = 10;
		base.NPC.defense = (NPC.downedMoonlord ? 50 : 15);
		base.NPC.lifeMax = (NPC.downedMoonlord ? 2500 : 250);
		base.NPC.HitSound = SoundID.NPCHit1;
		base.NPC.DeathSound = SoundID.NPCDeath1;
		base.NPC.knockBackResist = 0.5f;
		base.AnimationType = 369;
		base.NPC.buffImmune[68] = true;
	}

	public override bool CanTownNPCSpawn(int numTownNPCs)
	{
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("DevianttAlive"))
		{
			return false;
		}
		bool value;
		return FargoServerConfig.Instance.Devi && !FargoGlobalNPC.AnyBossAlive() && ((FargoWorld.DownedBools.TryGetValue("rareEnemy", out value) && value) || (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("EternityMode")));
	}

	public override bool CanGoToStatue(bool toKingStatue)
	{
		return !toKingStatue;
	}

	public override void AI()
	{
		base.NPC.breath = 200;
		if (defeatQuoteTimer > 0)
		{
			defeatQuoteTimer--;
		}
		else
		{
			canSayDefeatQuote = false;
		}
		if (++trolling > 10800)
		{
			trolling = -Main.rand.Next(1800);
			DoALittleTrolling();
		}
	}

	private void DoALittleTrolling()
	{
		if (Main.netMode == 1 || FargoGlobalNPC.AnyBossAlive() || Main.npc.Any((NPC n) => n.active && n.damage > 0 && !n.friendly && base.NPC.Distance(n.Center) < 1200f) || base.NPC.life < base.NPC.lifeMax || base.NPC.ai[0] == 10f)
		{
			return;
		}
		Vector2 targetPos = default(Vector2);
		float targetDistance = 600f;
		for (int i = 0; i < Main.maxNPCs; i++)
		{
			if (Main.npc[i].active && Main.npc[i].friendly && Main.npc[i].townNPC && Main.npc[i].life == Main.npc[i].lifeMax && i != base.NPC.whoAmI)
			{
				TryUpdateTarget(Main.npc[i].Center);
			}
		}
		for (int i = 0; i < 255; i++)
		{
			if (Main.player[i].active && !Main.player[i].dead && !Main.player[i].ghost && Main.player[i].statLife == Main.player[i].statLifeMax2)
			{
				TryUpdateTarget(Main.player[i].Center);
			}
		}
		if (targetPos != default(Vector2))
		{
			float distanceRatio = targetDistance / 600f;
			targetPos.Y += 16f;
			targetPos.Y -= 60f * distanceRatio * distanceRatio;
			Vector2 vel = (8f + 12f * distanceRatio) * base.NPC.DirectionTo(targetPos);
			int type = (Main.rand.NextBool() ? 370 : 371);
			int p = Projectile.NewProjectile(base.NPC.GetSource_FromThis(), base.NPC.Center, vel, type, 0, 0f, Main.myPlayer);
			Main.projectile[p].npcProj = true;
			base.NPC.spriteDirection = (base.NPC.direction = ((!(targetPos.X < base.NPC.Center.X)) ? 1 : (-1)));
			base.NPC.ai[0] = 10f;
			base.NPC.ai[1] = NPCID.Sets.AttackTime[base.NPC.type] - 1;
			base.NPC.localAI[3] = 300f;
			base.NPC.netUpdate = true;
		}
		void TryUpdateTarget(Vector2 possibleTarget)
		{
			if (targetDistance > base.NPC.Distance(possibleTarget) && Collision.CanHitLine(base.NPC.Center, 0, 0, possibleTarget, 0, 0))
			{
				Tile tileBelow = Framing.GetTileSafely(possibleTarget + 32f * Vector2.UnitY);
				if (tileBelow.HasUnactuatedTile && Main.tileSolid[tileBelow.TileType] && !Main.tileSolidTop[tileBelow.TileType])
				{
					targetPos = possibleTarget;
					targetDistance = base.NPC.Distance(possibleTarget);
				}
			}
		}
	}

	public override List<string> SetNPCNameList()
	{
		string[] names = new string[13]
		{
			"Akira", "Remi", "Saku", "Seira", "Koi", "Elly", "Lori", "Calia", "Teri", "Artt",
			"Flan", "Shion", "Tewi"
		};
		return new List<string>(names);
	}

	public override string GetChat()
	{
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("EternityMode") && !(bool)ModLoader.GetMod("FargowiltasSouls").Call("GiftsReceived"))
		{
			ModLoader.GetMod("FargowiltasSouls").Call("GiveDevianttGifts");
			return Main.npcChatText = DeviChat("GiveGifts");
		}
		if (Main.notTheBeesWorld)
		{
			string text = DeviChat("NTB");
			int max = Main.rand.Next(10, 50);
			for (int i = 0; i < max; i++)
			{
				text += DeviChat("NTB" + Main.rand.Next(new string[6] { "HA", "HA", "HEE", "HOO", "HEH", "HAH" }));
			}
			return text + Language.GetTextValue("Mods.Fargowiltas.MessageInfo.Common.Exclamation");
		}
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && Main.rand.NextBool())
		{
			if ((bool)ModLoader.GetMod("FargowiltasSouls").Call("EridanusArmor"))
			{
				return DeviChat("EridanusArmor");
			}
			if ((bool)ModLoader.GetMod("FargowiltasSouls").Call("NekomiArmor"))
			{
				return DeviChat("NekomiArmor");
			}
		}
		if (base.NPC.homeless && canSayDefeatQuote && Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedDevi"))
		{
			canSayDefeatQuote = false;
			return DeviChat("Defeat");
		}
		if (Main.rand.NextBool())
		{
			if (Main.LocalPlayer.stinky)
			{
				return DeviChat("Stinky");
			}
			if (Main.LocalPlayer.loveStruck)
			{
				return DeviChat("LoveStruck", Main.rand.Next(2, 8));
			}
			if (Main.bloodMoon)
			{
				return DeviChat("BloodMoon");
			}
		}
		List<string> dialogue = (from item in Language.FindAll(Lang.CreateDialogFilter("Mods.Fargowiltas.NPCs.Deviantt.Chat.Normal"))
			select item.Value).ToList();
		dialogue.Add(DeviChat("Formattable1", Main.LocalPlayer.name));
		if (Main.hardMode)
		{
			dialogue.Add(DeviChat("HM"));
		}
		int mutant = NPC.FindFirstNPC(ModContent.NPCType<Mutant>());
		if (mutant != -1)
		{
			dialogue.Add(DeviChat("Mutant1", Main.npc[mutant].GivenName));
			dialogue.Add(DeviChat("Mutant2", Main.npc[mutant].GivenName));
		}
		int lumberjack = NPC.FindFirstNPC(ModContent.NPCType<LumberJack>());
		if (lumberjack != -1)
		{
			dialogue.Add(DeviChat("Lumber", Main.npc[lumberjack].GivenName));
		}
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("EternityMode"))
		{
			dialogue.Add(DeviChat("EternityMode"));
		}
		return Main.rand.Next(dialogue);
	}

	public override void SetChatButtons(ref string button, ref string button2)
	{
		button = Language.GetTextValue("LegacyInterface.28");
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("EternityMode"))
		{
			button2 = Language.GetTextValue("Mods.Fargowiltas.NPCs.Deviantt.HelpButton");
		}
	}

	public override void OnChatButtonClicked(bool firstButton, ref string shopName)
	{
		if (firstButton)
		{
			shopName = "Shop";
		}
		else if (Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("EternityMode"))
		{
			Main.npcChatText = Fargowiltas.dialogueTracker.GetDialogue(base.NPC.GivenName);
		}
	}

	public override void AddShops()
	{
		AddVanillaShop();
	}

	public void AddVanillaShop()
	{
		NPCShop npcShop = new NPCShop(base.Type);
		if (Fargowiltas.ModLoaded["FargowiltasSoulsDLC"] && ModContent.TryFind<ModItem>("FargowiltasSoulsDLC", "PandorasBox", out var pandorasBox))
		{
			npcShop.Add(new Item(pandorasBox.Type));
		}
		npcShop.Add(new Item(ModContent.ItemType<WormSnack>())
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 20000)
		}, new Condition("Mods.Fargowiltas.Conditions.WormDown", () => FargoWorld.DownedBools["worm"])).Add(new Item(ModContent.ItemType<PinkSlimeCrown>())
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 50000)
		}, new Condition("Mods.Fargowiltas.Conditions.PinkyDown", () => FargoWorld.DownedBools["pinky"])).Add(new Item(ModContent.ItemType<GoblinScrap>())
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 10000)
		}, new Condition("Mods.Fargowiltas.Conditions.ScoutDown", () => FargoWorld.DownedBools["goblinScout"]))
			.Add(new Item(ModContent.ItemType<Eggplant>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 20000)
			}, new Condition("Mods.Fargowiltas.Conditions.DoctorDown", () => FargoWorld.DownedBools["doctorBones"]))
			.Add(new Item(ModContent.ItemType<AttractiveOre>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 30000)
			}, new Condition("Mods.Fargowiltas.Conditions.MinerDown", () => FargoWorld.DownedBools["undeadMiner"]))
			.Add(new Item(ModContent.ItemType<HolyGrail>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 50000)
			}, new Condition("Mods.Fargowiltas.Conditions.TimDown", () => FargoWorld.DownedBools["tim"]))
			.Add(new Item(ModContent.ItemType<GnomeHat>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 50000)
			}, new Condition("Mods.Fargowiltas.Conditions.GnomeDown", () => FargoWorld.DownedBools["gnome"]))
			.Add(new Item(ModContent.ItemType<GoldenSlimeCrown>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 600000)
			}, new Condition("Mods.Fargowiltas.Conditions.GoldSlimeDown", () => FargoWorld.DownedBools["goldenSlime"]))
			.Add(new Item(ModContent.ItemType<SlimyLockBox>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.DungeonSlimeDown", () => NPC.downedBoss3 && FargoWorld.DownedBools["dungeonSlime"]))
			.Add(new Item(ModContent.ItemType<AthenianIdol>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 50000)
			}, new Condition("Mods.Fargowiltas.Conditions.MedusaDown", () => Main.hardMode && FargoWorld.DownedBools["medusa"]))
			.Add(new Item(ModContent.ItemType<ClownLicense>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 50000)
			}, new Condition("Mods.Fargowiltas.Conditions.ClownDown", () => Main.hardMode && FargoWorld.DownedBools["clown"]))
			.Add(new Item(ModContent.ItemType<HeartChocolate>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.NymphDown", () => FargoWorld.DownedBools["nymph"]))
			.Add(new Item(ModContent.ItemType<MothLamp>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.MothDown", () => Main.hardMode && FargoWorld.DownedBools["moth"]))
			.Add(new Item(ModContent.ItemType<DilutedRainbowMatter>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.RainbowSlimeDown", () => Main.hardMode && FargoWorld.DownedBools["rainbowSlime"]))
			.Add(new Item(ModContent.ItemType<CloudSnack>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.WyvernDown", () => Main.hardMode && FargoWorld.DownedBools["wyvern"]))
			.Add(new Item(ModContent.ItemType<RuneOrb>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 150000)
			}, new Condition("Mods.Fargowiltas.Conditions.RuneDown", () => Main.hardMode && FargoWorld.DownedBools["runeWizard"]))
			.Add(new Item(ModContent.ItemType<SuspiciousLookingChest>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, new Condition("Mods.Fargowiltas.Conditions.MimicDown", () => Main.hardMode && FargoWorld.DownedBools["mimic"]))
			.Add(new Item(ModContent.ItemType<HallowChest>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, new Condition("Mods.Fargowiltas.Conditions.MimicHallowDown", () => Main.hardMode && FargoWorld.DownedBools["mimicHallow"]))
			.Add(new Item(ModContent.ItemType<CorruptChest>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, new Condition("Mods.Fargowiltas.Conditions.MimicCorruptDown", () => Main.hardMode && (FargoWorld.DownedBools["mimicCorrupt"] || FargoWorld.DownedBools["mimicCrimson"])))
			.Add(new Item(ModContent.ItemType<CrimsonChest>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, new Condition("Mods.Fargowiltas.Conditions.MimicCrimsonDown", () => Main.hardMode && (FargoWorld.DownedBools["mimicCorrupt"] || FargoWorld.DownedBools["mimicCrimson"])))
			.Add(new Item(ModContent.ItemType<JungleChest>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, new Condition("Mods.Fargowiltas.Conditions.MimicJungleDown", () => Main.hardMode && FargoWorld.DownedBools["mimicJungle"]))
			.Add(new Item(ModContent.ItemType<CoreoftheFrostCore>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.IceGolemDown", () => Main.hardMode && FargoWorld.DownedBools["iceGolem"]))
			.Add(new Item(ModContent.ItemType<ForbiddenForbiddenFragment>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.SandDown", () => Main.hardMode && FargoWorld.DownedBools["sandElemental"]))
			.Add(new Item(ModContent.ItemType<DemonicPlushie>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.DevilDown", () => NPC.downedMechBossAny && FargoWorld.DownedBools["redDevil"]))
			.Add(new Item(ModContent.ItemType<SuspiciousLookingLure>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.BloodFishDown", () => FargoWorld.DownedBools["eyeFish"] || FargoWorld.DownedBools["zombieMerman"]))
			.Add(new Item(ModContent.ItemType<BloodUrchin>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.BloodEelDown", () => Main.hardMode && FargoWorld.DownedBools["bloodEel"]))
			.Add(new Item(ModContent.ItemType<HemoclawCrab>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.BloodGoblinDown", () => Main.hardMode && FargoWorld.DownedBools["goblinShark"]))
			.Add(new Item(ModContent.ItemType<BloodSushiPlatter>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 200000)
			}, new Condition("Mods.Fargowiltas.Conditions.BloodNautDown", () => Main.hardMode && FargoWorld.DownedBools["dreadnautilus"]))
			.Add(new Item(ModContent.ItemType<ShadowflameIcon>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.SummonerDown", () => Main.hardMode && NPC.downedGoblins && FargoWorld.DownedBools["goblinSummoner"]))
			.Add(new Item(ModContent.ItemType<PirateFlag>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 150000)
			}, new Condition("Mods.Fargowiltas.Conditions.PirateDown", () => Main.hardMode && NPC.downedPirates && FargoWorld.DownedBools["pirateCaptain"]))
			.Add(new Item(ModContent.ItemType<Pincushion>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 150000)
			}, new Condition("Mods.Fargowiltas.Conditions.NailheadDown", () => NPC.downedPlantBoss && FargoWorld.DownedBools["nailhead"]))
			.Add(new Item(ModContent.ItemType<MothronEgg>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 150000)
			}, new Condition("Mods.Fargowiltas.Conditions.MothronDown", () => NPC.downedMechBoss1 && NPC.downedMechBoss2 && NPC.downedMechBoss3 && FargoWorld.DownedBools["mothron"]))
			.Add(new Item(ModContent.ItemType<LeesHeadband>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 150000)
			}, new Condition("Mods.Fargowiltas.Conditions.LeeDown", () => NPC.downedPlantBoss && FargoWorld.DownedBools["boneLee"]))
			.Add(new Item(ModContent.ItemType<GrandCross>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 150000)
			}, new Condition("Mods.Fargowiltas.Conditions.PaladinDown", () => NPC.downedPlantBoss && FargoWorld.DownedBools["paladin"]))
			.Add(new Item(ModContent.ItemType<AmalgamatedSkull>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, new Condition("Mods.Fargowiltas.Conditions.SkeleGunDown", () => NPC.downedPlantBoss && FargoWorld.DownedBools["skeletonGun"]))
			.Add(new Item(ModContent.ItemType<AmalgamatedSpirit>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, new Condition("Mods.Fargowiltas.Conditions.SkeleMagesDown", () => NPC.downedPlantBoss && FargoWorld.DownedBools["skeletonMage"]))
			.Add(new Item(ModContent.ItemType<SiblingPylon>()), Condition.HappyEnoughToSellPylons, Condition.NpcIsPresent(ModContent.NPCType<Mutant>()), Condition.NpcIsPresent(ModContent.NPCType<Abominationn>()));
		npcShop.Register();
	}

	public override void ModifyActiveShop(string shopName, Item[] items)
	{
	}

	public override void TownNPCAttackStrength(ref int damage, ref float knockback)
	{
		if (NPC.downedMoonlord)
		{
			damage = 80;
			knockback = 4f;
		}
		else if (Main.hardMode)
		{
			damage = 40;
			knockback = 4f;
		}
		else
		{
			damage = 20;
			knockback = 2f;
		}
	}

	public override void TownNPCAttackCooldown(ref int cooldown, ref int randExtraCooldown)
	{
		cooldown = (NPC.downedMoonlord ? 1 : 30);
		if (!NPC.downedMoonlord)
		{
			randExtraCooldown = 30;
		}
	}

	public override void TownNPCAttackProj(ref int projType, ref int attackDelay)
	{
		projType = (NPC.downedMoonlord ? ModContent.ProjectileType<FakeHeartMarkDeviantt>() : ModContent.ProjectileType<FakeHeartDeviantt>());
		attackDelay = 1;
	}

	public override void TownNPCAttackProjSpeed(ref float multiplier, ref float gravityCorrection, ref float randomOffset)
	{
		multiplier = 10f;
		randomOffset = 0f;
	}

	public override void HitEffect(NPC.HitInfo hit)
	{
		if (base.NPC.life <= 0)
		{
			for (int k = 0; k < 8; k++)
			{
				Dust.NewDust(base.NPC.position, base.NPC.width, base.NPC.height, 5, 2.5f * (float)hit.HitDirection, -2.5f, 0, default(Color), 0.8f);
			}
			if (!Main.dedServ)
			{
				Vector2 pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "DevianttGore3").Type);
				pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "DevianttGore2").Type);
				pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "DevianttGore1").Type);
			}
		}
		else
		{
			for (int k = 0; (double)k < (double)(hit.Damage / base.NPC.lifeMax) * 50.0; k++)
			{
				Dust.NewDust(base.NPC.position, base.NPC.width, base.NPC.height, 5, hit.HitDirection, -1f, 0, default(Color), 0.6f);
			}
		}
	}

	public override void OnKill()
	{
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && ModContent.TryFind<ModNPC>("FargowiltasSouls", "CosmosChampion", out var cosmosChamp) && NPC.AnyNPCs(cosmosChamp.Type))
		{
			Item.NewItem(base.NPC.GetSource_Loot(), base.NPC.Hitbox, ModContent.ItemType<WalkingRick>());
		}
	}

	public override bool PreDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
	{
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && !(bool)ModLoader.GetMod("FargowiltasSouls").Call("GiftsReceived"))
		{
			Texture2D texture = (Texture2D)TownNPCProfile().GetTextureNPCShouldUse(base.NPC);
			Rectangle rectangle = base.NPC.frame;
			Vector2 origin2 = rectangle.Size() / 2f;
			SpriteEffects effects = ((base.NPC.spriteDirection >= 0) ? SpriteEffects.FlipHorizontally : SpriteEffects.None);
			Color color26 = Main.DiscoColor;
			color26.A = 0;
			float scale = ((float)(int)Main.mouseTextColor / 200f - 0.35f) * 0.5f + 1f;
			scale *= base.NPC.scale;
			Main.EntitySpriteDraw(texture, base.NPC.Center - Main.screenPosition + new Vector2(0f, base.NPC.gfxOffY - 4f), rectangle, color26, base.NPC.rotation, origin2, scale, effects);
		}
		return true;
	}

	private static string DeviChat(string key, params object[] args)
	{
		return Language.GetTextValue("Mods.Fargowiltas.NPCs.Deviantt.Chat." + key, args);
	}
}
