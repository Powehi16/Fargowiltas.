namespace Fargowiltas.NPCs;

public enum SquirrelSellType
{
	SoldBySquirrel,
	SomeMaterialsSold,
	CraftableMaterialsSold,
	SoldAtThirtyStack,
	End
}
