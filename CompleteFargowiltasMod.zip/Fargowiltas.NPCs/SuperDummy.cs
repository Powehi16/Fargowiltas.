using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.NPCs;

public class SuperDummy : ModNPC
{
	public override void SetStaticDefaults()
	{
		NPCID.Sets.NPCBestiaryDrawModifiers nPCBestiaryDrawModifiers = new NPCID.Sets.NPCBestiaryDrawModifiers();
		nPCBestiaryDrawModifiers.Hide = true;
		NPCID.Sets.NPCBestiaryDrawModifiers bestiaryData = nPCBestiaryDrawModifiers;
		NPCID.Sets.NPCBestiaryDrawOffset.Add(base.Type, bestiaryData);
	}

	public override void SetDefaults()
	{
		base.NPC.CloneDefaults(488);
		base.NPC.lifeMax = 1000000;
		base.NPC.aiStyle = -1;
		base.NPC.width = 28;
		base.NPC.height = 50;
		base.NPC.immortal = false;
		base.NPC.npcSlots = 0f;
		base.NPC.dontCountMe = true;
	}

	public override bool? DrawHealthBar(byte hbPosition, ref float scale, ref Vector2 position)
	{
		return false;
	}

	public override void OnSpawn(IEntitySource source)
	{
		base.NPC.life = (base.NPC.lifeMax = 1000000);
	}

	public override void AI()
	{
		base.NPC.life = (base.NPC.lifeMax = 1000000);
		if (FargoGlobalNPC.AnyBossAlive())
		{
			base.NPC.life = 0;
			base.NPC.HitEffect();
			base.NPC.SimpleStrikeNPC(int.MaxValue, 0, crit: false, 0f, null, damageVariation: false, 0f, noPlayerInteraction: true);
		}
	}

	public override bool CheckDead()
	{
		return false;
	}
}
