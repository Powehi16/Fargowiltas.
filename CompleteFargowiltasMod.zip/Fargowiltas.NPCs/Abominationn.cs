using System.Collections.Generic;
using System.Linq;
using Fargowiltas.Common.Configs;
using Fargowiltas.Content.Biomes;
using Fargowiltas.Items.Summons.Abom;
using Fargowiltas.Items.Summons.Deviantt;
using Fargowiltas.Items.Tiles;
using Fargowiltas.Items.Vanity;
using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent.Bestiary;
using Terraria.GameContent.Personalities;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.NPCs;

[AutoloadHead]
public class Abominationn : ModNPC
{
	private bool canSayDefeatQuote = true;

	private bool canSayMutantShimmerQuote = false;

	private int defeatQuoteTimer = 900;

	public const string ShopName = "Shop";

	public override void SetStaticDefaults()
	{
		Main.npcFrameCount[base.NPC.type] = 25;
		NPCID.Sets.ExtraFramesCount[base.NPC.type] = 9;
		NPCID.Sets.AttackFrameCount[base.NPC.type] = 4;
		NPCID.Sets.DangerDetectRange[base.NPC.type] = 700;
		NPCID.Sets.AttackType[base.NPC.type] = 0;
		NPCID.Sets.AttackTime[base.NPC.type] = 90;
		NPCID.Sets.AttackAverageChance[base.NPC.type] = 30;
		NPCID.Sets.HatOffsetY[base.NPC.type] = 2;
		NPCID.Sets.NPCBestiaryDrawModifiers nPCBestiaryDrawModifiers = new NPCID.Sets.NPCBestiaryDrawModifiers();
		nPCBestiaryDrawModifiers.Velocity = -1f;
		nPCBestiaryDrawModifiers.Direction = -1;
		NPCID.Sets.NPCBestiaryDrawModifiers drawModifiers = nPCBestiaryDrawModifiers;
		NPCID.Sets.NPCBestiaryDrawOffset.Add(base.Type, drawModifiers);
		base.NPC.Happiness.SetBiomeAffection<SkyBiome>(AffectionLevel.Love);
		base.NPC.Happiness.SetBiomeAffection<OceanBiome>(AffectionLevel.Like);
		base.NPC.Happiness.SetBiomeAffection<DungeonBiome>(AffectionLevel.Dislike);
		base.NPC.Happiness.SetNPCAffection<Mutant>(AffectionLevel.Love);
		base.NPC.Happiness.SetNPCAffection<Deviantt>(AffectionLevel.Like);
		base.NPC.Happiness.SetNPCAffection(18, AffectionLevel.Hate);
		base.NPC.AddDebuffImmunities(new List<int> { 68 });
	}

	public override void SetBestiary(BestiaryDatabase database, BestiaryEntry bestiaryEntry)
	{
		bestiaryEntry.Info.AddRange(new IBestiaryInfoElement[2]
		{
			BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Biomes.Sky,
			new FlavorTextBestiaryInfoElement("Mods.Fargowiltas.Bestiary.Abominationn")
		});
	}

	public override void SetDefaults()
	{
		base.NPC.townNPC = true;
		base.NPC.friendly = true;
		base.NPC.width = 40;
		base.NPC.height = 40;
		base.NPC.aiStyle = 7;
		base.NPC.damage = 10;
		base.NPC.defense = (NPC.downedMoonlord ? 50 : 15);
		base.NPC.lifeMax = (NPC.downedMoonlord ? 5000 : 250);
		base.NPC.HitSound = SoundID.NPCHit1;
		base.NPC.DeathSound = SoundID.NPCDeath1;
		base.NPC.knockBackResist = 0.5f;
		base.AnimationType = 22;
		base.NPC.buffImmune[68] = true;
	}

	public override bool CanTownNPCSpawn(int numTownNPCs)
	{
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && ((bool)ModLoader.GetMod("FargowiltasSouls").Call("MutantAlive") || (bool)ModLoader.GetMod("FargowiltasSouls").Call("AbomAlive")))
		{
			return false;
		}
		return FargoServerConfig.Instance.Abom && NPC.downedGoblins && !FargoGlobalNPC.AnyBossAlive();
	}

	public override bool CanGoToStatue(bool toKingStatue)
	{
		return toKingStatue;
	}

	public override void AI()
	{
		base.NPC.breath = 200;
		if (defeatQuoteTimer > 0)
		{
			defeatQuoteTimer--;
		}
		else
		{
			canSayDefeatQuote = false;
		}
		int mutant = NPC.FindFirstNPC(ModContent.NPCType<Mutant>());
		if (mutant != -1 && !Main.npc[mutant].IsShimmerVariant)
		{
			canSayMutantShimmerQuote = true;
		}
	}

	public override List<string> SetNPCNameList()
	{
		string[] names = new string[12]
		{
			"Wilta", "Jack", "Harley", "Reaper", "Stevenn", "Doof", "Baroo", "Fergus", "Entev", "Catastrophe",
			"Bardo", "Betson"
		};
		return new List<string>(names);
	}

	public override string GetChat()
	{
		if (base.NPC.homeless && canSayDefeatQuote && Fargowiltas.ModLoaded["FargowiltasSouls"] && (bool)ModLoader.GetMod("FargowiltasSouls").Call("DownedAbom"))
		{
			canSayDefeatQuote = false;
			return AbomChat("Defeat");
		}
		int mutant = NPC.FindFirstNPC(ModContent.NPCType<Mutant>());
		if (mutant != -1 && Main.npc[mutant].IsShimmerVariant && canSayMutantShimmerQuote)
		{
			canSayMutantShimmerQuote = false;
			return AbomChat("MutantShimmer");
		}
		if (Fargowiltas.ModLoaded["FargowiltasSouls"] && Main.rand.NextBool(3) && (bool)ModLoader.GetMod("FargowiltasSouls").Call("StyxArmor"))
		{
			return AbomChat("StyxArmor");
		}
		List<string> dialogue = (from item in Language.FindAll(Lang.CreateDialogFilter("Mods.Fargowiltas.NPCs.Abominationn.Chat.Normal"))
			select item.Value).ToList();
		dialogue.Add(AbomChat("Formattable1", (!Main.hardMode) ? AbomChat("Formatter1PHM") : AbomChat("Formatter1HM")));
		if (Main.LocalPlayer.ZoneGraveyard)
		{
			dialogue.Add(AbomChat("Graveyard"));
		}
		int mechanic = NPC.FindFirstNPC(124);
		if (mechanic != -1)
		{
			dialogue.Add(AbomChat("Mechanic", Main.npc[mechanic].GivenName));
		}
		return Main.rand.Next(dialogue);
	}

	public override void SetChatButtons(ref string button, ref string button2)
	{
		button = Language.GetTextValue("LegacyInterface.28");
		button2 = Language.GetTextValue("Mods.Fargowiltas.NPCs.Abominationn.CancelEvent");
	}

	public override void OnChatButtonClicked(bool firstButton, ref string shopName)
	{
		if (firstButton)
		{
			shopName = "Shop";
			return;
		}
		if (Main.netMode == 1)
		{
			ModPacket netMessage = base.Mod.GetPacket();
			netMessage.Write((byte)6);
			netMessage.Send();
		}
		if (Fargowiltas.IsEventOccurring)
		{
			if (Main.netMode == 1)
			{
				ModPacket netMessage = base.Mod.GetPacket();
				netMessage.Write((byte)2);
				netMessage.Send();
			}
			Main.npcChatText = (Fargowiltas.TryClearEvents() ? AbomChat("Canceled") : AbomChat("CancelCD", FargoWorld.AbomClearCD / 60));
		}
		else
		{
			Main.npcChatText = AbomChat("NoEvent");
		}
	}

	public override void AddShops()
	{
		NPCShop npcShop = new NPCShop(base.Type).Add(new Item(ModContent.ItemType<PartyInvite>())
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 10000)
		}).Add(new Item(ModContent.ItemType<WeatherBalloon>())
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 20000)
		}).Add(new Item(ModContent.ItemType<Anemometer>())
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 30000)
		})
			.Add(new Item(ModContent.ItemType<ForbiddenScarab>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 30000)
			})
			.Add(new Item(ModContent.ItemType<SlimyBarometer>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 40000)
			})
			.Add(new Item(4271)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 50000)
			})
			.Add(new Item(361)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 60000)
			})
			.Add(new Item(ModContent.ItemType<MatsuriLantern>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			}, new Condition("Mods.Fargowiltas.Conditions.BossDown", () => FargoWorld.DownedBools["boss"]))
			.Add(new Item(602)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 150000)
			}, Condition.Hardmode)
			.Add(new Item(1315)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 200000)
			}, Condition.DownedPirates)
			.Add(new Item(ModContent.ItemType<PlunderedBooty>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 150000)
			}, new Condition("Mods.Fargowiltas.Conditions.DutchmanDown", () => NPC.downedPirates && FargoWorld.DownedBools["flyingDutchman"]))
			.Add(new Item(2767)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 200000)
			}, Condition.DownedMechBossAny)
			.Add(new Item(ModContent.ItemType<ForbiddenTome>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 50000)
			}, new Condition("Mods.Fargowiltas.Conditions.MageDown", () => FargoWorld.DownedBools["darkMage"] || NPC.downedMechBossAny))
			.Add(new Item(ModContent.ItemType<BatteredClub>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 150000)
			}, new Condition("Mods.Fargowiltas.Conditions.OgreDown", () => FargoWorld.DownedBools["ogre"] || NPC.downedGolemBoss))
			.Add(new Item(ModContent.ItemType<BetsyEgg>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 400000)
			}, new Condition("Mods.Fargowiltas.Conditions.BetsyDown", () => FargoWorld.DownedBools["betsy"]))
			.Add(new Item(1844)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 500000)
			}, Condition.DownedPumpking)
			.Add(new Item(ModContent.ItemType<HeadofMan>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 200000)
			}, new Condition("Mods.Fargowiltas.Conditions.HorsemanDown", () => FargoWorld.DownedBools["headlessHorseman"]))
			.Add(new Item(ModContent.ItemType<SpookyBranch>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 200000)
			}, Condition.DownedMourningWood)
			.Add(new Item(ModContent.ItemType<SuspiciousLookingScythe>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, Condition.DownedPumpking)
			.Add(new Item(1958)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 500000)
			}, Condition.DownedIceQueen)
			.Add(new Item(ModContent.ItemType<FestiveOrnament>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 200000)
			}, Condition.DownedEverscream)
			.Add(new Item(ModContent.ItemType<NaughtyList>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 200000)
			}, Condition.DownedSantaNK1)
			.Add(new Item(ModContent.ItemType<IceKingsRemains>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, Condition.DownedIceQueen)
			.Add(new Item(ModContent.ItemType<RunawayProbe>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 500000)
			}, Condition.DownedGolem)
			.Add(new Item(ModContent.ItemType<MartianMemoryStick>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 300000)
			}, Condition.DownedMartians)
			.Add(new Item(ModContent.ItemType<PillarSummon>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 750000)
			}, new Condition("Mods.Fargowiltas.Conditions.PillarsDown", () => NPC.downedTowers))
			.Add(new Item(ModContent.ItemType<AbominationnScythe>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 50000)
			}, new Condition("Mods.Fargowiltas.Conditions.PillarsDown", () => NPC.downedTowers))
			.Add(new Item(ModContent.ItemType<SiblingPylon>()), Condition.HappyEnoughToSellPylons, Condition.NpcIsPresent(ModContent.NPCType<Mutant>()), Condition.NpcIsPresent(ModContent.NPCType<Deviantt>()));
		npcShop.Register();
	}

	public override void TownNPCAttackStrength(ref int damage, ref float knockback)
	{
		damage = (NPC.downedMoonlord ? 150 : 20);
		knockback = (NPC.downedMoonlord ? 10f : 4f);
	}

	public override void TownNPCAttackCooldown(ref int cooldown, ref int randExtraCooldown)
	{
		cooldown = (NPC.downedMoonlord ? 1 : 30);
		if (!NPC.downedMoonlord)
		{
			randExtraCooldown = 30;
		}
	}

	public override void TownNPCAttackProj(ref int projType, ref int attackDelay)
	{
		projType = (NPC.downedMoonlord ? ModContent.ProjectileType<DeathScythe>() : 274);
		attackDelay = 1;
	}

	public override void TownNPCAttackProjSpeed(ref float multiplier, ref float gravityCorrection, ref float randomOffset)
	{
		multiplier = 12f;
		randomOffset = 2f;
	}

	public override void HitEffect(NPC.HitInfo hit)
	{
		if (base.NPC.life <= 0)
		{
			for (int k = 0; k < 8; k++)
			{
				Dust.NewDust(base.NPC.position, base.NPC.width, base.NPC.height, 5, 2.5f * (float)hit.HitDirection, -2.5f, 0, default(Color), 0.8f);
			}
			if (!Main.dedServ)
			{
				Vector2 pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "AbomGore3").Type);
				pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "AbomGore2").Type);
				pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "AbomGore1").Type);
			}
		}
		else
		{
			for (int k = 0; (double)k < (double)(hit.Damage / base.NPC.lifeMax) * 50.0; k++)
			{
				Dust.NewDust(base.NPC.position, base.NPC.width, base.NPC.height, 5, hit.HitDirection, -1f, 0, default(Color), 0.6f);
			}
		}
	}

	private static string AbomChat(string key, params object[] args)
	{
		return Language.GetTextValue("Mods.Fargowiltas.NPCs.Abominationn.Chat." + key, args);
	}
}
