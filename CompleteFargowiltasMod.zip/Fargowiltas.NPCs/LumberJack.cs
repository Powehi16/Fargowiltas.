using System.Collections.Generic;
using System.Linq;
using Fargowiltas.Common.Configs;
using Fargowiltas.Items.Tiles;
using Fargowiltas.Items.Vanity;
using Fargowiltas.Items.Weapons;
using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent;
using Terraria.GameContent.Bestiary;
using Terraria.GameContent.ItemDropRules;
using Terraria.GameContent.Personalities;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.NPCs;

[AutoloadHead]
public class LumberJack : ModNPC
{
	private bool dayOver;

	private bool nightOver;

	public const string ShopName = "Shop";

	public override ITownNPCProfile TownNPCProfile()
	{
		return new LumberJackProfile();
	}

	public override void SetStaticDefaults()
	{
		Main.npcFrameCount[base.NPC.type] = 25;
		NPCID.Sets.ExtraFramesCount[base.NPC.type] = 9;
		NPCID.Sets.AttackFrameCount[base.NPC.type] = 4;
		NPCID.Sets.DangerDetectRange[base.NPC.type] = 700;
		NPCID.Sets.AttackType[base.NPC.type] = 0;
		NPCID.Sets.AttackTime[base.NPC.type] = 90;
		NPCID.Sets.AttackAverageChance[base.NPC.type] = 30;
		NPCID.Sets.HatOffsetY[base.NPC.type] = 2;
		NPCID.Sets.ShimmerTownTransform[base.NPC.type] = true;
		NPCID.Sets.ShimmerTownTransform[base.Type] = true;
		NPCID.Sets.NPCBestiaryDrawModifiers nPCBestiaryDrawModifiers = new NPCID.Sets.NPCBestiaryDrawModifiers();
		nPCBestiaryDrawModifiers.Velocity = -1f;
		nPCBestiaryDrawModifiers.Direction = -1;
		NPCID.Sets.NPCBestiaryDrawModifiers drawModifiers = nPCBestiaryDrawModifiers;
		NPCID.Sets.NPCBestiaryDrawOffset.Add(base.Type, drawModifiers);
		base.NPC.Happiness.SetBiomeAffection<ForestBiome>(AffectionLevel.Love);
		base.NPC.Happiness.SetNPCAffection<Squirrel>(AffectionLevel.Like);
		base.NPC.Happiness.SetNPCAffection(20, AffectionLevel.Dislike);
		base.NPC.Happiness.SetNPCAffection(38, AffectionLevel.Hate);
	}

	public override void SetBestiary(BestiaryDatabase database, BestiaryEntry bestiaryEntry)
	{
		bestiaryEntry.Info.AddRange(new IBestiaryInfoElement[2]
		{
			BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Biomes.Surface,
			new FlavorTextBestiaryInfoElement("Mods.Fargowiltas.Bestiary.LumberJack")
		});
	}

	public override void SetDefaults()
	{
		base.NPC.townNPC = true;
		base.NPC.friendly = true;
		base.NPC.width = 40;
		base.NPC.height = 40;
		base.NPC.aiStyle = 7;
		base.NPC.damage = 10;
		base.NPC.defense = 15;
		base.NPC.lifeMax = 250;
		base.NPC.HitSound = SoundID.NPCHit1;
		base.NPC.DeathSound = SoundID.NPCDeath1;
		base.NPC.knockBackResist = 0.5f;
		base.AnimationType = 22;
	}

	public override bool CanTownNPCSpawn(int numTownNPCs)
	{
		bool down = default(bool);
		return FargoServerConfig.Instance.Lumber && FargoWorld.DownedBools.TryGetValue("lumberjack", out down) && down;
	}

	public static void OnTreeShake(On_WorldGen.orig_ShakeTree orig, int i, int j)
	{
		orig(i, j);
		if (!FargoServerConfig.Instance.Lumber || !Main.rand.NextBool(10) || FargoWorld.WoodChopped < 400 || (FargoWorld.DownedBools.TryGetValue("lumberjack", out var down) && down))
		{
			return;
		}
		WorldGen.GetTreeBottom(i, j, out var x, out var y);
		if (WorldGen.GetTreeType(Main.tile[x, y].TileType) != 0)
		{
			y--;
			while (y > 10 && Main.tile[x, y].HasTile && TileID.Sets.IsShakeable[Main.tile[x, y].TileType])
			{
				y--;
			}
			y++;
			if (WorldGen.IsTileALeafyTreeTop(x, y) && !Collision.SolidTiles(x - 2, x + 2, y - 2, y + 2))
			{
				FargoWorld.DownedBools["lumberjack"] = true;
				NPC.NewNPC(NPC.GetBossSpawnSource(Main.myPlayer), x * 16, y * 16, ModContent.NPCType<LumberJack>());
			}
		}
	}

	public override void Load()
	{
		On_WorldGen.ShakeTree += OnTreeShake;
	}

	public override bool CanGoToStatue(bool toKingStatue)
	{
		return toKingStatue;
	}

	public override void AI()
	{
		if (!Main.dayTime)
		{
			nightOver = true;
		}
		if (Main.dayTime)
		{
			dayOver = true;
		}
	}

	public override List<string> SetNPCNameList()
	{
		string[] names = new string[12]
		{
			"Griff", "Jack", "Bruce", "Larry", "Will", "Jerry", "Liam", "Stan", "Lee", "Woody",
			"Leif", "Paul"
		};
		return new List<string>(names);
	}

	public override string GetChat()
	{
		List<string> dialogue = (from item in Language.FindAll(Lang.CreateDialogFilter("Mods.Fargowiltas.NPCs.LumberJack.Chat.Normal"))
			select item.Value).ToList();
		int nurse = NPC.FindFirstNPC(18);
		if (nurse >= 0)
		{
			dialogue.Add(LumberChat("Nurse", Main.npc[nurse].GivenName));
		}
		Player player = Main.LocalPlayer;
		if (player.HeldItem.type == 5095)
		{
			dialogue.Add(LumberChat("LucyTheAxe"));
		}
		return Main.rand.Next(dialogue);
	}

	public override void SetChatButtons(ref string button, ref string button2)
	{
		button = Language.GetTextValue("LegacyInterface.28");
		button2 = Language.GetTextValue("Mods.Fargowiltas.NPCs.LumberJack.TreeTreasures");
	}

	public override void OnChatButtonClicked(bool firstButton, ref string shopName)
	{
		Player player = Main.LocalPlayer;
		if (firstButton)
		{
			shopName = "Shop";
		}
		else if (dayOver && nightOver)
		{
			string quote = "";
			if (player.ZoneDesert && !player.ZoneBeach)
			{
				quote = LumberChat("Desert");
				int itemType = Main.rand.Next(new int[2] { 2157, 2156 });
				player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 5);
				player.QuickSpawnItem(player.GetSource_OpenItem(276), 276, 100);
			}
			else if (player.ZoneJungle)
			{
				quote = LumberChat("Jungle");
				int itemType = Main.rand.Next(new int[4] { 3194, 3193, 3192, 2121 });
				player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 5);
				itemType = Main.rand.Next(new int[2] { 4292, 4294 });
				player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 5);
				player.QuickSpawnItem(player.GetSource_OpenItem(620), 620, 50);
			}
			else if (player.ZoneHallow)
			{
				quote = LumberChat("Hallow");
				int itemType;
				for (int i = 0; i < 5; i++)
				{
					itemType = Main.rand.Next(new int[4] { 2004, 4070, 4069, 4068 });
					player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType);
				}
				itemType = Main.rand.Next(new int[2] { 4297, 4288 });
				player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 5);
				player.QuickSpawnItem(player.GetSource_OpenItem(621), 621, 50);
				player.QuickSpawnItem(player.GetSource_OpenItem(4961), 4961);
			}
			else if (player.ZoneGlowshroom && Main.hardMode)
			{
				quote = LumberChat("GlowshroomHM");
				int itemType = Main.rand.Next(new int[2] { 2007, 2673 });
				player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 5);
				player.QuickSpawnItem(player.GetSource_OpenItem(183), 183, 50);
			}
			else if (player.ZoneCorrupt || player.ZoneCrimson)
			{
				quote = LumberChat("Evil");
				for (int i = 0; i < 5; i++)
				{
					int itemType = Main.rand.Next(new int[4] { 4289, 4284, 4285, 4296 });
					player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType);
				}
			}
			else if (player.ZoneSnow)
			{
				quote = LumberChat("Snow");
				int itemType = Main.rand.Next(new int[2] { 4286, 4295 });
				player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 5);
				player.QuickSpawnItem(player.GetSource_OpenItem(2503), 2503, 50);
			}
			else if (player.ZoneBeach)
			{
				quote = LumberChat("Beach");
				int itemType = Main.rand.Next(new int[2] { 4287, 4283 });
				player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 5);
				player.QuickSpawnItem(player.GetSource_OpenItem(4359), 4359, 5);
				player.QuickSpawnItem(player.GetSource_OpenItem(2504), 2504, 50);
			}
			else if (player.ZoneUnderworldHeight)
			{
				quote = LumberChat("Underworld");
				for (int i = 0; i < 5; i++)
				{
					player.QuickSpawnItem(player.GetSource_OpenItem(5215), 5215, 50);
					int itemType = Main.rand.Next(new int[3] { 4845, 4849, 4847 });
					player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType);
					itemType = Main.rand.Next(new int[2] { 5277, 5278 });
					player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType);
				}
			}
			else if (player.ZoneRockLayerHeight || player.ZoneDirtLayerHeight)
			{
				if (Main.rand.NextBool(2))
				{
					quote = LumberChat("DirtRockGem");
					for (int i = 0; i < 5; i++)
					{
						int itemType = Main.rand.Next(new int[7] { 182, 178, 181, 179, 177, 180, 999 });
						player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 3);
						itemType = Main.rand.Next(new int[14]
						{
							4836, 4837, 4831, 4834, 4835, 4833, 4832, 4844, 4838, 4843,
							4841, 4842, 4840, 4839
						});
						player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType);
					}
				}
				else
				{
					quote = LumberChat("DirtRockMouse");
					int itemType = 2003;
					player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 5);
				}
			}
			else
			{
				if (Main.dayTime)
				{
					if (Main.WindyEnoughForKiteDrops && Main.rand.NextBool(2))
					{
						quote = LumberChat("CommonDayTimeWindy");
						int itemType = 4361;
						player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType, 5);
					}
					else if (Main.rand.NextBool(3))
					{
						quote = LumberChat("CommonDayTimeButterfly");
						for (int i = 0; i < 5; i++)
						{
							int itemType = Main.rand.Next(new int[8] { 2001, 1994, 1995, 1996, 1998, 1999, 1997, 2000 });
							player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType);
						}
					}
					else if (Main.rand.NextBool(20))
					{
						quote = LumberChat("CommonDayTimeEucaluptusSap");
						player.QuickSpawnItem(player.GetSource_OpenItem(4366), 4366);
					}
					else
					{
						quote = LumberChat("CommonDayTimeCritter");
						for (int i = 0; i < 5; i++)
						{
							int itemType = Main.rand.Next(new int[6] { 2740, 2018, 3563, 2015, 2016, 2017 });
							player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType);
						}
					}
				}
				else
				{
					quote = LumberChat("CommonNightTime");
					player.QuickSpawnItem(player.GetSource_OpenItem(1992), 1992);
				}
				for (int i = 0; i < 5; i++)
				{
					int itemType = Main.rand.Next(new int[5] { 4291, 4293, 4282, 4290, 4009 });
					player.QuickSpawnItem(player.GetSource_OpenItem(itemType), itemType);
				}
				player.QuickSpawnItem(player.GetSource_OpenItem(9), 9, 50);
			}
			Main.npcChatText = quote;
			dayOver = false;
			nightOver = false;
		}
		else
		{
			Main.npcChatText = LumberChat("Rest");
		}
	}

	public override void AddShops()
	{
		NPCShop npcShop = new NPCShop(base.Type).Add(new Item(94)
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 5)
		}).Add(new Item(9)
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 10)
		}).Add(new Item(2503)
		{
			shopCustomPrice = Item.buyPrice(0, 0, 0, 10)
		})
			.Add(new Item(620)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 15)
			})
			.Add(new Item(2504)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 15)
			})
			.Add(new Item(619)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 15)
			})
			.Add(new Item(911)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 15)
			})
			.Add(new Item(5215)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 20)
			})
			.Add(new Item(621)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 20)
			}, Condition.Hardmode)
			.Add(new Item(1729)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 50)
			}, Condition.DownedPumpking)
			.Add(new Item(276)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 10)
			})
			.Add(new Item(4564)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 10)
			})
			.Add(new Item(832)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 10000)
			})
			.Add(new Item(ModContent.ItemType<LumberjackMask>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 10000)
			})
			.Add(new Item(ModContent.ItemType<LumberjackBody>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 10000)
			})
			.Add(new Item(ModContent.ItemType<LumberjackPants>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 10000)
			})
			.Add(new Item(ModContent.ItemType<global::Fargowiltas.Items.Weapons.LumberJaxe>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 10000)
			})
			.Add(new Item(3198)
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 100000)
			})
			.Add(new Item(ModContent.ItemType<WoodenToken>())
			{
				shopCustomPrice = Item.buyPrice(0, 0, 0, 10000)
			});
		npcShop.Register();
	}

	public override void ModifyActiveShop(string shopName, Item[] items)
	{
	}

	public override void TownNPCAttackStrength(ref int damage, ref float knockback)
	{
		damage = 20;
		knockback = 4f;
	}

	public override void TownNPCAttackCooldown(ref int cooldown, ref int randExtraCooldown)
	{
		cooldown = 30;
		randExtraCooldown = 30;
	}

	public override void TownNPCAttackProj(ref int projType, ref int attackDelay)
	{
		projType = ModContent.ProjectileType<global::Fargowiltas.Projectiles.LumberJaxe>();
		attackDelay = 1;
	}

	public override void TownNPCAttackProjSpeed(ref float multiplier, ref float gravityCorrection, ref float randomOffset)
	{
		multiplier = 12f;
		randomOffset = 2f;
	}

	public override void OnKill()
	{
		FargoWorld.DownedBools["lumberjack"] = true;
	}

	public override void ModifyNPCLoot(NPCLoot npcLoot)
	{
		npcLoot.Add(ItemDropRule.Common(ModContent.ItemType<LumberHat>(), 3));
	}

	public override void HitEffect(NPC.HitInfo hit)
	{
		if (base.NPC.life <= 0)
		{
			for (int k = 0; k < 8; k++)
			{
				Dust.NewDust(base.NPC.position, base.NPC.width, base.NPC.height, 5, 2.5f * (float)hit.HitDirection, -2.5f, 0, default(Color), 0.8f);
			}
			if (!Main.dedServ)
			{
				Vector2 pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "LumberGore3").Type);
				pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "LumberGore2").Type);
				pos = base.NPC.position + new Vector2(Main.rand.Next(base.NPC.width - 8), Main.rand.Next(base.NPC.height / 2));
				Gore.NewGore(base.NPC.GetSource_Death(), pos, base.NPC.velocity, ModContent.Find<ModGore>("Fargowiltas", "LumberGore1").Type);
			}
		}
		else
		{
			for (int k = 0; (double)k < (double)(hit.Damage / base.NPC.lifeMax) * 50.0; k++)
			{
				Dust.NewDust(base.NPC.position, base.NPC.width, base.NPC.height, 5, hit.HitDirection, -1f, 0, default(Color), 0.6f);
			}
		}
	}

	private static string LumberChat(string key, params object[] args)
	{
		return Language.GetTextValue("Mods.Fargowiltas.NPCs.LumberJack.Chat." + key, args);
	}
}
