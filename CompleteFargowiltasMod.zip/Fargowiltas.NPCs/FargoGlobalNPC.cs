using System;
using System.Collections.Generic;
using System.Linq;
using Fargowiltas.Common.Configs;
using Fargowiltas.Content.Buffs;
using Fargowiltas.Items.Ammos;
using Fargowiltas.Items.Explosives;
using Fargowiltas.Items.Summons.Deviantt;
using Fargowiltas.Items.Summons.SwarmSummons.Energizers;
using Fargowiltas.Items.Tiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Chat;
using Terraria.DataStructures;
using Terraria.GameContent.Events;
using Terraria.GameContent.ItemDropRules;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.Utilities;

namespace Fargowiltas.NPCs;

public class FargoGlobalNPC : GlobalNPC
{
	internal static int[] Bosses = new int[29]
	{
		50, 4, 266, 222, 35, 657, 134, 127, 125, 126,
		262, 245, 370, 636, 439, 398, 395, 327, 345, 551,
		577, 243, 541, 290, 344, 325, 346, 315, 491
	};

	public static int LastWoFIndex = -1;

	public static int WoFDirection = 0;

	internal bool PillarSpawn = true;

	internal bool SwarmActive;

	internal bool PandoraActive;

	internal bool NoLoot = false;

	public static int eaterBoss = -1;

	public static int brainBoss = -1;

	public static int plantBoss = -1;

	public static int beeBoss = -1;

	public bool FirstFrame = true;

	public static int boss = -1;

	public override bool InstancePerEntity => true;

	public override bool CanHitNPC(NPC npc, NPC target)
	{
		if (target.dontTakeDamage && target.type == ModContent.NPCType<Squirrel>())
		{
			return false;
		}
		if (target.friendly && FargoServerConfig.Instance.SaferBoundNPCs && (target.type == 105 || target.type == 123 || target.type == 106 || target.type == 579 || target.type == 589))
		{
			return false;
		}
		return base.CanHitNPC(npc, target);
	}

	public override bool PreAI(NPC npc)
	{
		if (FirstFrame)
		{
			FirstFrame = false;
			FargoServerConfig config = FargoServerConfig.Instance;
			if ((config.EnemyHealth != 1f || config.BossHealth != 1f) && !npc.townNPC && !npc.CountsAsACritter && npc.life > 10)
			{
				if (config.BossHealth > config.EnemyHealth && (npc.boss || npc.type == 13 || npc.type == 14 || npc.type == 15 || (config.BossApplyToAllWhenAlive && AnyBossAlive())))
				{
					npc.lifeMax = (int)Math.Round((float)npc.lifeMax * config.BossHealth);
				}
				else
				{
					npc.lifeMax = (int)Math.Round((float)npc.lifeMax * config.EnemyHealth);
				}
				npc.life = npc.lifeMax;
			}
		}
		if (npc.boss)
		{
			boss = npc.whoAmI;
		}
		if (npc.townNPC && npc.homeTileX == -1 && npc.homeTileY == -1 && WorldGen.TownManager.HasRoom(npc.type, out var homePoint) && homePoint.X > 0 && homePoint.Y > 0)
		{
			int x = homePoint.X;
			int y = homePoint.Y - 2;
			WorldGen.moveRoom(x, y, npc.whoAmI);
		}
		switch (npc.type)
		{
		case 13:
			eaterBoss = npc.whoAmI;
			break;
		case 266:
			brainBoss = npc.whoAmI;
			break;
		case 262:
			plantBoss = npc.whoAmI;
			break;
		case 222:
			beeBoss = npc.whoAmI;
			break;
		case 439:
			if (npc.ai[0] == -1f && npc.ai[1] == 1f && !Main.npc.Any((NPC n) => n.active && n.type == 437 && npc.Distance(n.Center) < 400f))
			{
				npc.ai[1] = 360f;
				npc.netUpdate = true;
			}
			break;
		case 398:
			if (npc.ai[0] == 2f)
			{
				int skipPoint = 540;
				if (npc.ai[1] < (float)skipPoint && npc.ai[1] % 60f == 30f && NPC.CountNPCS(npc.type) > 1)
				{
					npc.ai[1] = skipPoint;
					npc.netUpdate = true;
				}
			}
			break;
		}
		return true;
	}

	public override void AI(NPC npc)
	{
		if (FargoWorld.OverloadMartians && npc.type == 395 && npc.dontTakeDamage)
		{
			npc.dontTakeDamage = false;
		}
	}

	public override void PostAI(NPC npc)
	{
		if (SwarmActive && npc.type == 245)
		{
			npc.dontTakeDamage = false;
		}
	}

	public override void ModifyShop(NPCShop shop)
	{
		Condition angler5 = new Condition("Mods.Fargowiltas.Conditions.Angler5", () => Main.LocalPlayer.anglerQuestsFinished >= 5);
		Condition angler10 = new Condition("Mods.Fargowiltas.Conditions.Angler10", () => Main.LocalPlayer.anglerQuestsFinished >= 10);
		Condition angler15 = new Condition("Mods.Fargowiltas.Conditions.Angler15", () => Main.LocalPlayer.anglerQuestsFinished >= 15);
		Condition angler20 = new Condition("Mods.Fargowiltas.Conditions.Angler20", () => Main.LocalPlayer.anglerQuestsFinished >= 20);
		Condition angler25 = new Condition("Mods.Fargowiltas.Conditions.Angler25", () => Main.LocalPlayer.anglerQuestsFinished >= 25);
		Condition angler30 = new Condition("Mods.Fargowiltas.Conditions.Angler30", () => Main.LocalPlayer.anglerQuestsFinished >= 30);
		Condition InRockOrDirtLayerHeight = new Condition("Mods.Fargowiltas.Conditions.InRockOrDirtLayerHeight", () => Condition.InDirtLayerHeight.IsMet() || Condition.InRockLayerHeight.IsMet());
		if (!FargoServerConfig.Instance.NPCSales)
		{
			return;
		}
		switch (shop.NpcType)
		{
		case 208:
			if (BirthdayParty.PartyIsUp)
			{
				AddItem(3750);
			}
			break;
		case 54:
			AddItem(848, Item.buyPrice(0, 1));
			AddItem(866, Item.buyPrice(0, 1));
			AddItem(2367, -1, angler10);
			AddItem(2368, -1, angler15);
			AddItem(2369, -1, angler20);
			AddItem(134, Item.buyPrice(0, 0, 1));
			AddItem(ModContent.ItemType<UnsafeBlueBrickWall>(), Item.buyPrice(0, 0, 0, 25));
			AddItem(ModContent.ItemType<UnsafeBlueSlabWall>(), Item.buyPrice(0, 0, 0, 25));
			AddItem(ModContent.ItemType<UnsafeBlueTileWall>(), Item.buyPrice(0, 0, 0, 25));
			AddItem(137, Item.buyPrice(0, 0, 1));
			AddItem(ModContent.ItemType<UnsafeGreenBrickWall>(), Item.buyPrice(0, 0, 0, 25));
			AddItem(ModContent.ItemType<UnsafeGreenSlabWall>(), Item.buyPrice(0, 0, 0, 25));
			AddItem(ModContent.ItemType<UnsafeGreenTileWall>(), Item.buyPrice(0, 0, 0, 25));
			AddItem(139, Item.buyPrice(0, 0, 1));
			AddItem(ModContent.ItemType<UnsafePinkBrickWall>(), Item.buyPrice(0, 0, 0, 25));
			AddItem(ModContent.ItemType<UnsafePinkSlabWall>(), Item.buyPrice(0, 0, 0, 25));
			AddItem(ModContent.ItemType<UnsafePinkTileWall>(), Item.buyPrice(0, 0, 0, 25));
			AddItem(ModContent.ItemType<BrittleBone>(), -1, new Condition("Mods.Fargowiltas.Conditions.BrittleBone", () => Main.LocalPlayer.inventory.Any((Item i) => !i.IsAir && i.useAmmo == 154)));
			break;
		case 17:
			AddItem(2428, -1, angler5);
			AddItem(2374, -1, angler10);
			AddItem(2373, -1, angler10);
			AddItem(2375, -1, angler10);
			AddItem(3183, -1, angler10);
			AddItem(2360, -1, angler10);
			AddItem(2494, -1, null, new Condition[2]
			{
				angler10,
				Condition.Hardmode
			});
			AddItem(3032, -1, null, new Condition[2]
			{
				angler10,
				Condition.Hardmode
			});
			AddItem(3031, -1, null, new Condition[2]
			{
				angler10,
				Condition.Hardmode
			});
			AddItem(2422, -1, null, new Condition[2]
			{
				angler25,
				Condition.Hardmode
			});
			AddItem(2294, -1, null, new Condition[2]
			{
				angler30,
				Condition.Hardmode
			});
			AddItem(283, 3, new Condition("Mods.Fargowiltas.Conditions.Seeds", () => Main.LocalPlayer.inventory.Any((Item i) => !i.IsAir && i.useAmmo == AmmoID.Dart)));
			break;
		case 227:
			AddItem(1372, -1, Condition.InDungeon);
			AddItem(1375, -1, Condition.InDungeon);
			AddItem(1573, -1, Condition.InDungeon);
			AddItem(1420, -1, Condition.InDungeon);
			AddItem(1435, -1, Condition.InDungeon);
			AddItem(1426, -1, Condition.InDungeon);
			AddItem(1421, -1, Condition.InDungeon);
			AddItem(1500, -1, Condition.InDungeon);
			AddItem(1374, -1, Condition.InDungeon);
			AddItem(1425, -1, Condition.InDungeon);
			AddItem(1438, -1, Condition.InDungeon);
			AddItem(1441, -1, Condition.InDungeon);
			AddItem(1373, -1, Condition.InDungeon);
			AddItem(1433, -1, Condition.InDungeon);
			AddItem(1436, -1, Condition.InDungeon);
			AddItem(1434, -1, Condition.InDungeon);
			AddItem(1424, -1, Condition.InDungeon);
			AddItem(1419, -1, Condition.InDungeon);
			AddItem(2995, -1, Condition.InDungeon);
			AddItem(1422, -1, Condition.InDungeon);
			AddItem(1439, -1, Condition.InDungeon);
			AddItem(1502, -1, Condition.InDungeon);
			AddItem(1423, -1, Condition.InDungeon);
			AddItem(1437, -1, Condition.InDungeon);
			AddItem(1495, -1, InRockOrDirtLayerHeight);
			AddItem(1575, -1, InRockOrDirtLayerHeight);
			AddItem(1496, -1, InRockOrDirtLayerHeight);
			AddItem(1442, -1, InRockOrDirtLayerHeight);
			AddItem(1480, -1, InRockOrDirtLayerHeight);
			AddItem(1577, -1, InRockOrDirtLayerHeight);
			AddItem(1440, -1, InRockOrDirtLayerHeight);
			AddItem(1477, -1, InRockOrDirtLayerHeight);
			AddItem(1574, -1, InRockOrDirtLayerHeight);
			AddItem(1443, -1, InRockOrDirtLayerHeight);
			AddItem(1498, -1, InRockOrDirtLayerHeight);
			AddItem(1576, -1, InRockOrDirtLayerHeight);
			AddItem(1427, -1, InRockOrDirtLayerHeight);
			AddItem(1428, -1, InRockOrDirtLayerHeight);
			AddItem(1474, -1, InRockOrDirtLayerHeight);
			AddItem(1476, -1, Condition.InUnderworldHeight);
			AddItem(1475, -1, Condition.InUnderworldHeight);
			AddItem(1479, -1, Condition.InUnderworldHeight);
			AddItem(1542, -1, Condition.InUnderworldHeight);
			AddItem(1497, -1, Condition.InUnderworldHeight);
			AddItem(1538, -1, Condition.InUnderworldHeight);
			AddItem(1501, -1, Condition.InUnderworldHeight);
			AddItem(1541, -1, Condition.InUnderworldHeight);
			AddItem(1539, -1, Condition.InUnderworldHeight);
			AddItem(1540, -1, Condition.InUnderworldHeight);
			AddItem(1499, -1, Condition.InUnderworldHeight);
			AddItem(1478, -1, Condition.InUnderworldHeight);
			break;
		case 38:
			AddItem(ModContent.ItemType<BoomShuriken>(), Item.buyPrice(0, 0, 1, 25));
			AddItem(12, -1, Condition.Hardmode);
			AddItem(699, -1, Condition.Hardmode);
			AddItem(11, -1, Condition.Hardmode);
			AddItem(700, -1, Condition.Hardmode);
			AddItem(14, -1, Condition.Hardmode);
			AddItem(701, -1, Condition.Hardmode);
			AddItem(13, -1, Condition.Hardmode);
			AddItem(702, -1, Condition.Hardmode);
			AddItem(116, -1, Condition.DownedPlantera);
			AddItem(56, -1, Condition.DownedPlantera);
			AddItem(880, -1, Condition.DownedPlantera);
			AddItem(174, -1, Condition.DownedPlantera);
			AddItem(364, -1, Condition.DownedMoonLord);
			AddItem(1104, -1, Condition.DownedMoonLord);
			AddItem(365, -1, Condition.DownedMoonLord);
			AddItem(1105, -1, Condition.DownedMoonLord);
			AddItem(366, -1, Condition.DownedMoonLord);
			AddItem(1106, -1, Condition.DownedMoonLord);
			AddItem(947, -1, Condition.DownedMoonLord);
			break;
		case 228:
		{
			bool alreadySellsTable = false;
			foreach (NPCShop.Entry entry in shop.Entries)
			{
				if (!entry.Item.IsAir && entry.Item.type == 2999)
				{
					alreadySellsTable = true;
					break;
				}
			}
			if (!alreadySellsTable)
			{
				AddItem(2999, -1, Condition.DownedSkeletron);
			}
			break;
		}
		case 178:
			AddItem(782, -1, Condition.CorruptWorld);
			AddItem(784, -1, Condition.CrimsonWorld);
			break;
		case 207:
			AddItem(1115, -1, new Condition("Mods.Fargowiltas.Conditions.RedHusk", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["RedHusk"]));
			AddItem(1114, -1, new Condition("Mods.Fargowiltas.Conditions.OrangeBloodroot", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["OrangeBloodroot"]));
			AddItem(1110, -1, new Condition("Mods.Fargowiltas.Conditions.YellowMarigold", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["YellowMarigold"]));
			AddItem(1112, -1, new Condition("Mods.Fargowiltas.Conditions.LimeKelp", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["LimeKelp"]));
			AddItem(1108, -1, new Condition("Mods.Fargowiltas.Conditions.GreenMushroom", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["GreenMushroom"]));
			AddItem(1107, -1, new Condition("Mods.Fargowiltas.Conditions.TealMushroom", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["TealMushroom"]));
			AddItem(1116, -1, new Condition("Mods.Fargowiltas.Conditions.CyanHusk", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["CyanHusk"]));
			AddItem(1109, -1, new Condition("Mods.Fargowiltas.Conditions.SkyBlueFlower", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["SkyBlueFlower"]));
			AddItem(1111, -1, new Condition("Mods.Fargowiltas.Conditions.BlueBerries", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["BlueBerries"]));
			AddItem(1118, -1, new Condition("Mods.Fargowiltas.Conditions.PurpleMucos", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["PurpleMucos"]));
			AddItem(1117, -1, new Condition("Mods.Fargowiltas.Conditions.VioletHusk", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["VioletHusk"]));
			AddItem(1113, -1, new Condition("Mods.Fargowiltas.Conditions.PinkPricklyPear", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["PinkPricklyPear"]));
			AddItem(1119, -1, new Condition("Mods.Fargowiltas.Conditions.BlackInk", () => Main.LocalPlayer.GetModPlayer<FargoPlayer>().FirstDyeIngredients["BlackInk"]));
			break;
		case 20:
			AddItem(223, Item.buyPrice(0, 20), Condition.Hardmode);
			AddItem(208, Item.buyPrice(0, 10), Condition.Hardmode);
			AddItem(3385, Item.buyPrice(0, 5), Condition.Hardmode);
			AddItem(3386, Item.buyPrice(0, 5), Condition.Hardmode);
			AddItem(3387, Item.buyPrice(0, 5), Condition.Hardmode);
			AddItem(3388, Item.buyPrice(0, 5), Condition.Hardmode);
			break;
		case 108:
			AddItem(2209, -1, Condition.DownedGolem);
			break;
		case 229:
			AddItem(ModContent.ItemType<GoldenDippingVat>(), Item.buyPrice(0, 35), Condition.Hardmode);
			break;
		}
		void AddItem(int itemID, int customPrice = -1, Condition condition = null, Condition[] conditions = null)
		{
			if (condition != null)
			{
				conditions = new Condition[1] { condition };
			}
			if (conditions != null)
			{
				if (customPrice != -1)
				{
					shop.Add(new Item(itemID)
					{
						shopCustomPrice = customPrice
					}, conditions);
				}
				else
				{
					shop.Add(itemID, conditions);
				}
			}
			else if (customPrice != -1)
			{
				shop.Add(new Item(itemID)
				{
					shopCustomPrice = customPrice
				});
			}
			else
			{
				shop.Add(itemID);
			}
		}
	}

	public override void EditSpawnRate(Player player, ref int spawnRate, ref int maxSpawns)
	{
		FargoPlayer fargoPlayer = player.GetFargoPlayer();
		if (fargoPlayer.BattleCry)
		{
			spawnRate = (int)((double)spawnRate * 0.1);
			maxSpawns = (int)((float)maxSpawns * 10f);
		}
		if (fargoPlayer.CalmingCry)
		{
			float cryStrength = 1.15f;
			if (Main.hardMode)
			{
				cryStrength += 0.15f;
			}
			if (NPC.downedMechBossAny)
			{
				cryStrength += 0.15f;
			}
			if (NPC.downedPlantBoss)
			{
				cryStrength += 0.15f;
			}
			if (NPC.downedGolemBoss)
			{
				cryStrength += 0.15f;
			}
			if (NPC.downedAncientCultist)
			{
				cryStrength += 0.15f;
			}
			spawnRate = (int)((float)spawnRate * cryStrength);
			maxSpawns = (int)((float)maxSpawns * (1f / cryStrength));
		}
		if ((FargoWorld.OverloadGoblins || FargoWorld.OverloadPirates) && (double)player.position.X > Main.invasionX * 16.0 - 3000.0 && (double)player.position.X < Main.invasionX * 16.0 + 3000.0)
		{
			if (FargoWorld.OverloadGoblins)
			{
				spawnRate = (int)((double)spawnRate * 0.2);
				maxSpawns = (int)((float)maxSpawns * 10f);
			}
			else if (FargoWorld.OverloadPirates)
			{
				spawnRate = (int)((double)spawnRate * 0.2);
				maxSpawns = (int)((float)maxSpawns * 30f);
			}
		}
		if (FargoWorld.OverloadPumpkinMoon || FargoWorld.OverloadFrostMoon)
		{
			spawnRate = (int)((double)spawnRate * 0.2);
			maxSpawns = (int)((float)maxSpawns * 10f);
		}
		else if (FargoWorld.OverloadMartians)
		{
			spawnRate = (int)((double)spawnRate * 0.2);
			maxSpawns = (int)((float)maxSpawns * 30f);
		}
		if (AnyBossAlive() && FargoServerConfig.Instance.BossZen && player.Distance(Main.npc[boss].Center) < 6000f)
		{
			maxSpawns = 0;
		}
	}

	public override void EditSpawnPool(IDictionary<int, float> pool, NPCSpawnInfo spawnInfo)
	{
		Player player = Main.LocalPlayer;
		if (FargoWorld.OverloadGoblins && (double)player.position.X > Main.invasionX * 16.0 - 3000.0 && (double)player.position.X < Main.invasionX * 16.0 + 3000.0)
		{
			pool[471] = 1f;
			pool[111] = 3f;
			pool[26] = 5f;
			pool[29] = 3f;
			pool[28] = 5f;
			pool[27] = 5f;
			pool[73] = 3f;
		}
		else if (FargoWorld.OverloadPirates && (double)player.position.X > Main.invasionX * 16.0 - 3000.0 && (double)player.position.X < Main.invasionX * 16.0 + 3000.0)
		{
			if (NPC.CountNPCS(491) < 4)
			{
				pool[491] = 0.5f;
			}
			pool[252] = 2f;
			pool[216] = 1f;
			pool[215] = 3f;
			pool[213] = 5f;
			pool[214] = 4f;
			pool[212] = 5f;
		}
		else if (FargoWorld.OverloadPumpkinMoon)
		{
			pool[327] = 4f;
			pool[325] = 4f;
			pool[315] = 3f;
			pool[305] = 0.5f;
			pool[306] = 0.5f;
			pool[307] = 0.5f;
			pool[308] = 0.5f;
			pool[309] = 0.5f;
			pool[310] = 0.5f;
			pool[311] = 0.5f;
			pool[312] = 0.5f;
			pool[313] = 0.5f;
			pool[314] = 0.5f;
			pool[329] = 3f;
			pool[330] = 3f;
			pool[326] = 3f;
		}
		else if (FargoWorld.OverloadFrostMoon)
		{
			pool[345] = 5f;
			pool[344] = 5f;
			pool[346] = 5f;
			pool[338] = 1f;
			pool[339] = 1f;
			pool[340] = 1f;
			pool[342] = 2f;
			pool[350] = 2f;
			pool[348] = 3f;
			pool[347] = 3f;
			pool[352] = 2f;
			pool[343] = 4f;
			pool[341] = 2f;
			pool[351] = 4f;
		}
		else if (FargoWorld.OverloadMartians)
		{
			pool[395] = 1f;
			pool[391] = 3f;
			pool[390] = 2f;
			pool[520] = 3f;
			pool[388] = 2f;
			pool[389] = 1f;
			pool[386] = 2f;
			pool[383] = 2f;
			pool[382] = 1f;
			pool[385] = 1f;
			pool[381] = 1f;
		}
	}

	public override bool PreKill(NPC npc)
	{
		if (NoLoot)
		{
			return false;
		}
		if (Fargowiltas.SwarmActive && (npc.type == 1 || npc.type == 14 || npc.type == 15 || npc.type == 267 || (npc.type >= 213 && npc.type <= 215)))
		{
			return false;
		}
		if (SwarmActive && Fargowiltas.SwarmActive && Main.netMode != 1)
		{
			switch (npc.type)
			{
			case 50:
				Swarm(npc, 50, 1, 3318, 2489, ModContent.ItemType<EnergizerSlime>());
				break;
			case 4:
				Swarm(npc, 4, 5, 3319, 1360, ModContent.ItemType<EnergizerEye>());
				break;
			case 13:
				Swarm(npc, 13, 15, 3320, 1361, ModContent.ItemType<EnergizerWorm>());
				break;
			case 266:
				Swarm(npc, 266, 267, 3321, 1362, ModContent.ItemType<EnergizerBrain>());
				break;
			case 564:
				Swarm(npc, 564, -1, 3817, 3867, ModContent.ItemType<EnergizerDarkMage>());
				break;
			case 668:
				Swarm(npc, 668, -1, 5111, 5108, ModContent.ItemType<EnergizerDeer>());
				break;
			case 222:
				Swarm(npc, 222, 211, 3322, 1364, ModContent.ItemType<EnergizerBee>());
				break;
			case 35:
				Swarm(npc, 35, -1, 3323, 1363, ModContent.ItemType<EnergizerSkele>());
				break;
			case 113:
				Swarm(npc, 113, 115, 3324, 1365, ModContent.ItemType<EnergizerWall>());
				break;
			case 657:
				Swarm(npc, 657, 659, 4957, 4958, ModContent.ItemType<EnergizerQueenSlime>());
				break;
			case 134:
				Swarm(npc, 134, 139, 3325, 1366, ModContent.ItemType<EnergizerDestroy>());
				break;
			case 125:
				Swarm(npc, 125, -1, 3326, 1368, ModContent.ItemType<EnergizerTwins>());
				break;
			case 126:
				Swarm(npc, 126, -1, -1, 1369, -1);
				break;
			case 127:
				Swarm(npc, 127, -1, 3327, 1367, ModContent.ItemType<EnergizerPrime>());
				break;
			case 262:
				Swarm(npc, 262, 263, 3328, 1370, ModContent.ItemType<EnergizerPlant>());
				break;
			case 245:
				Swarm(npc, 245, 249, 3329, 1371, ModContent.ItemType<EnergizerGolem>());
				break;
			case 551:
				Swarm(npc, 551, 560, 3860, 3866, ModContent.ItemType<EnergizerBetsy>());
				break;
			case 370:
				Swarm(npc, 370, 372, 3330, 2589, ModContent.ItemType<EnergizerFish>());
				break;
			case 636:
				Swarm(npc, 636, -1, 4782, 4783, ModContent.ItemType<EnergizerEmpress>());
				break;
			case 439:
				Swarm(npc, 439, -1, 3331, 3357, ModContent.ItemType<EnergizerCultist>());
				break;
			case 398:
				Swarm(npc, 398, 400, 3332, 3595, ModContent.ItemType<EnergizerMoon>());
				break;
			case 68:
				Swarm(npc, 68, -1, -1, 1169, ModContent.ItemType<EnergizerDG>());
				break;
			}
			return false;
		}
		if (!PandoraActive)
		{
			return true;
		}
		return false;
	}

	public override void OnKill(NPC npc)
	{
		switch (npc.type)
		{
		case 227:
			if (NPC.AnyNPCs(398))
			{
				Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, ModContent.ItemType<EchPainting>());
			}
			break;
		case 576:
		case 577:
			if (!DD2Event.Ongoing)
			{
				if (Main.rand.NextBool(14))
				{
					Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, 3865);
				}
				Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, Main.rand.Next(new int[10] { 3809, 3810, 3811, 3812, 3823, 3835, 3836, 3852, 3854, 3856 }));
				Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, 73, Main.rand.Next(4, 7));
			}
			break;
		case 564:
		case 565:
			if (!DD2Event.Ongoing)
			{
				if (Main.rand.NextBool(14))
				{
					Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, 3864);
				}
				if (Main.rand.NextBool(10))
				{
					Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, Main.rand.NextBool() ? 3814 : 3815);
				}
				if (Main.rand.NextBool(6))
				{
					Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, Main.rand.Next(new int[2] { 3855, 3857 }));
				}
			}
			break;
		case 315:
			if (!Main.dayTime && !Main.pumpkinMoon && Main.rand.NextBool(10))
			{
				Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, 1857);
			}
			break;
		case 325:
			if (!Main.dayTime && !Main.pumpkinMoon)
			{
				Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, 1729, 30);
				IEntitySource source_Loot = npc.GetSource_Loot();
				Rectangle hitbox = npc.Hitbox;
				UnifiedRandom rand = Main.rand;
				int[] obj = new int[6] { 1829, 1831, 1835, 1837, 1845, 0 };
				obj[5] = (Main.expertMode ? 4444 : 1729);
				Item.NewItem(source_Loot, hitbox, rand.Next(obj));
			}
			break;
		case 327:
			if (!Main.dayTime && !Main.pumpkinMoon)
			{
				Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, Main.rand.Next(new int[8] { 1826, 1801, 1811, 1798, 1802, 1782, 1784, 4680 }));
			}
			break;
		case 344:
			if (!Main.dayTime && !Main.snowMoon)
			{
				Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, Main.rand.Next(new int[4] { 1928, 1916, 1930, 1871 }));
			}
			break;
		case 346:
			if (!Main.dayTime && !Main.snowMoon)
			{
				Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, Main.rand.Next(new int[2] { 1910, 1929 }));
			}
			break;
		case 345:
			if (!Main.dayTime && !Main.snowMoon)
			{
				Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, Main.rand.Next(new int[5] { 1931, 1946, 1947, 1959, 1914 }));
			}
			break;
		}
	}

	public override void ModifyNPCLoot(NPC npc, NPCLoot npcLoot)
	{
		switch (npc.type)
		{
		case 147:
		case 148:
		case 161:
		case 184:
		case 431:
			npcLoot.Add(ItemDropRule.OneFromOptions(20, 803, 804, 805));
			break;
		case 153:
		case 175:
		case 176:
		case 236:
		case 237:
			npcLoot.Add(ItemDropRule.ByCondition(new Conditions.IsHardmode(), ModContent.ItemType<JungleChest>(), 50));
			break;
		case 205:
			npcLoot.Add(ItemDropRule.ByCondition(new Conditions.IsHardmode(), ModContent.ItemType<JungleChest>(), 10));
			break;
		case 481:
			npcLoot.RemoveWhere((IItemDropRule rule) => rule is CommonDrop commonDrop && (commonDrop.itemId == 3187 || commonDrop.itemId == 3188 || commonDrop.itemId == 3189));
			npcLoot.Add(ItemDropRule.OneFromOptions(10, 3187, 3188, 3189));
			break;
		case 17:
			npcLoot.Add(ItemDropRule.Common(410, 8));
			npcLoot.Add(ItemDropRule.Common(411, 8));
			break;
		case 18:
			npcLoot.Add(ItemDropRule.Common(29, 5));
			break;
		case 38:
			npcLoot.Add(ItemDropRule.Common(167, 2, 5, 5));
			break;
		case 20:
			npcLoot.Add(ItemDropRule.Common(3093, 3));
			break;
		case 550:
			npcLoot.Add(ItemDropRule.Common(353, 2, 4, 4));
			break;
		case 209:
			npcLoot.Add(ItemDropRule.Common(1350, 4, 30, 30));
			break;
		case 54:
			npcLoot.Add(ItemDropRule.Common(1274, 20));
			break;
		case 124:
			npcLoot.Add(ItemDropRule.Common(530, 5, 40, 40));
			break;
		case 108:
			npcLoot.Add(ItemDropRule.Common(75, 5, 5, 5));
			break;
		case 441:
			npcLoot.Add(ItemDropRule.Common(73, 8, 10, 10));
			break;
		case 160:
			npcLoot.Add(ItemDropRule.Common(470, 8));
			break;
		case 369:
			npcLoot.Add(ItemDropRule.OneFromOptions(2, 2337, 2339, 2338));
			break;
		case 576:
		case 577:
			npcLoot.Add(ItemDropRule.Common(3817, 1, 20, 20));
			break;
		case 564:
		case 565:
			npcLoot.Add(ItemDropRule.Common(3817, 1, 5, 5));
			break;
		case 301:
			npcLoot.Add(ItemDropRule.Common(1774));
			break;
		case 333:
		case 334:
		case 335:
		case 336:
			npcLoot.Add(ItemDropRule.Common(1869));
			break;
		case 489:
			npcLoot.Add(ItemDropRule.OneFromOptions(200, 1827, 1825));
			break;
		case 109:
			npcLoot.Add(ItemDropRule.Common(1324));
			break;
		case 398:
			npcLoot.Add(ItemDropRule.Common(5001, 100));
			break;
		}
		base.ModifyNPCLoot(npc, npcLoot);
	}

	public override bool CheckDead(NPC npc)
	{
		if (npc.FindBuffIndex(ModContent.BuffType<WoodDrop>()) != -1)
		{
			Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, 9, Main.rand.Next(10, 30));
		}
		switch (npc.type)
		{
		case 439:
		{
			if (PillarSpawn)
			{
				break;
			}
			for (int i = 0; i < Main.maxNPCs; i++)
			{
				NPC npc2 = Main.npc[i];
				NPC.LunarApocalypseIsUp = false;
				if (npc2.type == 507 || npc2.type == 517 || npc2.type == 493 || npc2.type == 422)
				{
					NPC.TowerActiveSolar = true;
					npc2.active = false;
				}
				NPC.TowerActiveSolar = false;
			}
			break;
		}
		case 10:
		case 95:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "worm");
			break;
		case 576:
		case 577:
			FargoUtils.TryDowned("Abominationn", Color.Orange, "ogre");
			break;
		case 564:
		case 565:
			FargoUtils.TryDowned("Abominationn", Color.Orange, "darkMage");
			break;
		case 109:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "clown");
			break;
		case 1:
			if (npc.netID == -4)
			{
				FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "pinky");
			}
			break;
		case 44:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "undeadMiner");
			break;
		case 45:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "tim");
			break;
		case 52:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "doctorBones");
			break;
		case 85:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "mimic");
			break;
		case 87:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "wyvern");
			break;
		case 172:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "runeWizard");
			break;
		case 196:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "nymph");
			break;
		case 205:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "moth");
			break;
		case 244:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "rainbowSlime");
			break;
		case 290:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, NPC.downedPlantBoss, "rareEnemy", "paladin");
			break;
		case 480:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "medusa");
			break;
		case 243:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "iceGolem");
			break;
		case 541:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "sandElemental");
			break;
		case 463:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, NPC.downedPlantBoss, "rareEnemy", "nailhead");
			break;
		case 477:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, NPC.downedMechBoss1 && NPC.downedMechBoss2 && NPC.downedMechBoss3, "rareEnemy", "mothron");
			break;
		case 473:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "mimicCorrupt");
			break;
		case 475:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "mimicHallow");
			break;
		case 474:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "mimicCrimson");
			break;
		case 476:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "mimicJungle");
			break;
		case 471:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode && NPC.downedGoblins, "rareEnemy", "goblinSummoner");
			break;
		case 491:
			FargoUtils.TryDowned("Abominationn", Color.Orange, NPC.downedPirates, "flyingDutchman");
			break;
		case 71:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, NPC.downedBoss3, "rareEnemy", "dungeonSlime");
			break;
		case 216:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode && NPC.downedPirates, "rareEnemy", "pirateCaptain");
			break;
		case 291:
		case 292:
		case 293:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, NPC.downedPlantBoss, "rareEnemy", "skeletonGun");
			break;
		case 281:
		case 282:
		case 283:
		case 284:
		case 285:
		case 286:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, NPC.downedPlantBoss, "rareEnemy", "skeletonMage");
			break;
		case 287:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, NPC.downedPlantBoss, "rareEnemy", "boneLee");
			break;
		case 315:
			FargoUtils.TryDowned("Abominationn", Color.Orange, "headlessHorseman");
			break;
		case 327:
			FargoUtils.TryDowned("Abominationn", Color.Orange, NPC.downedHalloweenKing, "pumpking");
			break;
		case 325:
			FargoUtils.TryDowned("Abominationn", Color.Orange, NPC.downedHalloweenTree, "mourningWood");
			break;
		case 345:
			FargoUtils.TryDowned("Abominationn", Color.Orange, NPC.downedChristmasIceQueen, "iceQueen");
			break;
		case 346:
			FargoUtils.TryDowned("Abominationn", Color.Orange, NPC.downedChristmasSantank, "santank");
			break;
		case 344:
			FargoUtils.TryDowned("Abominationn", Color.Orange, NPC.downedChristmasTree, "everscream");
			break;
		case 586:
		case 587:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "zombieMerman", "eyeFish");
			break;
		case 621:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "bloodEel");
			break;
		case 620:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, Main.hardMode, "rareEnemy", "goblinShark");
			break;
		case 618:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "dreadnautilus");
			break;
		case 624:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "gnome");
			break;
		case 156:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "redDevil");
			break;
		case 667:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "goldenSlime");
			break;
		case 73:
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "goblinScout");
			break;
		}
		if (Fargowiltas.ModRareEnemies.ContainsKey(npc.type))
		{
			FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", Fargowiltas.ModRareEnemies[npc.type]);
		}
		if (npc.type == 551 && !PandoraActive)
		{
			FargoUtils.PrintText(Language.GetTextValue("Announcement.HasBeenDefeated_Single", Lang.GetNPCNameValue(551)), new Color(175, 75, 0));
			FargoWorld.DownedBools["betsy"] = true;
		}
		if (npc.boss)
		{
			FargoWorld.DownedBools["boss"] = true;
		}
		return true;
	}

	public override void ModifyHitByProjectile(NPC npc, Projectile projectile, ref NPC.HitModifiers modifiers)
	{
		if (FargoServerConfig.Instance.RottenEggs && projectile.type == 318 && npc.townNPC)
		{
			modifiers.FinalDamage *= 20f;
		}
	}

	public override void OnChatButtonClicked(NPC npc, bool firstButton)
	{
		if (FargoServerConfig.Instance.AnglerQuestInstantReset && Main.anglerQuestFinished)
		{
			if (Main.netMode == 0)
			{
				Main.AnglerQuestSwap();
			}
			else if (Main.netMode == 1)
			{
				ModPacket netMessage = base.Mod.GetPacket();
				netMessage.Write((byte)3);
				netMessage.Send();
			}
		}
	}

	private void SpawnBoss(NPC npc, int boss)
	{
		if (SwarmActive)
		{
			if (npc.type == 113)
			{
				NPC currentWoF = Main.npc[LastWoFIndex];
				int startingPos = (int)currentWoF.position.X;
				int spawn = NPC.NewNPC(NPC.GetBossSpawnSource(Main.myPlayer), startingPos + 400 * WoFDirection, (int)currentWoF.position.Y, 113);
				if (spawn != Main.maxNPCs)
				{
					Main.npc[spawn].GetGlobalNPC<FargoGlobalNPC>().SwarmActive = true;
					LastWoFIndex = spawn;
				}
			}
			else
			{
				int spawn = NPC.NewNPC(NPC.GetBossSpawnSource(Main.myPlayer), (int)npc.position.X + Main.rand.Next(-1000, 1000), (int)npc.position.Y + Main.rand.Next(-400, -100), boss);
				if (spawn != Main.maxNPCs)
				{
					Main.npc[spawn].GetGlobalNPC<FargoGlobalNPC>().SwarmActive = true;
					NetMessage.SendData(23, -1, -1, null, boss);
				}
			}
		}
		else
		{
			int random;
			do
			{
				random = Main.rand.Next(Bosses);
			}
			while (NPC.CountNPCS(random) >= 4);
			int spawn = NPC.NewNPC(NPC.GetBossSpawnSource(Main.myPlayer), (int)npc.position.X + Main.rand.Next(-1000, 1000), (int)npc.position.Y + Main.rand.Next(-400, -100), random);
			if (spawn != Main.maxNPCs)
			{
				Main.npc[spawn].GetGlobalNPC<FargoGlobalNPC>().PandoraActive = true;
				NetMessage.SendData(23, -1, -1, null, random);
			}
		}
	}

	private void Swarm(NPC npc, int boss, int minion, int bossbag, int trophy, int reward)
	{
		if (bossbag >= 0 && bossbag != 3817)
		{
			npc.DropItemInstanced(npc.Center, npc.Size, bossbag);
		}
		else if (bossbag >= 0 && bossbag == 3817)
		{
			npc.DropItemInstanced(npc.Center, npc.Size, bossbag, 5);
		}
		int count = 0;
		if (SwarmActive)
		{
			count = NPC.CountNPCS(boss) - 1;
		}
		else
		{
			for (int i = 0; i < Main.maxNPCs; i++)
			{
				if (Main.npc[i].active && Array.IndexOf(Bosses, Main.npc[i].type) > -1)
				{
					count++;
				}
			}
		}
		int missing = Fargowiltas.SwarmSpawned - count;
		Fargowiltas.SwarmKills++;
		if (Fargowiltas.SwarmKills % 100 == 0 && reward > 0)
		{
			Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, reward);
		}
		if (Fargowiltas.SwarmKills % 10 == 0 && trophy != -1)
		{
			Item.NewItem(npc.GetSource_Loot(), npc.Hitbox, trophy);
		}
		if (Main.netMode == 2)
		{
			ChatHelper.BroadcastChatMessage(NetworkText.FromKey("Mods.Fargowiltas.MessageInfo.SwarmKilled", Fargowiltas.SwarmKills), new Color(206, 12, 15));
			ChatHelper.BroadcastChatMessage(NetworkText.FromKey("Mods.Fargowiltas.MessageInfo.SwarmTotal", Fargowiltas.SwarmTotal), new Color(206, 12, 15));
		}
		else
		{
			Main.NewText(Language.GetTextValue("Mods.Fargowiltas.MessageInfo.SwarmKilled", Fargowiltas.SwarmKills), new Color(206, 12, 15));
			Main.NewText(Language.GetTextValue("Mods.Fargowiltas.MessageInfo.SwarmTotal", Fargowiltas.SwarmTotal), new Color(206, 12, 15));
		}
		if (minion != -1 && NPC.CountNPCS(minion) >= Fargowiltas.SwarmSpawned)
		{
			for (int i = 0; i < Main.maxNPCs; i++)
			{
				if (Main.npc[i].active && Main.npc[i].type == minion)
				{
					Main.npc[i].SimpleStrikeNPC(Main.npc[i].lifeMax, -Main.npc[i].direction, crit: true, 0f, null, damageVariation: false, 0f, noPlayerInteraction: true);
				}
			}
		}
		if (Fargowiltas.SwarmKills <= Fargowiltas.SwarmTotal - Fargowiltas.SwarmSpawned)
		{
			int spawned = 0;
			for (int i = 0; i < Main.maxNPCs; i++)
			{
				int num = 0;
				for (int j = 0; j < Main.maxNPCs; j++)
				{
					if (Main.npc[j].active)
					{
						num++;
					}
				}
				if (num >= Main.maxNPCs)
				{
					if (SwarmActive && minion > 0 && i < Main.maxNPCs - 1)
					{
						if (Main.npc[i].type == minion)
						{
							Main.npc[i].SimpleStrikeNPC(Main.npc[i].lifeMax, -Main.npc[i].direction, crit: true, 0f, null, damageVariation: false, 0f, noPlayerInteraction: true);
						}
					}
					else if (Array.IndexOf(Bosses, Main.npc[i].type) == -1 && !Main.npc[i].boss)
					{
						Main.npc[i].SimpleStrikeNPC(Main.npc[i].lifeMax, -Main.npc[i].direction, crit: true, 0f, null, damageVariation: false, 0f, noPlayerInteraction: true);
					}
				}
				SpawnBoss(npc, boss);
				spawned++;
				if (spawned > missing)
				{
					break;
				}
			}
		}
		else if (Fargowiltas.SwarmKills >= Fargowiltas.SwarmTotal)
		{
			if (Main.netMode == 2)
			{
				ChatHelper.BroadcastChatMessage(NetworkText.FromKey("Mods.Fargowiltas.MessageInfo.SwarmDefeated"), new Color(206, 12, 15));
			}
			else
			{
				Main.NewText(Language.GetTextValue("Mods.Fargowiltas.MessageInfo.SwarmDefeated"), new Color(206, 12, 15));
			}
			for (int i = 0; i < Main.maxNPCs; i++)
			{
				NPC kill = Main.npc[i];
				if (kill.active && !kill.friendly && kill.type != 507 && kill.type != 517 && kill.type != 493 && kill.type != 422)
				{
					Main.npc[i].GetGlobalNPC<FargoGlobalNPC>().NoLoot = true;
					Main.npc[i].SimpleStrikeNPC(Main.npc[i].lifeMax, -Main.npc[i].direction, crit: true, 0f, null, damageVariation: false, 0f, noPlayerInteraction: true);
				}
			}
			if (Main.netMode != 1)
			{
				Fargowiltas.SwarmActive = false;
				LastWoFIndex = -1;
				WoFDirection = 0;
				if (Main.netMode == 2)
				{
					NetMessage.SendData(7);
				}
			}
		}
		else
		{
			if (count >= Fargowiltas.SwarmSpawned || Fargowiltas.SwarmTotal <= 20)
			{
				return;
			}
			int extraSpawn = 0;
			for (int i = 0; i < Main.maxNPCs; i++)
			{
				int num = 0;
				for (int j = 0; j < Main.maxNPCs; j++)
				{
					if (Main.npc[j].active)
					{
						num++;
					}
				}
				if (num >= Main.maxNPCs)
				{
					if (SwarmActive && minion > 0 && i < Main.maxNPCs - 1)
					{
						if (Main.npc[i].type == minion)
						{
							Main.npc[i].SimpleStrikeNPC(Main.npc[i].lifeMax, -Main.npc[i].direction, crit: true, 0f, null, damageVariation: false, 0f, noPlayerInteraction: true);
						}
					}
					else if (Array.IndexOf(Bosses, Main.npc[i].type) == -1 && !Main.npc[i].boss)
					{
						Main.npc[i].SimpleStrikeNPC(Main.npc[i].lifeMax, -Main.npc[i].direction, crit: true, 0f, null, damageVariation: false, 0f, noPlayerInteraction: true);
					}
				}
				SpawnBoss(npc, boss);
				extraSpawn++;
				if (extraSpawn >= 5)
				{
					break;
				}
			}
		}
	}

	public static void SpawnWalls(Player player)
	{
		int startingPos = ((LastWoFIndex != -1) ? ((int)Main.npc[LastWoFIndex].position.X) : ((int)player.position.X));
		Vector2 pos = player.position;
		if (WoFDirection == 0)
		{
			WoFDirection = ((player.position.X / 16f > (float)(Main.maxTilesX / 2)) ? 1 : (-1));
		}
		int wof = NPC.NewNPC(NPC.GetBossSpawnSource(Main.myPlayer), startingPos + 400 * WoFDirection, (int)pos.Y, 113);
		Main.npc[wof].GetGlobalNPC<FargoGlobalNPC>().SwarmActive = true;
		LastWoFIndex = wof;
	}

	public static bool SpecificBossIsAlive(ref int bossID, int bossType)
	{
		if (bossID != -1)
		{
			if (Main.npc[bossID].active && Main.npc[bossID].type == bossType)
			{
				return true;
			}
			bossID = -1;
			return false;
		}
		return false;
	}

	public static bool AnyBossAlive()
	{
		if (boss == -1)
		{
			return false;
		}
		NPC npc = Main.npc[boss];
		if (npc.active && npc.type != 395 && (npc.boss || npc.type == 13))
		{
			return true;
		}
		boss = -1;
		return false;
	}
}
