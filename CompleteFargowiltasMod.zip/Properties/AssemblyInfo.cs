using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("Fargowiltas")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+7db53ef8fbeb5b18c376f306b365eb1c2aafeefa")]
[assembly: AssemblyProduct("Fargowiltas")]
[assembly: AssemblyTitle("Fargowiltas")]
[assembly: AssemblyVersion("1.0.0.0")]
[module: RefSafetyRules(11)]
