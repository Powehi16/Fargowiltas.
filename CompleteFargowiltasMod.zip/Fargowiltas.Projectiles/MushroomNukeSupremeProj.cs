namespace Fargowiltas.Projectiles;

public class MushroomNukeSupremeProj : RenewalBaseProj
{
	public MushroomNukeSupremeProj()
		: base("MushroomRenewalSupreme", 148, 3, supreme: true)
	{
	}
}
