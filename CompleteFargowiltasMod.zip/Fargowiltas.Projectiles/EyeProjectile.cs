using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class EyeProjectile : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 8;
		base.Projectile.height = 13;
		base.Projectile.aiStyle = 1;
		base.Projectile.friendly = true;
		base.Projectile.npcProj = true;
		base.Projectile.penetrate = 2;
		base.Projectile.timeLeft = 600;
		base.AIType = 14;
	}

	public override void OnKill(int timeLeft)
	{
		for (int i = 0; i < 20; i++)
		{
			int num469 = Dust.NewDust(base.Projectile.Center, base.Projectile.width, base.Projectile.height, 60, (0f - base.Projectile.velocity.X) * 0.2f, (0f - base.Projectile.velocity.Y) * 0.2f, 100, default(Color), 2f);
			Main.dust[num469].noGravity = true;
			Main.dust[num469].velocity *= 2f;
			num469 = Dust.NewDust(base.Projectile.Center, base.Projectile.width, base.Projectile.height, 60, (0f - base.Projectile.velocity.X) * 0.2f, (0f - base.Projectile.velocity.Y) * 0.2f, 100);
			Main.dust[num469].velocity *= 2f;
		}
	}
}
