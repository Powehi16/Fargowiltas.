namespace Fargowiltas.Projectiles;

public class PurityNukeProj : RenewalBaseProj
{
	public PurityNukeProj()
		: base("PurityRenewal", 145, 0, supreme: false)
	{
	}
}
