using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class MechEyeProjectile : ModProjectile
{
	private float HomingCooldown
	{
		get
		{
			return base.Projectile.ai[0];
		}
		set
		{
			base.Projectile.ai[0] = value;
		}
	}

	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 8;
		base.Projectile.height = 12;
		base.Projectile.aiStyle = 1;
		base.Projectile.friendly = true;
		base.Projectile.npcProj = true;
		base.Projectile.penetrate = 5;
		base.Projectile.timeLeft = 600;
		base.AIType = 14;
	}

	public override void AI()
	{
		HomingCooldown++;
		if (!(HomingCooldown > 10f))
		{
			return;
		}
		HomingCooldown = 10f;
		int foundTarget = HomeOnTarget();
		if (foundTarget != -1)
		{
			NPC n = Main.npc[foundTarget];
			if (base.Projectile.Distance(n.Center) > (float)Math.Max(n.width, n.height))
			{
				Vector2 desiredVelocity = base.Projectile.DirectionTo(n.Center) * 60f;
				base.Projectile.velocity = Vector2.Lerp(base.Projectile.velocity, desiredVelocity, 0.05f);
			}
		}
	}

	public override void OnKill(int timeLeft)
	{
		for (int num468 = 0; num468 < 20; num468++)
		{
			int num469 = Dust.NewDust(new Vector2(base.Projectile.Center.X, base.Projectile.Center.Y), base.Projectile.width, base.Projectile.height, 11, (0f - base.Projectile.velocity.X) * 0.2f, (0f - base.Projectile.velocity.Y) * 0.2f, 100, default(Color), 1.5f);
			Main.dust[num469].noGravity = true;
			Main.dust[num469].velocity *= 2f;
			num469 = Dust.NewDust(new Vector2(base.Projectile.Center.X, base.Projectile.Center.Y), base.Projectile.width, base.Projectile.height, 11, (0f - base.Projectile.velocity.X) * 0.2f, (0f - base.Projectile.velocity.Y) * 0.2f, 100, default(Color), 0.75f);
			Main.dust[num469].velocity *= 2f;
		}
	}

	private int HomeOnTarget()
	{
		int selectedTarget = -1;
		for (int i = 0; i < Main.maxNPCs; i++)
		{
			NPC n = Main.npc[i];
			if (n.CanBeChasedBy(base.Projectile) && Collision.CanHitLine(base.Projectile.Center, 0, 0, n.Center, 0, 0))
			{
				float distance = base.Projectile.Distance(n.Center);
				if (distance <= 500f && (selectedTarget == -1 || base.Projectile.Distance(Main.npc[selectedTarget].Center) > distance))
				{
					selectedTarget = i;
				}
			}
		}
		return selectedTarget;
	}
}
