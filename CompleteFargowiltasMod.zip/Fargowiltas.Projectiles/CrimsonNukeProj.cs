namespace Fargowiltas.Projectiles;

public class CrimsonNukeProj : RenewalBaseProj
{
	public CrimsonNukeProj()
		: base("CrimsonRenewal", 149, 4, supreme: false)
	{
	}
}
