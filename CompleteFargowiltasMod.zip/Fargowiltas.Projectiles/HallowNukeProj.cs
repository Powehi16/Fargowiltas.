namespace Fargowiltas.Projectiles;

public class HallowNukeProj : RenewalBaseProj
{
	public HallowNukeProj()
		: base("HallowRenewal", 146, 2, supreme: false)
	{
	}
}
