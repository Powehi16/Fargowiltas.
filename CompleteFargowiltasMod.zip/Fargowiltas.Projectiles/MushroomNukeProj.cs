namespace Fargowiltas.Projectiles;

public class MushroomNukeProj : RenewalBaseProj
{
	public MushroomNukeProj()
		: base("MushroomRenewal", 148, 3, supreme: false)
	{
	}
}
