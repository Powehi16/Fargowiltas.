using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class RenewalBaseProj : ModProjectile
{
	private readonly string name;

	private readonly int projType;

	private readonly int convertType;

	private readonly bool supreme;

	public override string Texture => "Fargowiltas/Items/Renewals/" + name;

	protected RenewalBaseProj(string name, int projType, int convertType, bool supreme)
	{
		this.name = name;
		this.projType = projType;
		this.convertType = convertType;
		this.supreme = supreme;
	}

	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 20;
		base.Projectile.height = 20;
		base.Projectile.aiStyle = 2;
		base.Projectile.friendly = true;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 170;
	}

	public override bool OnTileCollide(Vector2 oldVelocity)
	{
		base.Projectile.Kill();
		return true;
	}

	public override void OnKill(int timeLeft)
	{
		SoundEngine.PlaySound(in SoundID.Shatter, base.Projectile.Center);
		int radius = 150;
		float[] speedX = new float[8] { 0f, 0f, 5f, 5f, 5f, -5f, -5f, -5f };
		float[] speedY = new float[8] { 5f, -5f, 0f, 5f, -5f, 0f, 5f, -5f };
		if (Main.netMode == 0)
		{
			for (int i = 0; i < 8; i++)
			{
				Projectile.NewProjectile(base.Projectile.GetSource_FromThis(), base.Projectile.Center.X, base.Projectile.Center.Y, speedX[i], speedY[i], projType, 0, 0f, Main.myPlayer);
			}
		}
		if (supreme)
		{
			for (int x = -Main.maxTilesX; x < Main.maxTilesX; x++)
			{
				for (int y = -Main.maxTilesY; y < Main.maxTilesY; y++)
				{
					int xPosition = (int)((float)x + base.Projectile.Center.X / 16f);
					int yPosition = (int)((float)y + base.Projectile.Center.Y / 16f);
					WorldGen.Convert(xPosition, yPosition, convertType, 1);
				}
			}
			return;
		}
		for (int x = -radius; x <= radius; x++)
		{
			for (int y = -radius; y <= radius; y++)
			{
				int xPosition = (int)((float)x + base.Projectile.Center.X / 16f);
				int yPosition = (int)((float)y + base.Projectile.Center.Y / 16f);
				if (Math.Sqrt(x * x + y * y) <= (double)radius + 0.5)
				{
					WorldGen.Convert(xPosition, yPosition, convertType, 1);
				}
			}
		}
	}
}
