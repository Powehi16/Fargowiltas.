namespace Fargowiltas.Projectiles;

public class PurityNukeSupremeProj : RenewalBaseProj
{
	public PurityNukeSupremeProj()
		: base("PurityRenewalSupreme", 145, 0, supreme: true)
	{
	}
}
