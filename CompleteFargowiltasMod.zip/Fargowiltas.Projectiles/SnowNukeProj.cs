namespace Fargowiltas.Projectiles;

public class SnowNukeProj : RenewalBaseProj
{
	public SnowNukeProj()
		: base("SnowRenewal", 1016, 6, supreme: false)
	{
	}
}
