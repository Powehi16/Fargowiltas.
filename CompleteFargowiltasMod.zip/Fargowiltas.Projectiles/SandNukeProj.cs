namespace Fargowiltas.Projectiles;

public class SandNukeProj : RenewalBaseProj
{
	public SandNukeProj()
		: base("SandRenewal", 1015, 5, supreme: false)
	{
	}
}
