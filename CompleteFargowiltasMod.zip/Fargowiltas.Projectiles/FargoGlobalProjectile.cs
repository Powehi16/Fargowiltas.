using System.Collections.Generic;
using System.Linq;
using Fargowiltas.Common.Configs;
using Fargowiltas.NPCs;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.WorldBuilding;

namespace Fargowiltas.Projectiles;

public class FargoGlobalProjectile : GlobalProjectile
{
	private bool firstTick = true;

	public bool lowRender;

	public static HashSet<Rectangle> CannotDestroyRectangle = new HashSet<Rectangle>();

	public float DamageMultiplier = 1f;

	public override bool InstancePerEntity => true;

	public override void SetDefaults(Projectile projectile)
	{
		if (projectile.friendly)
		{
			lowRender = true;
		}
	}

	public override void OnSpawn(Projectile projectile, IEntitySource source)
	{
		FargoServerConfig config = FargoServerConfig.Instance;
		if (config.EnemyDamage != 1f || config.BossDamage != 1f)
		{
			FargoGlobalProjectile parentFGP;
			if (source is EntitySource_Parent { Entity: NPC npc } && config.BossDamage > config.EnemyDamage && (npc.boss || npc.type == 13 || npc.type == 14 || npc.type == 15 || (config.BossApplyToAllWhenAlive && FargoGlobalNPC.AnyBossAlive())))
			{
				DamageMultiplier = config.BossDamage;
			}
			else if (source is EntitySource_Parent { Entity: Projectile parentProj } && parentProj.TryGetGlobalProjectile<FargoGlobalProjectile>(out parentFGP) && parentFGP.DamageMultiplier > config.EnemyDamage)
			{
				DamageMultiplier = parentFGP.DamageMultiplier;
			}
			else
			{
				DamageMultiplier = config.EnemyDamage;
			}
		}
		if (projectile.bobber && projectile.owner == Main.myPlayer && FargoServerConfig.Instance.ExtraLures && source is EntitySource_ItemUse)
		{
			int split = 1;
			switch (Main.player[Main.myPlayer].HeldItem.type)
			{
			case 2294:
			case 2422:
				split = 5;
				break;
			case 2295:
			case 2296:
				split = 3;
				break;
			case 2292:
			case 2293:
			case 2421:
			case 4325:
			case 4442:
				split = 2;
				break;
			default:
				split = 1;
				break;
			}
			if (Main.player[projectile.owner].HasBuff(121))
			{
				split++;
			}
			if (split > 1)
			{
				SplitProj(projectile, split);
			}
		}
	}

	public override bool PreAI(Projectile projectile)
	{
		if (projectile.type == 525 && FargoServerConfig.Instance.StalkerMoneyTrough)
		{
			Player player = Main.player[projectile.owner];
			float dist = Vector2.Distance(projectile.Center, player.Center);
			if (dist > 3000f)
			{
				projectile.Center = player.Top;
			}
			else if (projectile.Center != player.Center)
			{
				Vector2 velocity = (player.Center + projectile.DirectionFrom(player.Center) * 3f * 16f - projectile.Center) / ((dist < 48f) ? 30f : 60f);
				projectile.position += velocity;
			}
			if (projectile.timeLeft < 2 && projectile.timeLeft > 0)
			{
				projectile.timeLeft = 2;
			}
		}
		if (firstTick)
		{
			firstTick = false;
			if (projectile.owner != Main.myPlayer && !projectile.hostile && !projectile.trap && projectile.friendly)
			{
				lowRender = true;
			}
		}
		if (projectile.bobber && projectile.lavaWet && FargoServerConfig.Instance.FasterLavaFishing && projectile.ai[0] == 0f && projectile.ai[1] == 0f && projectile.localAI[1] < 600f)
		{
			projectile.localAI[1] += 1f;
		}
		return true;
	}

	public override void OnKill(Projectile projectile, int timeLeft)
	{
		if (projectile.type != 525 || !FargoServerConfig.Instance.StalkerMoneyTrough)
		{
			return;
		}
		foreach (Projectile p in Main.projectile.Where((Projectile p) => p.active && p.type == projectile.type && p.owner == projectile.owner))
		{
			p.timeLeft = 0;
		}
	}

	public override void ModifyHitPlayer(Projectile projectile, Player target, ref Player.HurtModifiers modifiers)
	{
		modifiers.FinalDamage *= DamageMultiplier;
	}

	public static void SplitProj(Projectile projectile, int number)
	{
		double spread = 0.3 / (double)number;
		for (int i = 0; i < number / 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				int factor = ((j == 0) ? 1 : (-1));
				Projectile split = NewProjectileDirectSafe(projectile.GetSource_FromThis(), projectile.Center, projectile.velocity.RotatedBy((double)factor * spread * (double)(i + 1)), projectile.type, projectile.damage, projectile.knockBack, projectile.owner, projectile.ai[0], projectile.ai[1]);
				if (split != null)
				{
					split.friendly = true;
					split.GetGlobalProjectile<FargoGlobalProjectile>().firstTick = false;
				}
			}
		}
		if (number % 2 == 0)
		{
			projectile.active = false;
		}
	}

	public static Projectile NewProjectileDirectSafe(IEntitySource source, Vector2 pos, Vector2 vel, int type, int damage, float knockback, int owner = 255, float ai0 = 0f, float ai1 = 0f)
	{
		int p = Projectile.NewProjectile(source, pos, vel, type, damage, knockback, owner, ai0, ai1);
		return (p < Main.maxProjectiles) ? Main.projectile[p] : null;
	}

	public override Color? GetAlpha(Projectile projectile, Color lightColor)
	{
		if (lowRender && !projectile.hostile && FargoClientConfig.Instance.TransparentFriendlyProjectiles < 1f)
		{
			Color? color = projectile.ModProjectile?.GetAlpha(lightColor);
			if (color.HasValue)
			{
				return color.Value * FargoClientConfig.Instance.TransparentFriendlyProjectiles;
			}
			lightColor *= projectile.Opacity * FargoClientConfig.Instance.TransparentFriendlyProjectiles;
			return lightColor;
		}
		return base.GetAlpha(projectile, lightColor);
	}

	public static bool OkayToDestroyTile(Tile tile)
	{
		if (tile == null)
		{
			return false;
		}
		bool noDungeon = !NPC.downedBoss3 && (FargoSets.Walls.DungeonWall[tile.WallType] || FargoSets.Tiles.DungeonTile[tile.TileType]);
		bool noHMOre = FargoSets.Tiles.HardmodeOre[tile.TileType] && !NPC.downedMechBossAny;
		bool noChloro = tile.TileType == 211 && (!NPC.downedMechBoss1 || !NPC.downedMechBoss2 || !NPC.downedMechBoss3);
		bool noLihzahrd = (tile.TileType == 226 || tile.WallType == 87) && !NPC.downedGolemBoss;
		bool noAbyss = false;
		if (ModLoader.TryGetMod("CalamityMod", out var calamity) && calamity.TryFind<ModTile>("AbyssGravel", out var gravel) && calamity.TryFind<ModTile>("Voidstone", out var voidstone))
		{
			noAbyss = tile.TileType == gravel.Type || tile.TileType == voidstone.Type;
		}
		if (noDungeon || noHMOre || noChloro || noLihzahrd || noAbyss || TileBelongsToMagicStorage(tile) || FargoSets.Tiles.InstaCannotDestroy[tile.TileType] || FargoSets.Walls.InstaCannotDestroy[tile.WallType])
		{
			return false;
		}
		return true;
	}

	public static bool OkayToDestroyTileAt(int x, int y, bool bypassVanillaCanPlace = false)
	{
		if (!WorldGen.InWorld(x, y))
		{
			return false;
		}
		Tile tile = Main.tile[x, y];
		if (tile == null)
		{
			return false;
		}
		if (CannotDestroyRectangle != null && CannotDestroyRectangle.Any())
		{
			foreach (Rectangle item in CannotDestroyRectangle)
			{
				if (item.Contains(x * 16, y * 16))
				{
					return false;
				}
			}
		}
		Rectangle area = new Rectangle(x, y, 3, 3);
		if (!FargoServerConfig.Instance.SafeTerraformers)
		{
			bypassVanillaCanPlace = true;
		}
		if (!bypassVanillaCanPlace && GenVars.structures != null && !GenVars.structures.CanPlace(area))
		{
			return false;
		}
		return OkayToDestroyTile(tile);
	}

	public static bool TileIsLiterallyAir(Tile tile)
	{
		return tile.TileType == 0 && tile.WallType == 0 && tile.LiquidAmount == 0 && tile.TileFrameX == 0 && tile.TileFrameY == 0;
	}

	public static bool TileBelongsToMagicStorage(Tile tile)
	{
		return Fargowiltas.ModLoaded["MagicStorage"] && TileLoader.GetTile(tile.TileType)?.Mod == ModLoader.GetMod("MagicStorage");
	}
}
