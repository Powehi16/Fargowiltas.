using System;
using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class FakeHeartMarkDeviantt : ModProjectile
{
	public override string Texture => "Fargowiltas/Projectiles/FakeHeartDeviantt";

	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 12;
		base.Projectile.height = 12;
		base.Projectile.timeLeft = 2;
		base.Projectile.aiStyle = -1;
		base.Projectile.hide = true;
		base.Projectile.tileCollide = false;
		base.Projectile.ignoreWater = true;
	}

	public override void AI()
	{
		if (Main.netMode != 1)
		{
			for (int i = -3; i < 3; i++)
			{
				Projectile.NewProjectile(base.Projectile.GetSource_FromThis(), base.Projectile.Center, -base.Projectile.velocity.RotatedBy(Math.PI / 7.0 * (double)i), ModContent.ProjectileType<FakeHeart2Deviantt>(), base.Projectile.damage, base.Projectile.knockBack, base.Projectile.owner, -1f, 120 + 20 * i);
			}
		}
		base.Projectile.Kill();
	}

	public override bool? CanDamage()
	{
		return false;
	}
}
