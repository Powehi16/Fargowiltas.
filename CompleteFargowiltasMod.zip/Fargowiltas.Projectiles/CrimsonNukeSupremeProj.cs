namespace Fargowiltas.Projectiles;

public class CrimsonNukeSupremeProj : RenewalBaseProj
{
	public CrimsonNukeSupremeProj()
		: base("CrimsonRenewalSupreme", 149, 4, supreme: true)
	{
	}
}
