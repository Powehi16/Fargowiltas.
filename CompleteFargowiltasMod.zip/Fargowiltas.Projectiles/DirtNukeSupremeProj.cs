namespace Fargowiltas.Projectiles;

public class DirtNukeSupremeProj : RenewalBaseProj
{
	public DirtNukeSupremeProj()
		: base("DirtRenewalSupreme", 1017, 7, supreme: true)
	{
	}
}
