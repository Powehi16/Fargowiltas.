using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class FakeHeartDeviantt : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 12;
		base.Projectile.height = 12;
		base.Projectile.timeLeft = 600;
		base.Projectile.friendly = true;
		base.Projectile.npcProj = true;
		base.Projectile.aiStyle = -1;
		base.Projectile.tileCollide = false;
		base.Projectile.ignoreWater = true;
	}

	public override void AI()
	{
		float rand = (float)Main.rand.Next(90, 111) * 0.01f * (Main.essScale * 0.5f);
		Lighting.AddLight(base.Projectile.Center, 0.5f * rand, 0.1f * rand, 0.1f * rand);
		if (base.Projectile.localAI[0] == 0f)
		{
			base.Projectile.localAI[0] = 1f;
			base.Projectile.ai[0] = -1f;
		}
		if (base.Projectile.ai[0] >= 0f && base.Projectile.ai[0] < (float)Main.maxNPCs)
		{
			int ai0 = (int)base.Projectile.ai[0];
			if (Main.npc[ai0].CanBeChasedBy())
			{
				double num4 = (Main.npc[ai0].Center - base.Projectile.Center).ToRotation() - base.Projectile.velocity.ToRotation();
				if (num4 > Math.PI)
				{
					num4 -= Math.PI * 2.0;
				}
				if (num4 < -Math.PI)
				{
					num4 += Math.PI * 2.0;
				}
				base.Projectile.velocity = base.Projectile.velocity.RotatedBy(num4 * (double)((base.Projectile.Distance(Main.npc[ai0].Center) > 100f) ? 0.4f : 0.1f));
			}
			else
			{
				base.Projectile.ai[0] = -1f;
				base.Projectile.netUpdate = true;
			}
		}
		else if ((base.Projectile.localAI[1] += 1f) > 6f)
		{
			base.Projectile.localAI[1] = 0f;
			float maxDistance = 700f;
			int possibleTarget = -1;
			for (int i = 0; i < Main.maxNPCs; i++)
			{
				NPC npc = Main.npc[i];
				if (npc.CanBeChasedBy() && Collision.CanHitLine(base.Projectile.Center, 0, 0, npc.Center, 0, 0))
				{
					float npcDistance = base.Projectile.Distance(npc.Center);
					if (npcDistance < maxDistance)
					{
						maxDistance = npcDistance;
						possibleTarget = i;
					}
				}
			}
			base.Projectile.ai[0] = possibleTarget;
			base.Projectile.netUpdate = true;
		}
		base.Projectile.rotation = base.Projectile.velocity.ToRotation() - (float)Math.PI / 2f;
	}

	public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
	{
		target.AddBuff(119, 600);
	}

	public override Color? GetAlpha(Color lightColor)
	{
		return new Color(255, lightColor.G, lightColor.B, lightColor.A) * base.Projectile.Opacity;
	}
}
