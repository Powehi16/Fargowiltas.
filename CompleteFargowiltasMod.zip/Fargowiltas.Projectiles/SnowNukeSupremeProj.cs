namespace Fargowiltas.Projectiles;

public class SnowNukeSupremeProj : RenewalBaseProj
{
	public SnowNukeSupremeProj()
		: base("SnowRenewalSupreme", 1016, 6, supreme: true)
	{
	}
}
