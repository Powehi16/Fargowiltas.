namespace Fargowiltas.Projectiles;

public class CorruptNukeSupremeProj : RenewalBaseProj
{
	public CorruptNukeSupremeProj()
		: base("CorruptRenewalSupreme", 147, 1, supreme: true)
	{
	}
}
