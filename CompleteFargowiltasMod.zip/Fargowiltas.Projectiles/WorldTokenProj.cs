using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class WorldTokenProj : ModProjectile
{
	public override string Texture => "Fargowiltas/Items/Misc/ModeToggle_0";

	public override Color? GetAlpha(Color lightColor)
	{
		return Color.White * base.Projectile.Opacity;
	}

	public override void SetStaticDefaults()
	{
		ProjectileID.Sets.TrailCacheLength[base.Projectile.type] = 6;
		ProjectileID.Sets.TrailingMode[base.Projectile.type] = 2;
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 32;
		base.Projectile.height = 32;
		base.Projectile.friendly = false;
		base.Projectile.penetrate = -1;
		base.Projectile.scale = 1f;
		base.Projectile.timeLeft = 60;
		base.Projectile.ignoreWater = true;
		base.Projectile.tileCollide = false;
	}

	public override void AI()
	{
		if (base.Projectile.TryGetOwner(out Player player))
		{
			base.Projectile.Center = player.Center - Vector2.UnitY * 100f;
		}
		base.Projectile.scale += 1f / 30f;
		base.Projectile.Opacity -= 1f / 60f;
		if (base.Projectile.Opacity <= 0.01f)
		{
			base.Projectile.Kill();
		}
	}

	public override bool PreDraw(ref Color lightColor)
	{
		Texture2D texture = (Texture2D)ModContent.Request<Texture2D>($"Fargowiltas/Items/Misc/ModeToggle_{Main.GameMode}");
		Rectangle frame = new Rectangle(0, 0, texture.Width, texture.Height);
		Vector2 origin = frame.Size() / 2f;
		Main.spriteBatch.Draw(texture, base.Projectile.Center - Main.screenPosition + new Vector2(0f, base.Projectile.gfxOffY), frame, base.Projectile.GetAlpha(lightColor), base.Projectile.rotation, origin, base.Projectile.scale, SpriteEffects.None, 0f);
		return false;
	}
}
