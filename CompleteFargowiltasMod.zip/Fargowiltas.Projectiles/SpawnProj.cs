using Fargowiltas.NPCs;
using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class SpawnProj : ModProjectile
{
	private readonly int[] bosses = new int[18]
	{
		50, 4, 13, 266, 222, 668, 35, 134, 127, 125,
		126, 262, 245, 370, 439, 398, 657, 636
	};

	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 2;
		base.Projectile.height = 2;
		base.Projectile.aiStyle = -1;
		base.Projectile.timeLeft = 1;
		base.Projectile.tileCollide = false;
		base.Projectile.ignoreWater = true;
		base.Projectile.hide = true;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override void OnKill(int timeLeft)
	{
		if (Main.netMode == 1)
		{
			return;
		}
		if ((int)base.Projectile.ai[0] == 439 && NPC.downedAncientCultist)
		{
			int npc = NPC.NewNPC(NPC.GetBossSpawnSource(Main.myPlayer), (int)base.Projectile.Center.X, (int)base.Projectile.Center.Y, (int)base.Projectile.ai[0]);
			if (npc != Main.maxNPCs)
			{
				Main.npc[npc].GetGlobalNPC<FargoGlobalNPC>().PillarSpawn = false;
				if (Main.netMode == 2)
				{
					NetMessage.SendData(23, -1, -1, null, npc);
				}
			}
		}
		else if (base.Projectile.ai[1] == 2f)
		{
			for (int i = 0; i < 7; i++)
			{
				int n = NPC.NewNPC(NPC.GetBossSpawnSource(Main.myPlayer), (int)base.Projectile.Center.X, (int)base.Projectile.Center.Y, bosses[i]);
				if (n != Main.maxNPCs && Main.netMode == 2)
				{
					NetMessage.SendData(23, -1, -1, null, n);
				}
			}
			NPC.SpawnWOF(Main.player[base.Projectile.owner].Center);
		}
		else if (base.Projectile.ai[1] == 3f)
		{
			int[] array = bosses;
			foreach (int boss in array)
			{
				int spawn = NPC.NewNPC(NPC.GetBossSpawnSource(Main.myPlayer), (int)base.Projectile.Center.X, (int)base.Projectile.Center.Y, boss);
				if (boss == 439)
				{
					Main.npc[spawn].GetGlobalNPC<FargoGlobalNPC>().PillarSpawn = false;
					if (spawn != Main.maxNPCs && Main.netMode == 2)
					{
						NetMessage.SendData(23, -1, -1, null, spawn);
					}
				}
			}
			NPC.SpawnWOF(Main.player[base.Projectile.owner].Center);
		}
		else
		{
			int n = NPC.NewNPC(NPC.GetBossSpawnSource(Main.myPlayer), (int)base.Projectile.Center.X, (int)base.Projectile.Center.Y, (int)base.Projectile.ai[0]);
			if (n != Main.maxNPCs && Main.netMode == 2)
			{
				NetMessage.SendData(23, -1, -1, null, n);
			}
		}
	}
}
