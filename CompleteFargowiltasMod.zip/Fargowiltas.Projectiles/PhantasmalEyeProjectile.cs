using System;
using Fargowiltas.NPCs;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class PhantasmalEyeProjectile : ModProjectile
{
	private float HomingCooldown
	{
		get
		{
			return base.Projectile.ai[0];
		}
		set
		{
			base.Projectile.ai[0] = value;
		}
	}

	public override void SetStaticDefaults()
	{
		ProjectileID.Sets.TrailCacheLength[base.Projectile.type] = 4;
		ProjectileID.Sets.TrailingMode[base.Projectile.type] = 2;
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 9;
		base.Projectile.height = 16;
		base.Projectile.aiStyle = -1;
		base.Projectile.friendly = true;
		base.Projectile.npcProj = true;
		base.Projectile.tileCollide = false;
		base.Projectile.penetrate = 50;
		base.Projectile.timeLeft = 600;
		base.Projectile.usesLocalNPCImmunity = true;
		base.Projectile.localNPCHitCooldown = 10;
	}

	public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
	{
		target.AddBuff(69, 240);
		target.AddBuff(203, 240);
	}

	public override void AI()
	{
		HomingCooldown++;
		if (HomingCooldown > 10f)
		{
			HomingCooldown = 10f;
			int foundTarget = HomeOnTarget();
			if (foundTarget != -1)
			{
				NPC n = Main.npc[foundTarget];
				if (base.Projectile.Distance(n.Center) > (float)Math.Max(n.width, n.height))
				{
					Vector2 desiredVelocity = base.Projectile.DirectionTo(n.Center) * 60f;
					base.Projectile.velocity = Vector2.Lerp(base.Projectile.velocity, desiredVelocity, 0.05f);
					double num4 = (n.Center - base.Projectile.Center).ToRotation() - base.Projectile.velocity.ToRotation();
					if (num4 > Math.PI)
					{
						num4 -= Math.PI * 2.0;
					}
					if (num4 < -Math.PI)
					{
						num4 += Math.PI * 2.0;
					}
					base.Projectile.velocity = base.Projectile.velocity.RotatedBy(num4 * (double)((base.Projectile.Distance(n.Center) > 100f) ? 0.4f : 0.1f));
				}
			}
		}
		if (base.Projectile.velocity.Length() < 2f)
		{
			base.Projectile.velocity *= 1.03f;
		}
		base.Projectile.rotation = base.Projectile.velocity.ToRotation() + 1.570796f;
		base.Projectile.localAI[0] += 0.1f;
		if (base.Projectile.localAI[0] > (float)ProjectileID.Sets.TrailCacheLength[base.Projectile.type])
		{
			base.Projectile.localAI[0] = ProjectileID.Sets.TrailCacheLength[base.Projectile.type];
		}
		base.Projectile.localAI[1] += 0.25f;
	}

	public override void OnKill(int timeLeft)
	{
		SoundStyle style = new SoundStyle("Terraria/Sounds/Zombie_103");
		SoundEngine.PlaySound(in style, base.Projectile.Center);
		base.Projectile.position = base.Projectile.Center;
		base.Projectile.width = (base.Projectile.height = 144);
		base.Projectile.Center = base.Projectile.position;
		for (int i = 0; i < 2; i++)
		{
			Dust.NewDust(base.Projectile.position, base.Projectile.width, base.Projectile.height, 31, 0f, 0f, 100, default(Color), 1.5f);
		}
		for (int i = 0; i < 20; i++)
		{
			int d = Dust.NewDust(base.Projectile.position, base.Projectile.width, base.Projectile.height, 229, 0f, 0f, 0, default(Color), 2.5f);
			Main.dust[d].noGravity = true;
			Main.dust[d].velocity *= 3f;
			d = Dust.NewDust(base.Projectile.position, base.Projectile.width, base.Projectile.height, 229, 0f, 0f, 100, default(Color), 1.5f);
			Main.dust[d].velocity *= 2f;
			Main.dust[d].noGravity = true;
		}
	}

	private int HomeOnTarget()
	{
		int selectedTarget = -1;
		for (int i = 0; i < Main.maxNPCs; i++)
		{
			NPC n = Main.npc[i];
			if (n.CanBeChasedBy(base.Projectile))
			{
				float distance = base.Projectile.Distance(n.Center);
				if (distance <= 1000f && (selectedTarget == -1 || base.Projectile.Distance(Main.npc[selectedTarget].Center) > distance))
				{
					selectedTarget = i;
				}
			}
		}
		if (selectedTarget == -1)
		{
			selectedTarget = NPC.FindFirstNPC(ModContent.NPCType<Mutant>());
		}
		return selectedTarget;
	}

	public override Color? GetAlpha(Color lightColor)
	{
		return Color.White * base.Projectile.Opacity;
	}

	public override bool PreDraw(ref Color lightColor)
	{
		Texture2D glow = ModContent.Request<Texture2D>(Texture + "_Glow").Value;
		int rect1 = glow.Height / Main.projFrames[base.Projectile.type];
		int rect2 = rect1 * base.Projectile.frame;
		Rectangle glowrectangle = new Rectangle(0, rect2, glow.Width, rect1);
		Vector2 gloworigin2 = glowrectangle.Size() / 2f;
		Color glowcolor = Color.Lerp(new Color(31, 187, 192, 0), Color.Transparent, 0.74f);
		Vector2 drawCenter = base.Projectile.Center - base.Projectile.velocity.SafeNormalize(Vector2.UnitX) * 14f;
		for (int i = 0; i < 3; i++)
		{
			Vector2 drawCenter2 = drawCenter + (base.Projectile.velocity.SafeNormalize(Vector2.UnitX) * 8f).RotatedBy((float)Math.PI / 5f - (float)i * (float)Math.PI / 5f);
			drawCenter2 -= base.Projectile.velocity.SafeNormalize(Vector2.UnitX) * 8f;
			float scale = base.Projectile.scale;
			scale += (float)Math.Sin(base.Projectile.localAI[1]) / 10f;
			Main.spriteBatch.Draw(glow, drawCenter2 - Main.screenPosition + new Vector2(0f, base.Projectile.gfxOffY), glowrectangle, glowcolor, base.Projectile.velocity.ToRotation() + (float)Math.PI / 2f, gloworigin2, scale, SpriteEffects.None, 0f);
		}
		for (float i = base.Projectile.localAI[0] - 1f; i > 0f; i -= base.Projectile.localAI[0] / 5f)
		{
			float lerpamount = 0.2f;
			if (i > 5f && i < 10f)
			{
				lerpamount = 0.4f;
			}
			if (i >= 10f)
			{
				lerpamount = 0.6f;
			}
			Color color27 = Color.Lerp(glowcolor, Color.Transparent, 0.1f + lerpamount);
			color27 *= (float)((int)((base.Projectile.localAI[0] - i) / base.Projectile.localAI[0]) ^ 2);
			float scale = base.Projectile.scale * (base.Projectile.localAI[0] - i) / base.Projectile.localAI[0];
			scale += (float)Math.Sin(base.Projectile.localAI[1]) / 10f;
			Vector2 value4 = base.Projectile.oldPos[(int)i] - base.Projectile.velocity.SafeNormalize(Vector2.UnitX) * 14f;
			Main.spriteBatch.Draw(glow, value4 + base.Projectile.Size / 2f - Main.screenPosition + new Vector2(0f, base.Projectile.gfxOffY), glowrectangle, color27, base.Projectile.velocity.ToRotation() + (float)Math.PI / 2f, gloworigin2, scale * 0.8f, SpriteEffects.None, 0f);
		}
		return false;
	}

	public override void PostDraw(Color lightColor)
	{
		Texture2D texture2D13 = ModContent.Request<Texture2D>(Texture).Value;
		int num156 = texture2D13.Height / Main.projFrames[base.Projectile.type];
		int y3 = num156 * base.Projectile.frame;
		Rectangle rectangle = new Rectangle(0, y3, texture2D13.Width, num156);
		Vector2 origin2 = rectangle.Size() / 2f;
		Main.spriteBatch.Draw(texture2D13, base.Projectile.Center - Main.screenPosition + new Vector2(0f, base.Projectile.gfxOffY), rectangle, base.Projectile.GetAlpha(lightColor), base.Projectile.rotation, origin2, base.Projectile.scale, SpriteEffects.None, 0f);
	}
}
