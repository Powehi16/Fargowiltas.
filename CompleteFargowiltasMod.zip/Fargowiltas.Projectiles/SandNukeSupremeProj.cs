namespace Fargowiltas.Projectiles;

public class SandNukeSupremeProj : RenewalBaseProj
{
	public SandNukeSupremeProj()
		: base("SandRenewalSupreme", 1015, 5, supreme: true)
	{
	}
}
