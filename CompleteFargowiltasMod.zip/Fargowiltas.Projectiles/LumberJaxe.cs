using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class LumberJaxe : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 42;
		base.Projectile.height = 40;
		base.Projectile.friendly = true;
		base.Projectile.DamageType = DamageClass.Ranged;
		base.Projectile.penetrate = 1;
		base.Projectile.aiStyle = 0;
		base.Projectile.timeLeft = 150;
		base.AIType = 89;
	}

	public override void AI()
	{
		base.Projectile.rotation += 0.3f;
	}

	public override void ModifyHitNPC(NPC target, ref NPC.HitModifiers modifiers)
	{
		if (target.type == 325 || target.type == 344 || target.type == 326)
		{
			modifiers.FinalDamage *= 10f;
		}
		base.ModifyHitNPC(target, ref modifiers);
	}

	public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
	{
		base.Projectile.Kill();
	}

	public override void OnKill(int timeLeft)
	{
		Projectile.NewProjectile(base.Projectile.GetSource_FromThis(), base.Projectile.Center.X, base.Projectile.Center.Y, base.Projectile.velocity.X * 0f, base.Projectile.velocity.Y * 0f, ModContent.ProjectileType<Explosion>(), (int)((float)base.Projectile.damage * 1f), base.Projectile.knockBack, base.Projectile.owner);
	}
}
