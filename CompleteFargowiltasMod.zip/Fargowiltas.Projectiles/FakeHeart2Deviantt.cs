using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class FakeHeart2Deviantt : ModProjectile
{
	public override string Texture => "Fargowiltas/Projectiles/FakeHeartDeviantt";

	public override void SetStaticDefaults()
	{
		ProjectileID.Sets.TrailCacheLength[base.Projectile.type] = 7;
		ProjectileID.Sets.TrailingMode[base.Projectile.type] = 2;
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 12;
		base.Projectile.height = 12;
		base.Projectile.timeLeft = 600;
		base.Projectile.friendly = true;
		base.Projectile.aiStyle = -1;
		base.Projectile.penetrate = 2;
		base.Projectile.tileCollide = false;
		base.Projectile.ignoreWater = true;
		base.Projectile.extraUpdates = 1;
	}

	public override void AI()
	{
		float rand = (float)Main.rand.Next(90, 111) * 0.01f * (Main.essScale * 0.5f);
		Lighting.AddLight(base.Projectile.Center, 0.5f * rand, 0.1f * rand, 0.1f * rand);
		if ((base.Projectile.localAI[0] += 1f) == 30f)
		{
			base.Projectile.localAI[1] = base.Projectile.velocity.ToRotation();
			base.Projectile.velocity = Vector2.Zero;
		}
		if ((base.Projectile.ai[1] -= 1f) == 0f)
		{
			base.Projectile.velocity = base.Projectile.localAI[1].ToRotationVector2() * -12.5f;
		}
		else if (base.Projectile.ai[1] < 0f)
		{
			if (base.Projectile.ai[0] >= 0f && base.Projectile.ai[0] < 200f)
			{
				int ai0 = (int)base.Projectile.ai[0];
				if (Main.npc[ai0].CanBeChasedBy())
				{
					double num4 = (Main.npc[ai0].Center - base.Projectile.Center).ToRotation() - base.Projectile.velocity.ToRotation();
					if (num4 > Math.PI)
					{
						num4 -= Math.PI * 2.0;
					}
					if (num4 < -Math.PI)
					{
						num4 += Math.PI * 2.0;
					}
					base.Projectile.velocity = base.Projectile.velocity.RotatedBy(num4 * (double)((base.Projectile.Distance(Main.npc[ai0].Center) > 100f) ? 0.6f : 0.2f));
				}
				else
				{
					base.Projectile.ai[0] = -1f;
					base.Projectile.netUpdate = true;
				}
			}
			else if ((base.Projectile.localAI[1] += 1f) > 12f)
			{
				base.Projectile.localAI[1] = 0f;
				float maxDistance = 700f;
				int possibleTarget = -1;
				for (int i = 0; i < Main.maxNPCs; i++)
				{
					NPC npc = Main.npc[i];
					if (npc.CanBeChasedBy())
					{
						float npcDistance = base.Projectile.Distance(npc.Center);
						if (npcDistance < maxDistance)
						{
							maxDistance = npcDistance;
							possibleTarget = i;
						}
					}
				}
				base.Projectile.ai[0] = possibleTarget;
				base.Projectile.netUpdate = true;
			}
		}
		if (base.Projectile.velocity != Vector2.Zero)
		{
			base.Projectile.rotation = base.Projectile.velocity.ToRotation();
		}
		base.Projectile.rotation -= (float)Math.PI / 2f;
	}

	public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
	{
		target.immune[base.Projectile.owner] = 5;
		target.AddBuff(119, 600);
	}

	public override Color? GetAlpha(Color lightColor)
	{
		return new Color(255, lightColor.G, lightColor.B, lightColor.A);
	}
}
