namespace Fargowiltas.Projectiles;

public class DirtNukeProj : RenewalBaseProj
{
	public DirtNukeProj()
		: base("DirtRenewal", 1017, 7, supreme: false)
	{
	}
}
