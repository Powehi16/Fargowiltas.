using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class Explosion : ModProjectile
{
	public override void SetStaticDefaults()
	{
		ProjectileID.Sets.TrailCacheLength[base.Projectile.type] = 5;
		ProjectileID.Sets.TrailingMode[base.Projectile.type] = 0;
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 10;
		base.Projectile.height = 10;
		base.Projectile.aiStyle = 0;
		base.Projectile.friendly = true;
		base.Projectile.DamageType = DamageClass.Ranged;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 10;
		base.Projectile.tileCollide = false;
		base.Projectile.light = 0.75f;
		base.Projectile.ignoreWater = true;
		base.Projectile.extraUpdates = 1;
		base.AIType = 14;
	}

	public override void OnKill(int timeLeft)
	{
		SoundEngine.PlaySound(in SoundID.Item14, base.Projectile.position);
		base.Projectile.position = base.Projectile.Center;
		base.Projectile.width = 100;
		base.Projectile.height = 100;
		base.Projectile.Center = base.Projectile.position;
		for (int i = 0; i < 30; i++)
		{
			int num616 = Dust.NewDust(base.Projectile.position, base.Projectile.width, base.Projectile.height, 31, 0f, 0f, 100, default(Color), 1.5f);
			Main.dust[num616].velocity *= 1.4f;
		}
		for (int i = 0; i < 2; i++)
		{
			float scaleFactor = 0.4f;
			if (i == 1)
			{
				scaleFactor = 0.8f;
			}
			int num620 = Gore.NewGore(base.Projectile.GetSource_FromThis(), base.Projectile.position, default(Vector2), Main.rand.Next(61, 64));
			Main.gore[num620].velocity *= scaleFactor;
			Gore gore97 = Main.gore[num620];
			gore97.velocity.X += 1f;
			Gore gore98 = Main.gore[num620];
			gore98.velocity.Y += 1f;
			num620 = Gore.NewGore(base.Projectile.GetSource_FromThis(), base.Projectile.position, default(Vector2), Main.rand.Next(61, 64));
			Main.gore[num620].velocity *= scaleFactor;
			Gore gore99 = Main.gore[num620];
			gore99.velocity.X -= 1f;
			Gore gore100 = Main.gore[num620];
			gore100.velocity.Y += 1f;
			num620 = Gore.NewGore(base.Projectile.GetSource_FromThis(), base.Projectile.position, default(Vector2), Main.rand.Next(61, 64));
			Main.gore[num620].velocity *= scaleFactor;
			Gore gore101 = Main.gore[num620];
			gore101.velocity.X += 1f;
			Gore gore102 = Main.gore[num620];
			gore102.velocity.Y -= 1f;
			num620 = Gore.NewGore(base.Projectile.GetSource_FromThis(), base.Projectile.position, default(Vector2), Main.rand.Next(61, 64));
			Main.gore[num620].velocity *= scaleFactor;
			Gore gore103 = Main.gore[num620];
			gore103.velocity.X -= 1f;
			Gore gore104 = Main.gore[num620];
			gore104.velocity.Y -= 1f;
		}
	}
}
