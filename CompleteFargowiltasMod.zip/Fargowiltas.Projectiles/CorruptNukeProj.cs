namespace Fargowiltas.Projectiles;

public class CorruptNukeProj : RenewalBaseProj
{
	public CorruptNukeProj()
		: base("CorruptRenewal", 147, 1, supreme: false)
	{
	}
}
