using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles;

public class DeathScythe : ModProjectile
{
	public override string Texture => "Terraria/Images/Projectile_274";

	public override Color? GetAlpha(Color lightColor)
	{
		return Color.White * base.Projectile.Opacity;
	}

	public override void SetStaticDefaults()
	{
		ProjectileID.Sets.TrailCacheLength[base.Projectile.type] = 6;
		ProjectileID.Sets.TrailingMode[base.Projectile.type] = 2;
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 42;
		base.Projectile.height = 42;
		base.Projectile.friendly = true;
		base.Projectile.npcProj = true;
		base.Projectile.penetrate = 50;
		base.Projectile.scale = 1f;
		base.Projectile.timeLeft = 180;
		base.Projectile.ignoreWater = true;
		base.Projectile.tileCollide = false;
		base.Projectile.usesLocalNPCImmunity = true;
		base.Projectile.localNPCHitCooldown = 10;
	}

	public override void AI()
	{
		if (base.Projectile.localAI[0] == 0f)
		{
			base.Projectile.localAI[0] = 1f;
			base.Projectile.ai[0] = -1f;
			SoundEngine.PlaySound(in SoundID.Item71, base.Projectile.Center);
		}
		base.Projectile.rotation += 1f;
		base.Projectile.ai[1] += 1f;
		if (!(base.Projectile.ai[1] > 30f))
		{
			return;
		}
		base.Projectile.ai[1] = 30f;
		base.Projectile.ai[0] = HomeOnTarget();
		if (base.Projectile.ai[0] > -1f && base.Projectile.ai[0] < 200f)
		{
			NPC n = Main.npc[(int)base.Projectile.ai[0]];
			if (n.active && n.CanBeChasedBy())
			{
				Vector2 desiredVelocity = base.Projectile.DirectionTo(n.Center) * 70f;
				base.Projectile.velocity = Vector2.Lerp(base.Projectile.velocity, desiredVelocity, 0.1f);
			}
		}
		else
		{
			base.Projectile.ai[0] = -1f;
		}
	}

	public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
	{
		target.AddBuff(153, 600);
	}

	private int HomeOnTarget()
	{
		int selectedTarget = -1;
		for (int i = 0; i < Main.maxNPCs; i++)
		{
			NPC n = Main.npc[i];
			if (n.CanBeChasedBy(base.Projectile) && (!n.wet || true))
			{
				float distance = base.Projectile.Distance(n.Center);
				if (distance <= 1000f && (selectedTarget == -1 || base.Projectile.Distance(Main.npc[selectedTarget].Center) > distance))
				{
					selectedTarget = i;
				}
			}
		}
		return selectedTarget;
	}
}
