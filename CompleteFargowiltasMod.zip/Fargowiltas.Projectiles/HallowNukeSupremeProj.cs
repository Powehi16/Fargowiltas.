namespace Fargowiltas.Projectiles;

public class HallowNukeSupremeProj : RenewalBaseProj
{
	public HallowNukeSupremeProj()
		: base("HallowRenewalSupreme", 146, 2, supreme: true)
	{
	}
}
