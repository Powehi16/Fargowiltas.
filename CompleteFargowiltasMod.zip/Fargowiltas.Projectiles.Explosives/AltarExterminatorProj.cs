using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class AltarExterminatorProj : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 2;
		base.Projectile.height = 2;
		base.Projectile.aiStyle = -1;
		base.Projectile.friendly = true;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 1;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override void OnKill(int timeLeft)
	{
		SoundEngine.PlaySound(in SoundID.Item14, base.Projectile.Center);
		if (Main.netMode == 1)
		{
			return;
		}
		for (int i = 0; i < Main.maxTilesX; i++)
		{
			for (int j = 0; j < Main.maxTilesY; j++)
			{
				if (!WorldGen.InWorld(i, j))
				{
					continue;
				}
				Tile tile = Framing.GetTileSafely(i, j);
				if (FargoSets.Tiles.EvilAltars[tile.TileType])
				{
					WorldGen.KillTile(i, j);
					if (Main.netMode == 2)
					{
						NetMessage.SendTileSquare(-1, i, j, 1);
					}
				}
			}
		}
		Main.refreshMap = true;
	}
}
