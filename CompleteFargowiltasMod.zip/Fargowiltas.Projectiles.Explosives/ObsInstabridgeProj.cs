using Fargowiltas.Tiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class ObsInstabridgeProj : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 20;
		base.Projectile.height = 36;
		base.Projectile.aiStyle = 16;
		base.Projectile.friendly = true;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 1;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override void OnKill(int timeLeft)
	{
		Vector2 position = base.Projectile.Center;
		SoundEngine.PlaySound(in SoundID.Item14, position);
		if (Main.netMode == 1)
		{
			return;
		}
		for (int x = 1; x <= Main.maxTilesX; x++)
		{
			for (int y = -5; y <= 0; y++)
			{
				int xPosition = x;
				int yPosition = (int)((float)y + position.Y / 16f);
				if (xPosition < 0 || xPosition >= Main.maxTilesX || yPosition < 0 || yPosition >= Main.maxTilesY)
				{
					continue;
				}
				Tile tile = Main.tile[xPosition, yPosition];
				if (tile == null || !FargoGlobalProjectile.OkayToDestroyTileAt(xPosition, yPosition))
				{
					continue;
				}
				FargoGlobalTile.ClearEverything(xPosition, yPosition);
				if (y == 0)
				{
					FargoGlobalTile.ClearEverything(xPosition, yPosition, sendData: false);
					WorldGen.PlaceTile(xPosition, yPosition, 19, mute: false, forced: false, -1, 13);
					if (Main.netMode == 2)
					{
						NetMessage.SendTileSquare(-1, xPosition, yPosition, 1);
					}
				}
				else if (!FargoGlobalProjectile.TileIsLiterallyAir(tile))
				{
					FargoGlobalTile.ClearEverything(xPosition, yPosition);
				}
			}
		}
	}
}
