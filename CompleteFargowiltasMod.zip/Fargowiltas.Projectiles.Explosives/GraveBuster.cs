using Fargowiltas.Tiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class GraveBuster : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 30;
		base.Projectile.height = 30;
		base.Projectile.aiStyle = 16;
		base.Projectile.friendly = true;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 180;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override bool TileCollideStyle(ref int width, ref int height, ref bool fallThrough, ref Vector2 hitboxCenterFrac)
	{
		fallThrough = false;
		return base.TileCollideStyle(ref width, ref height, ref fallThrough, ref hitboxCenterFrac);
	}

	public override void OnKill(int timeLeft)
	{
		SoundEngine.PlaySound(in SoundID.Item15, base.Projectile.Center);
		SoundEngine.PlaySound(in SoundID.Item14, base.Projectile.Center);
		if (Main.netMode == 1)
		{
			return;
		}
		Vector2 position = base.Projectile.Center;
		int radius = 360;
		for (int x = -radius; x <= radius; x++)
		{
			for (int y = -radius; y <= radius; y++)
			{
				int xPosition = (int)((float)x + position.X / 16f);
				int yPosition = (int)((float)y + position.Y / 16f);
				if (xPosition >= 0 && xPosition < Main.maxTilesX && yPosition >= 0 && yPosition < Main.maxTilesY && Main.tile[xPosition, yPosition].TileType == 85 && FargoGlobalProjectile.OkayToDestroyTileAt(xPosition, yPosition, bypassVanillaCanPlace: true))
				{
					FargoGlobalTile.ClearTileAndLiquid(xPosition, yPosition);
				}
			}
		}
		Main.refreshMap = true;
	}
}
