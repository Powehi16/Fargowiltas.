using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent.Achievements;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class ShurikenProj : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 11;
		base.Projectile.height = 11;
		base.Projectile.friendly = true;
		base.Projectile.DamageType = DamageClass.Default;
		base.Projectile.penetrate = 5;
		base.Projectile.aiStyle = 2;
		base.Projectile.timeLeft = 600;
		base.AIType = 48;
	}

	public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
	{
		base.Projectile.timeLeft = 0;
	}

	public override bool OnTileCollide(Vector2 oldVelocity)
	{
		base.Projectile.timeLeft = 0;
		return false;
	}

	public override void OnKill(int timeLeft)
	{
		if (base.Projectile.owner == Main.myPlayer)
		{
			Projectile.NewProjectile(base.Projectile.GetSource_FromThis(), base.Projectile.Center.X, base.Projectile.Center.Y, 0f, 0f, ModContent.ProjectileType<Explosion>(), 0, base.Projectile.knockBack, base.Projectile.owner);
		}
		Vector2 position = base.Projectile.Center;
		SoundEngine.PlaySound(in SoundID.Item14, position);
		int radius = 16;
		Player player = Main.player[base.Projectile.owner];
		NetMessage.SendData(29, -1, -1, null, base.Projectile.identity, base.Projectile.owner);
		AchievementsHelper.CurrentlyMining = true;
		for (int x = -radius; x <= radius; x++)
		{
			for (int y = -radius; y <= radius; y++)
			{
				int xPosition = (int)((float)x + position.X / 16f);
				int yPosition = (int)((float)y + position.Y / 16f);
				if (xPosition < 0 || xPosition >= Main.maxTilesX || yPosition < 0 || yPosition >= Main.maxTilesY)
				{
					continue;
				}
				Tile tile = Main.tile[xPosition, yPosition];
				if (x * x + y * y > radius)
				{
					continue;
				}
				if (base.Projectile.owner == Main.myPlayer)
				{
					if (tile.IsActuated || FargoGlobalProjectile.TileIsLiterallyAir(tile) || FargoGlobalProjectile.TileBelongsToMagicStorage(tile))
					{
						continue;
					}
					if (player.HasEnoughPickPowerToHurtTile(xPosition, yPosition) && WorldGen.CanKillTile(xPosition, yPosition))
					{
						WorldGen.KillTile(xPosition, yPosition);
						if (Main.netMode != 0)
						{
							NetMessage.SendData(17, -1, -1, null, 20, xPosition, yPosition);
						}
					}
				}
				Dust.NewDust(position, 22, 22, 31, 0f, 0f, 120);
			}
		}
		AchievementsHelper.CurrentlyMining = false;
	}
}
