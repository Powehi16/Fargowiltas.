using System;
using Fargowiltas.Tiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class AutoHouseProj : ModProjectile
{
	public override void SetDefaults()
	{
		base.Projectile.width = 1;
		base.Projectile.height = 1;
		base.Projectile.timeLeft = 1;
	}

	public static void PlaceHouse(int x, int y, Vector2 position, int side, Player player)
	{
		int xPosition = (int)((float)(side * -1 + x) + position.X / 16f);
		int yPosition = (int)((float)y + position.Y / 16f);
		Tile tile = Main.tile[xPosition, yPosition];
		if (!FargoGlobalProjectile.OkayToDestroyTileAt(xPosition, yPosition, bypassVanillaCanPlace: true))
		{
			return;
		}
		int wallType = 4;
		int tileType = 30;
		int platformStyle = 0;
		if (player.ZoneDesert && !player.ZoneBeach)
		{
			wallType = 72;
			tileType = 188;
			platformStyle = 25;
		}
		else if (player.ZoneSnow)
		{
			wallType = 149;
			tileType = 321;
			platformStyle = 19;
		}
		else if (player.ZoneJungle)
		{
			wallType = 42;
			tileType = 158;
			platformStyle = 2;
		}
		else if (player.ZoneCorrupt)
		{
			wallType = 41;
			tileType = 157;
			platformStyle = 1;
		}
		else if (player.ZoneCrimson)
		{
			wallType = 85;
			tileType = 208;
			platformStyle = 5;
		}
		else if (player.ZoneBeach)
		{
			wallType = 151;
			tileType = 322;
			platformStyle = 17;
		}
		else if (player.ZoneHallow)
		{
			wallType = 43;
			tileType = 159;
			platformStyle = 3;
		}
		else if (player.ZoneGlowshroom)
		{
			wallType = 74;
			tileType = 190;
			platformStyle = 18;
		}
		else if (player.ZoneSkyHeight)
		{
			wallType = 82;
			tileType = 202;
			platformStyle = 22;
		}
		else if (player.ZoneUnderworldHeight)
		{
			wallType = 20;
			tileType = 75;
			platformStyle = 13;
		}
		if (x == 10 * side || x == side)
		{
			if ((y == -5 && tile.TileType == tileType) || ((y == -4 || y == 0) && tile.TileType == tileType) || ((y == -1 || y == -2 || y == -3) && (tile.TileType == 10 || tile.TileType == 11)))
			{
				return;
			}
		}
		else if ((y == -5 && (tile.TileType == 19 || tile.TileType == tileType)) || (y == 0 && (tile.TileType == 19 || tile.TileType == tileType)))
		{
			return;
		}
		if ((x != 9 * side && x != 2 * side) || (y != -1 && y != -2 && y != -3) || tile.TileType != 11)
		{
			FargoGlobalTile.ClearEverything(xPosition, yPosition);
		}
		if (y != -5 && y != 0 && x != 10 * side && x != side)
		{
			WorldGen.PlaceWall(xPosition, yPosition, wallType);
			if (Main.netMode == 2)
			{
				NetMessage.SendTileSquare(-1, xPosition, yPosition, 1);
			}
		}
		if (y == -5 && Math.Abs(x) >= 3 && Math.Abs(x) <= 5)
		{
			WorldGen.PlaceTile(xPosition, yPosition, 19, mute: false, forced: false, -1, platformStyle);
			if (Main.netMode == 2)
			{
				NetMessage.SendData(17, -1, -1, null, 1, xPosition, yPosition, 19f, platformStyle);
			}
		}
		else if (y == -5 || y == 0 || x == 10 * side || (x == side && y == -4))
		{
			WorldGen.PlaceTile(xPosition, yPosition, tileType);
			if (Main.netMode == 2)
			{
				NetMessage.SendTileSquare(-1, xPosition, yPosition, 1);
			}
		}
	}

	public static void PlaceFurniture(int x, int y, Vector2 position, int side, Player player)
	{
		int xPosition = (int)((float)(side * -1 + x) + position.X / 16f);
		int yPosition = (int)((float)y + position.Y / 16f);
		Tile tile = Main.tile[xPosition, yPosition];
		if (!FargoGlobalProjectile.OkayToDestroyTileAt(xPosition, yPosition, bypassVanillaCanPlace: true))
		{
			return;
		}
		if (y == -1)
		{
			if (Math.Abs(x) == 1)
			{
				int placeStyle = 0;
				if (player.ZoneDesert && !player.ZoneBeach)
				{
					placeStyle = 4;
				}
				else if (player.ZoneSnow)
				{
					placeStyle = 30;
				}
				else if (player.ZoneJungle)
				{
					placeStyle = 2;
				}
				else if (player.ZoneCorrupt)
				{
					placeStyle = 1;
				}
				else if (player.ZoneCrimson)
				{
					placeStyle = 10;
				}
				else if (player.ZoneBeach)
				{
					placeStyle = 29;
				}
				else if (player.ZoneHallow)
				{
					placeStyle = 3;
				}
				else if (player.ZoneGlowshroom)
				{
					placeStyle = 6;
				}
				else if (player.ZoneSkyHeight)
				{
					placeStyle = 9;
				}
				else if (player.ZoneUnderworldHeight)
				{
					placeStyle = 19;
				}
				WorldGen.PlaceTile(xPosition, yPosition, 10, mute: false, forced: false, -1, placeStyle);
				if (Main.netMode == 2)
				{
					NetMessage.SendTileSquare(-1, xPosition, yPosition - 2, 1, 3);
				}
			}
			if (x == 5 * side)
			{
				int placeStyle = 0;
				if (player.ZoneDesert && !player.ZoneBeach)
				{
					placeStyle = 6;
				}
				else if (player.ZoneSnow)
				{
					placeStyle = 30;
				}
				else if (player.ZoneJungle)
				{
					placeStyle = 3;
				}
				else if (player.ZoneCorrupt)
				{
					placeStyle = 2;
				}
				else if (player.ZoneCrimson)
				{
					placeStyle = 11;
				}
				else if (player.ZoneBeach)
				{
					placeStyle = 29;
				}
				else if (player.ZoneHallow)
				{
					placeStyle = 4;
				}
				else if (player.ZoneGlowshroom)
				{
					placeStyle = 9;
				}
				else if (player.ZoneSkyHeight)
				{
					placeStyle = 10;
				}
				else if (player.ZoneUnderworldHeight)
				{
					placeStyle = 16;
				}
				WorldGen.PlaceObject(xPosition, yPosition, 15, mute: false, placeStyle, 0, -1, side);
				if (Main.netMode == 2)
				{
					NetMessage.SendData(17, -1, -1, null, 1, xPosition, yPosition, 15f, placeStyle);
				}
			}
			if (x == 7 * side)
			{
				int placeStyle = 0;
				if (player.ZoneDesert && !player.ZoneBeach)
				{
					placeStyle = 30;
				}
				else if (player.ZoneSnow)
				{
					placeStyle = 28;
				}
				else if (player.ZoneJungle)
				{
					placeStyle = 2;
				}
				else if (player.ZoneCorrupt)
				{
					placeStyle = 1;
				}
				else if (player.ZoneCrimson)
				{
					placeStyle = 8;
				}
				else if (player.ZoneBeach)
				{
					placeStyle = 26;
				}
				else if (player.ZoneHallow)
				{
					placeStyle = 3;
				}
				else if (player.ZoneGlowshroom)
				{
					placeStyle = 27;
				}
				else if (player.ZoneSkyHeight)
				{
					placeStyle = 7;
				}
				else if (player.ZoneUnderworldHeight)
				{
					placeStyle = 13;
				}
				WorldGen.PlaceTile(xPosition, yPosition, 14, mute: false, forced: false, -1, placeStyle);
				if (Main.netMode == 2)
				{
					NetMessage.SendData(17, -1, -1, null, 1, xPosition, yPosition, 14f, placeStyle);
				}
			}
		}
		if (x == 7 * side && y == -4)
		{
			WorldGen.PlaceTile(xPosition, yPosition, 4, mute: false, forced: false, -1, 5);
			if (Main.netMode == 2)
			{
				NetMessage.SendData(17, -1, -1, null, 1, xPosition, yPosition, 4f);
			}
		}
	}

	public static void UpdateWall(int x, int y, Vector2 position, int side, Player player)
	{
		int xPosition = (int)((float)(side * -1 + x) + position.X / 16f);
		int yPosition = (int)((float)y + position.Y / 16f);
		WorldGen.SquareWallFrame(xPosition, yPosition);
		if (Main.netMode == 2)
		{
			NetMessage.SendTileSquare(-1, xPosition, yPosition, 1);
		}
	}

	public override void OnKill(int timeLeft)
	{
		Vector2 position = base.Projectile.Center;
		SoundEngine.PlaySound(in SoundID.Item14, position);
		Player player = Main.player[base.Projectile.owner];
		if (Main.netMode == 1)
		{
			return;
		}
		if (player.Center.X < position.X)
		{
			for (int i = 0; i < 3; i++)
			{
				for (int x = 11; x > -1; x--)
				{
					if (i == 2 || (x != 11 && x != 0))
					{
						for (int y = -6; y <= 1; y++)
						{
							if (i == 2 || (y != -6 && y != 1))
							{
								switch (i)
								{
								case 0:
									PlaceHouse(x, y, position, 1, player);
									break;
								case 1:
									PlaceFurniture(x, y, position, 1, player);
									break;
								default:
									UpdateWall(x, y, position, 1, player);
									break;
								}
							}
						}
					}
				}
			}
			return;
		}
		for (int i = 0; i < 3; i++)
		{
			for (int x = -11; x < 1; x++)
			{
				if (i != 2 && (x == -11 || x == 0))
				{
					continue;
				}
				for (int y = -6; y <= 1; y++)
				{
					if (i == 2 || (y != -6 && y != 1))
					{
						switch (i)
						{
						case 0:
							PlaceHouse(x, y, position, -1, player);
							break;
						case 1:
							PlaceFurniture(x, y, position, -1, player);
							break;
						}
					}
				}
			}
		}
	}
}
