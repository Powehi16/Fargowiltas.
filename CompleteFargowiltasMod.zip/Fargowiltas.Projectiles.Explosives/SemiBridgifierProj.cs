using Fargowiltas.Items.Tiles;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class SemiBridgifierProj : OmniBridgifierProj
{
	protected override int TileHeight => 3;

	protected override int Placeable => ModContent.TileType<SemistationSheet>();

	protected override bool Replaceable(int TileType)
	{
		return TileType == Placeable;
	}

	public override void SetStaticDefaults()
	{
	}
}
