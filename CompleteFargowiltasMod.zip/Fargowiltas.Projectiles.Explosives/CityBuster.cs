using Fargowiltas.Tiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class CityBuster : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 26;
		base.Projectile.height = 26;
		base.Projectile.aiStyle = 16;
		base.Projectile.friendly = true;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 300;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override bool OnTileCollide(Vector2 oldVelocity)
	{
		base.Projectile.velocity.X = 0f;
		return base.OnTileCollide(oldVelocity);
	}

	public override void OnKill(int timeLeft)
	{
		SoundEngine.PlaySound(in SoundID.Item15, base.Projectile.Center);
		SoundEngine.PlaySound(in SoundID.Item14, base.Projectile.Center);
		if (Main.netMode == 1)
		{
			return;
		}
		Vector2 position = base.Projectile.Center;
		int radius = 64;
		for (int x = -radius; x <= radius; x++)
		{
			for (int y = -radius * 2; y <= 0; y++)
			{
				int xPosition = (int)((float)x + position.X / 16f);
				int yPosition = (int)((float)y + position.Y / 16f);
				if (xPosition >= 0 && xPosition < Main.maxTilesX && yPosition >= 0 && yPosition < Main.maxTilesY)
				{
					Tile tile = Main.tile[xPosition, yPosition];
					if (!(tile == null) && FargoGlobalProjectile.OkayToDestroyTileAt(xPosition, yPosition) && !FargoGlobalProjectile.TileIsLiterallyAir(tile))
					{
						FargoGlobalTile.ClearTileAndLiquid(xPosition, yPosition);
					}
				}
			}
		}
		Main.refreshMap = true;
	}
}
