using Fargowiltas.Items.Tiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class OmniBridgifierProj : ModProjectile
{
	protected virtual int TileHeight => 4;

	protected virtual int Placeable => (base.Projectile.ai[0] == 0f) ? ModContent.TileType<OmnistationSheet>() : ModContent.TileType<OmnistationSheet2>();

	protected virtual bool Replaceable(int TileType)
	{
		return TileType == ModContent.TileType<OmnistationSheet>() || TileType == ModContent.TileType<OmnistationSheet2>();
	}

	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 20;
		base.Projectile.height = 36;
		base.Projectile.aiStyle = -1;
		base.Projectile.friendly = true;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 1;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override void OnKill(int timeLeft)
	{
		SoundEngine.PlaySound(in SoundID.Item14, base.Projectile.Center);
		if (Main.netMode != 1)
		{
			PlaceInDirection(1);
			PlaceInDirection(-1);
		}
		void PlaceInDirection(int direction)
		{
			Vector2 position = base.Projectile.Center;
			int xPosition = (int)(position.X / 16f);
			int yPosition = (int)(position.Y / 16f);
			int i = 64;
			bool allowOneGap = true;
			while (WorldGen.InWorld(xPosition, yPosition))
			{
				Tile platformTile = Framing.GetTileSafely(xPosition, yPosition);
				if (platformTile != null)
				{
					if (platformTile.TileType == 19)
					{
						allowOneGap = true;
						Tile tileAbove = Framing.GetTileSafely(xPosition, yPosition - 1);
						if (tileAbove != null && Replaceable(tileAbove.TileType))
						{
							i = 128;
						}
						if (i <= 0 && TryPlaceOmni(xPosition, yPosition))
						{
							i = 128;
						}
					}
					else
					{
						if (platformTile.TileType != 0 || !allowOneGap)
						{
							break;
						}
						allowOneGap = false;
					}
				}
				xPosition += direction;
				i--;
			}
		}
		bool TryPlaceOmni(int xPos, int yPos)
		{
			for (int i = -1; i <= 0; i++)
			{
				for (int j = -TileHeight; j < 0; j++)
				{
					int x = xPos + i;
					int y = yPos + j;
					if (WorldGen.InWorld(x, y))
					{
						Tile tile = Framing.GetTileSafely(x, y);
						if (tile == null || tile.TileType != 0)
						{
							return false;
						}
					}
				}
			}
			WorldGen.PlaceTile(xPos, yPos - TileHeight / 2, Placeable);
			if (Main.netMode == 2)
			{
				NetMessage.SendTileSquare(-1, xPos - 1, yPos - TileHeight, 2, TileHeight);
			}
			return true;
		}
	}
}
