using System.Linq;
using Fargowiltas.Tiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class MiniInstabridgeProj : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 20;
		base.Projectile.height = 36;
		base.Projectile.aiStyle = 16;
		base.Projectile.friendly = true;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 1;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override void OnKill(int timeLeft)
	{
		Vector2 position = base.Projectile.Center;
		SoundEngine.PlaySound(in SoundID.Item14, position);
		if (Main.netMode == 1)
		{
			return;
		}
		bool goLeft = base.Projectile.Center.X < Main.player[base.Projectile.owner].Center.X;
		int min = (goLeft ? (-400) : 0);
		int max = ((!goLeft) ? 400 : 0);
		int[] deletableTiles = new int[5] { 80, 5, 32, 352, 69 };
		for (int x = min; x < max; x++)
		{
			int xPosition = (int)((float)x + position.X / 16f);
			int yPosition = (int)(position.Y / 16f);
			if (xPosition < 0 || xPosition >= Main.maxTilesX || yPosition < 0 || yPosition >= Main.maxTilesY)
			{
				continue;
			}
			Tile tile = Main.tile[xPosition, yPosition];
			if (!(tile == null))
			{
				if (deletableTiles.Contains(tile.TileType))
				{
					FargoGlobalTile.ClearEverything(xPosition, yPosition);
				}
				WorldGen.PlaceTile(xPosition, yPosition, 19);
				NetMessage.SendTileSquare(-1, xPosition, yPosition, 1);
			}
		}
	}
}
