using Fargowiltas.Tiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class InstaProj : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 20;
		base.Projectile.height = 36;
		base.Projectile.aiStyle = 16;
		base.Projectile.friendly = true;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 1;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override bool TileCollideStyle(ref int width, ref int height, ref bool fallThrough, ref Vector2 hitboxCenterFrac)
	{
		fallThrough = false;
		return base.TileCollideStyle(ref width, ref height, ref fallThrough, ref hitboxCenterFrac);
	}

	public override bool OnTileCollide(Vector2 oldVelocity)
	{
		base.Projectile.Kill();
		return true;
	}

	public override void OnKill(int timeLeft)
	{
		Vector2 position = base.Projectile.Center;
		SoundEngine.PlaySound(in SoundID.Item14, position);
		if (Main.netMode == 1)
		{
			return;
		}
		for (int x = -3; x <= 3; x++)
		{
			for (int y = (int)(1f + position.Y / 16f); y <= Main.maxTilesY - 40; y++)
			{
				int xPosition = (int)((float)x + position.X / 16f);
				if (xPosition < 0 || xPosition >= Main.maxTilesX || y < 0 || y >= Main.maxTilesY)
				{
					continue;
				}
				Tile tile = Main.tile[xPosition, y];
				if (!(tile == null) && FargoGlobalProjectile.OkayToDestroyTileAt(xPosition, y))
				{
					FargoGlobalTile.ClearEverything(xPosition, y, sendData: false);
					WorldGen.PlaceWall(xPosition, y, 1);
					if (x == -3 || x == 3)
					{
						WorldGen.PlaceTile(xPosition, y, 38);
					}
					else if ((x == -2 || x == 2) && y % 10 == 0)
					{
						WorldGen.PlaceTile(xPosition, y, 4);
					}
					else if (x == 0)
					{
						WorldGen.PlaceTile(xPosition, y, 213);
					}
					NetMessage.SendTileSquare(-1, xPosition, y, 1);
				}
			}
		}
	}
}
