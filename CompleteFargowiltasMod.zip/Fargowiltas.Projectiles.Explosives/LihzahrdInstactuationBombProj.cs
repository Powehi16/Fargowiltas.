using System;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace Fargowiltas.Projectiles.Explosives;

public class LihzahrdInstactuationBombProj : ModProjectile
{
	public override void SetStaticDefaults()
	{
	}

	public override void SetDefaults()
	{
		base.Projectile.width = 20;
		base.Projectile.height = 36;
		base.Projectile.aiStyle = 16;
		base.Projectile.friendly = true;
		base.Projectile.penetrate = -1;
		base.Projectile.timeLeft = 1;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override void OnKill(int timeLeft)
	{
		SoundEngine.PlaySound(in SoundID.Item14, base.Projectile.Center);
		if (Main.netMode == 1)
		{
			return;
		}
		int xPos = (int)base.Projectile.Center.X / 16;
		int yPos = (int)base.Projectile.Center.Y / 16;
		int leftMax = 60;
		int rightMax = 60;
		int leftTry;
		for (leftTry = 0; leftTry >= -leftMax; leftTry--)
		{
			if (!WipeColumn(leftTry))
			{
				rightMax += leftMax - Math.Abs(leftTry);
				break;
			}
		}
		for (int rightTry = 0; rightTry <= rightMax; rightTry++)
		{
			if (!WipeColumn(rightTry))
			{
				leftMax += rightMax - rightTry;
				while (leftTry >= -leftMax && WipeColumn(leftTry))
				{
					leftTry--;
				}
				break;
			}
		}
		bool WipeColumn(int i)
		{
			for (int j = 0; j >= -60; j--)
			{
				int tileX = xPos + i;
				int tileY = yPos + j;
				if (tileX < 0 || tileX > Main.maxTilesX || tileY <= 0 || tileY > Main.maxTilesY)
				{
					if (j == 0)
					{
						return false;
					}
				}
				else
				{
					Tile tile = Framing.GetTileSafely(tileX, tileY);
					if (tile.TileType != 237)
					{
						if (tile.WallType != 87)
						{
							if (j == 0)
							{
								return false;
							}
						}
						else
						{
							Tile tileAbove = Framing.GetTileSafely(tileX, tileY - 1);
							if (TileID.Sets.BasicChest[tileAbove.TileType])
							{
								TileObjectData data = TileObjectData.GetTileData(tileAbove.TileType, 0);
								int x = tileX - tile.TileFrameX / 18 % data.Width;
								int y = tileY - 1 - tile.TileFrameY / 18 % data.Height;
								WorldGen.KillTile(x, y);
								if (Main.netMode == 2)
								{
									NetMessage.SendTileSquare(-1, x, y, 3);
								}
								if (TileID.Sets.BasicChest[tileAbove.TileType])
								{
									continue;
								}
							}
							if (TileID.Sets.BasicChest[tile.TileType])
							{
								TileObjectData data = TileObjectData.GetTileData(tile.TileType, 0);
								int x = tileX - tile.TileFrameX / 18 % data.Width;
								int y = tileY - tile.TileFrameY / 18 % data.Height;
								WorldGen.KillTile(x, y);
								if (Main.netMode == 2)
								{
									NetMessage.SendTileSquare(-1, x, y, 3);
								}
							}
							else if (tile.TileType == 226)
							{
								tile.IsActuated = true;
								if (Main.netMode == 2)
								{
									NetMessage.SendTileSquare(-1, tileX, tileY, 1);
								}
							}
							else
							{
								WorldGen.KillTile(tileX, tileY);
								if (Main.netMode == 2)
								{
									NetMessage.SendTileSquare(-1, tileX, tileY, 1);
								}
							}
						}
					}
				}
			}
			return true;
		}
	}
}
