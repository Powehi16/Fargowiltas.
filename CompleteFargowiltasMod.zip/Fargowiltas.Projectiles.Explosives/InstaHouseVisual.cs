using Fargowiltas.Items.Explosives;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Projectiles.Explosives;

public class InstaHouseVisual : ModProjectile
{
	public override void SetDefaults()
	{
		base.Projectile.width = 160;
		base.Projectile.height = 96;
		base.Projectile.timeLeft = 10;
		base.Projectile.tileCollide = false;
	}

	public override void AI()
	{
		Player player = Main.player[base.Projectile.owner];
		Vector2 mouse = Main.MouseWorld;
		if (player.position.X > mouse.X)
		{
			base.Projectile.position.X = mouse.X - (float)base.Projectile.width + 4f;
			base.Projectile.position.Y = mouse.Y - (float)base.Projectile.height + 8f + 16f;
		}
		else
		{
			base.Projectile.position.X = mouse.X - 4f;
			base.Projectile.position.Y = mouse.Y - (float)base.Projectile.height + 8f + 16f;
		}
		base.Projectile.timeLeft++;
		if (player.HeldItem.type != ModContent.ItemType<AutoHouse>())
		{
			base.Projectile.Kill();
		}
		base.Projectile.hide = base.Projectile.owner != Main.myPlayer;
	}
}
