using Fargowiltas.Content.Buffs;
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Weapons;

public class LumberJaxe : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 1;
	}

	public override void SetDefaults()
	{
		base.Item.damage = 15;
		base.Item.DamageType = DamageClass.Melee;
		base.Item.width = 40;
		base.Item.height = 40;
		base.Item.useTime = 30;
		base.Item.useAnimation = 30;
		base.Item.axe = 30;
		base.Item.useStyle = 1;
		base.Item.knockBack = 6f;
		base.Item.value = 5000;
		base.Item.rare = 3;
		base.Item.UseSound = SoundID.Item1;
		base.Item.autoReuse = true;
	}

	public override void OnHitNPC(Player player, NPC target, NPC.HitInfo hit, int damageDone)
	{
		target.AddBuff(ModContent.BuffType<WoodDrop>(), 600);
	}
}
