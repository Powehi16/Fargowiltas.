using System.Linq;
using Fargowiltas.Common.Configs;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace Fargowiltas.Tiles;

public class FargoGlobalTile : GlobalTile
{
	private enum TorchStyle
	{
		None = 0,
		Bone = 13,
		Demon = 7,
		Hallow = 20,
		Corrupt = 18,
		Crimson = 19,
		Ice = 9,
		Jungle = 21,
		Desert = 16,
		Coral = 17
	}

	private static uint LastTorchUpdate;

	private readonly int[] TorchesToReplace = new int[9] { 7, 20, 18, 19, 9, 21, 16, 17, 0 };

	public override int[] AdjTiles(int type)
	{
		if (type == 283)
		{
			return new int[2] { 18, 283 };
		}
		return base.AdjTiles(type);
	}

	public override void MouseOver(int i, int j, int type)
	{
		if (type == 219 || type == 642)
		{
			Main.player[Main.myPlayer].GetModPlayer<FargoPlayer>().extractSpeed = true;
		}
	}

	public override void KillTile(int i, int j, int type, ref bool fail, ref bool effectOnly, ref bool noItem)
	{
		if (!WorldGen.gen)
		{
			if (type == 5 || (type == 634 && !fail && !(FargoWorld.DownedBools.TryGetValue("lumberjack", out var down) && down)))
			{
				FargoWorld.WoodChopped++;
			}
			if (type == 567 && !fail)
			{
				FargoUtils.TryDowned("Deviantt", Color.HotPink, "rareEnemy", "gnome");
			}
		}
	}

	public override void NearbyEffects(int i, int j, int type, bool closer)
	{
		if (closer && TileID.Sets.Torch[type] && !Main.dedServ && Main.LocalPlayer.UsingBiomeTorches && (LastTorchUpdate < Main.GameUpdateCount - 60 || LastTorchUpdate == Main.GameUpdateCount))
		{
			LastTorchUpdate = Main.GameUpdateCount;
			if (FargoServerConfig.Instance.TorchGodEX && Main.LocalPlayer.ShoppingZone_BelowSurface && !Main.LocalPlayer.ZoneDungeon && !Main.LocalPlayer.ZoneLihzhardTemple)
			{
				int torch = Framing.GetTileSafely(i, j).TileFrameY / 22;
				bool replaceTorch = TorchesToReplace.Contains(torch);
				if (replaceTorch && ((torch == 20 && Main.LocalPlayer.ZoneHallow) || (torch == 18 && Main.LocalPlayer.ZoneCorrupt) || (torch == 19 && Main.LocalPlayer.ZoneCrimson) || (torch == 16 && (Main.LocalPlayer.ZoneDesert || Main.LocalPlayer.ZoneUndergroundDesert)) || (torch == 21 && Main.LocalPlayer.ZoneJungle) || (torch == 17 && Main.LocalPlayer.ZoneBeach)))
				{
					replaceTorch = false;
				}
				if (replaceTorch)
				{
					int style = 0;
					int correctTorch = Main.LocalPlayer.BiomeTorchPlaceStyle(ref type, ref style);
					if (correctTorch == 7)
					{
						correctTorch = 13;
					}
					else if (Main.LocalPlayer.ZoneBeach)
					{
						correctTorch = 17;
					}
					else if (correctTorch == 0)
					{
						correctTorch = 13;
					}
					if (torch != correctTorch && TorchesToReplace.Contains(torch))
					{
						WorldGen.KillTile(i, j, fail: false, effectOnly: false, noItem: true);
						WorldGen.PlaceTile(i, j, 4, mute: false, forced: false, Main.LocalPlayer.whoAmI, correctTorch);
						if (Main.netMode == 1)
						{
							NetMessage.SendData(17, -1, -1, null, 1, i, j, 4f);
						}
					}
				}
			}
		}
		if (!FargoServerConfig.Instance.PermanentStationsNearby)
		{
			return;
		}
		int buff = 0;
		SoundStyle? sound = null;
		switch (type)
		{
		case 377:
			buff = 159;
			sound = SoundID.Item37;
			break;
		case 287:
			buff = 93;
			sound = SoundID.Item149;
			break;
		case 125:
			buff = 29;
			sound = SoundID.Item4;
			break;
		case 354:
			buff = 150;
			sound = SoundID.Item4;
			break;
		case 464:
			buff = 348;
			sound = SoundID.Item4;
			break;
		}
		if (buff != 0 && Main.LocalPlayer.active && !Main.LocalPlayer.dead && !Main.LocalPlayer.ghost)
		{
			bool noAlchemistNPC = !ModLoader.HasMod("AlchemistNPC") && !ModLoader.HasMod("AlchemistNPCLite");
			if (!Main.LocalPlayer.HasBuff(buff) && sound.HasValue && noAlchemistNPC && Main.LocalPlayer.GetModPlayer<FargoPlayer>().StationSoundCooldown <= 0)
			{
				SoundStyle style2 = sound.Value;
				SoundEngine.PlaySound(in style2, new Vector2(i, j) * 16f);
				Main.LocalPlayer.GetModPlayer<FargoPlayer>().StationSoundCooldown = 3600;
			}
			Main.LocalPlayer.AddBuff(buff, 2);
		}
	}

	internal static void DestroyChest(int x, int y)
	{
		int chestType = 1;
		int chest = Chest.FindChest(x, y);
		if (chest != -1)
		{
			for (int i = 0; i < 40; i++)
			{
				Main.chest[chest].item[i] = new Item();
			}
			Main.chest[chest] = null;
			if (Main.tile[x, y].TileType == 467)
			{
				chestType = 5;
			}
			if (Main.tile[x, y].TileType >= TileID.Count)
			{
				chestType = 101;
			}
		}
		for (int i = x; i < x + 2; i++)
		{
			for (int j = y; j < y + 2; j++)
			{
				Main.tile[i, j].TileType = 0;
				Main.tile[i, j].TileFrameX = 0;
				Main.tile[i, j].TileFrameY = 0;
			}
		}
		if (Main.netMode != 0)
		{
			if (chest != -1)
			{
				NetMessage.SendData(34, -1, -1, null, chestType, x, y, 0f, chest, Main.tile[x, y].TileType);
			}
			NetMessage.SendTileSquare(-1, x, y, 3);
		}
	}

	internal static Point16 FindChestTopLeft(int x, int y, bool destroy)
	{
		Tile tile = Main.tile[x, y];
		if (TileID.Sets.BasicChest[tile.TileType])
		{
			TileObjectData data = TileObjectData.GetTileData(tile.TileType, 0);
			x -= tile.TileFrameX / 18 % data.Width;
			y -= tile.TileFrameY / 18 % data.Height;
			if (destroy)
			{
				DestroyChest(x, y);
			}
			return new Point16(x, y);
		}
		return Point16.NegativeOne;
	}

	internal static void ClearTileAndLiquid(int x, int y, bool sendData = true)
	{
		FindChestTopLeft(x, y, destroy: true);
		Tile tile = Main.tile[x, y];
		bool hadLiquid = tile.LiquidAmount != 0;
		WorldGen.KillTile(x, y, fail: false, effectOnly: false, noItem: true);
		tile.Clear(TileDataType.Tile);
		tile.Clear(TileDataType.Liquid);
		if (Main.netMode == 2)
		{
			if (hadLiquid)
			{
				NetMessage.sendWater(x, y);
			}
			if (sendData)
			{
				NetMessage.SendTileSquare(-1, x, y, 1);
			}
		}
	}

	internal static void ClearEverything(int x, int y, bool sendData = true)
	{
		FindChestTopLeft(x, y, destroy: true);
		Tile tile = Main.tile[x, y];
		bool hadLiquid = tile.LiquidAmount != 0;
		WorldGen.KillTile(x, y, fail: false, effectOnly: false, noItem: true);
		tile.ClearEverything();
		if (Main.netMode == 2)
		{
			if (hadLiquid)
			{
				NetMessage.sendWater(x, y);
			}
			if (sendData)
			{
				NetMessage.SendTileSquare(-1, x, y, 1);
			}
		}
	}
}
