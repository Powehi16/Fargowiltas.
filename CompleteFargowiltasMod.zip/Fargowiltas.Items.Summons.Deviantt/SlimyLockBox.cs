namespace Fargowiltas.Items.Summons.Deviantt;

public class SlimyLockBox : BaseSummon
{
	public override int NPCType => 71;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
