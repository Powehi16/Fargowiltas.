using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class ClownLicense : BaseSummon
{
	public override int NPCType => 109;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime || player.ZoneDirtLayerHeight || player.ZoneRockLayerHeight || player.ZoneUnderworldHeight;
	}
}
