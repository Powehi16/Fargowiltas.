namespace Fargowiltas.Items.Summons.Deviantt;

public class GnomeHat : BaseSummon
{
	public override int NPCType => 624;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
