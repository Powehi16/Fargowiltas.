namespace Fargowiltas.Items.Summons.Deviantt;

public class CorruptChest : BaseSummon
{
	public override int NPCType => 473;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
