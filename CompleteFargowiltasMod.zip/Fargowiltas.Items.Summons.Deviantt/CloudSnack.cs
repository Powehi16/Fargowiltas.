namespace Fargowiltas.Items.Summons.Deviantt;

public class CloudSnack : BaseSummon
{
	public override int NPCType => 87;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
