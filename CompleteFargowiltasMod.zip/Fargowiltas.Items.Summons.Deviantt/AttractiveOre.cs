using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class AttractiveOre : BaseSummon
{
	public override int NPCType => 44;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime || player.ZoneDirtLayerHeight || player.ZoneRockLayerHeight || player.ZoneUnderworldHeight;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(3988).AddIngredient(88).AddIngredient(296)
			.AddTile(283)
			.Register();
	}
}
