using Fargowiltas.Common.Systems.Recipes;
using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class BloodUrchin : BaseSummon
{
	public override int NPCType => 621;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime && Main.bloodMoon;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(4271).AddIngredient(1085).AddRecipeGroup(RecipeGroups.AnyFoodT3)
			.AddTile(134)
			.Register();
	}
}
