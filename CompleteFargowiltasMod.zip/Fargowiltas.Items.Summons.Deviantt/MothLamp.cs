namespace Fargowiltas.Items.Summons.Deviantt;

public class MothLamp : BaseSummon
{
	public override int NPCType => 205;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
