using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.Chat;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Deviantt;

public class PinkSlimeCrown : ModItem
{
	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.rare = 4;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
	}

	public override bool? UseItem(Player player)
	{
		int n = NPC.NewNPC(NPC.GetBossSpawnSource(player.whoAmI), (int)player.position.X + Main.rand.Next(-800, 800), (int)player.position.Y + Main.rand.Next(-800, -250), 1);
		Main.npc[n].SetDefaults(-4);
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		LocalizedText text = Language.GetText("Announcement.HasAwoken");
		string pinky = Lang.GetNPCNameValue(-4);
		if (Main.netMode == 2)
		{
			ChatHelper.BroadcastChatMessage(text.ToNetworkText(pinky), new Color(175, 75, 255));
		}
		else
		{
			Main.NewText(text.Format(pinky), new Color(175, 75, 255));
		}
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(560).AddIngredient(1018).AddTile(228)
			.Register();
	}
}
