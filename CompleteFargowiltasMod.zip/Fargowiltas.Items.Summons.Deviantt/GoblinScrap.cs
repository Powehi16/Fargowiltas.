namespace Fargowiltas.Items.Summons.Deviantt;

public class GoblinScrap : BaseSummon
{
	public override int NPCType => 73;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
