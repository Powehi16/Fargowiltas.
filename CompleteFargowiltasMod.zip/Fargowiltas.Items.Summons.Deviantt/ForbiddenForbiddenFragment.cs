namespace Fargowiltas.Items.Summons.Deviantt;

public class ForbiddenForbiddenFragment : BaseSummon
{
	public override int NPCType => 541;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
