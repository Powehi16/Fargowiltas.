using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class HolyGrail : BaseSummon
{
	public override int NPCType => 45;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime || player.ZoneDirtLayerHeight || player.ZoneRockLayerHeight || player.ZoneUnderworldHeight;
	}

	public override void AddRecipes()
	{
		Recipe(57);
		Recipe(1257);
		void Recipe(int bar)
		{
			CreateRecipe().AddIngredient(bar, 3).AddIngredient(2328, 7).AddIngredient(176)
				.AddIngredient(109)
				.AddTile(26)
				.Register();
		}
	}
}
