using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class WormSnack : BaseSummon
{
	public override int NPCType => Main.hardMode ? 95 : 10;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return player.ZoneDirtLayerHeight || player.ZoneRockLayerHeight || player.ZoneUnderworldHeight;
	}
}
