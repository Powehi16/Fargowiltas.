using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class DemonicPlushie : BaseSummon
{
	public override int NPCType => 156;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return player.ZoneUnderworldHeight;
	}
}
