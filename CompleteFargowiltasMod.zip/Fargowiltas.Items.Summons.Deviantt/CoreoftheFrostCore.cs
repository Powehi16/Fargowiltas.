using Terraria;
using Terraria.DataStructures;
using Terraria.ID;

namespace Fargowiltas.Items.Summons.Deviantt;

public class CoreoftheFrostCore : BaseSummon
{
	public override int NPCType => 243;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
		Main.RegisterItemAnimation(base.Item.type, new DrawAnimationVertical(6, 6));
		ItemID.Sets.AnimatesAsSoul[base.Item.type] = true;
	}
}
