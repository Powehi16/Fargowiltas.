using Fargowiltas.Common.Systems.Recipes;
using Fargowiltas.Projectiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Deviantt;

public class SuspiciousLookingLure : ModItem
{
	public override void SetStaticDefaults()
	{
		CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[base.Type] = 3;
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime;
	}

	public override void SetDefaults()
	{
		base.Item.width = 20;
		base.Item.height = 20;
		base.Item.maxStack = 20;
		base.Item.value = Item.sellPrice(0, 0, 2);
		base.Item.rare = 1;
		base.Item.useAnimation = 30;
		base.Item.useTime = 30;
		base.Item.useStyle = 5;
		base.Item.consumable = true;
		base.Item.shoot = ModContent.ProjectileType<SpawnProj>();
	}

	public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
	{
		Projectile.NewProjectile(position: new Vector2((int)player.position.X + Main.rand.Next(-800, 800), (int)player.position.Y + Main.rand.Next(-1000, -250)), spawnSource: player.GetSource_ItemUse(source.Item), velocity: Vector2.Zero, Type: ModContent.ProjectileType<SpawnProj>(), Damage: 0, KnockBack: 0f, Owner: Main.myPlayer, ai0: 587f);
		Projectile.NewProjectile(position: new Vector2((int)player.position.X + Main.rand.Next(-800, 800), (int)player.position.Y + Main.rand.Next(-1000, -250)), spawnSource: player.GetSource_ItemUse(source.Item), velocity: Vector2.Zero, Type: ModContent.ProjectileType<SpawnProj>(), Damage: 0, KnockBack: 0f, Owner: Main.myPlayer, ai0: 586f);
		SoundEngine.PlaySound(in SoundID.Roar, player.position);
		return true;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(4271).AddIngredient(1085).AddRecipeGroup(RecipeGroups.AnyFoodT2)
			.AddTile(16)
			.Register();
	}
}
