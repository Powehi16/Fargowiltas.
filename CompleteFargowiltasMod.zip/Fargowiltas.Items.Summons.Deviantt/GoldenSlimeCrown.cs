using Fargowiltas.Items.Tiles;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Deviantt;

public class GoldenSlimeCrown : BaseSummon
{
	public override int NPCType => 667;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(ModContent.ItemType<PinkSlimeCrown>()).AddIngredient(1348, 999).AddTile(ModContent.TileType<GoldenDippingVatSheet>())
			.Register();
	}
}
