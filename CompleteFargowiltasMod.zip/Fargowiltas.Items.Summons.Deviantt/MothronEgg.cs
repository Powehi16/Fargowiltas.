using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class MothronEgg : BaseSummon
{
	public override int NPCType => 477;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return Main.eclipse;
	}
}
