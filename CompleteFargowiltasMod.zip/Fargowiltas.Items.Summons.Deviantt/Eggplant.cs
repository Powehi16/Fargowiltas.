using Terraria;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Deviantt;

public class Eggplant : BaseSummon
{
	public override int NPCType => 52;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime || player.ZoneDirtLayerHeight || player.ZoneRockLayerHeight || player.ZoneUnderworldHeight;
	}

	public override void AddRecipes()
	{
		if (ModContent.TryFind<ModItem>("Fargowiltas/Deviantt", out var modItem))
		{
			Recipe(4292);
			Recipe(4294);
		}
		void Recipe(int fruit)
		{
			CreateRecipe().AddIngredient(fruit).AddIngredient(331, 4).AddIngredient(210, 2)
				.AddIngredient(195, 2)
				.AddIngredient(modItem.Type)
				.AddTile(16)
				.Register();
		}
	}
}
