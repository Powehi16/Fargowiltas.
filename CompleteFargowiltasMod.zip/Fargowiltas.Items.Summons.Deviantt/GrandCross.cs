using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class GrandCross : BaseSummon
{
	public override int NPCType => 290;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime || player.ZoneDirtLayerHeight || player.ZoneRockLayerHeight || player.ZoneUnderworldHeight;
	}
}
