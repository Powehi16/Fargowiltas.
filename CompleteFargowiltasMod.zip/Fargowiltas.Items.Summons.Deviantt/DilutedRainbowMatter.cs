namespace Fargowiltas.Items.Summons.Deviantt;

public class DilutedRainbowMatter : BaseSummon
{
	public override int NPCType => 244;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
