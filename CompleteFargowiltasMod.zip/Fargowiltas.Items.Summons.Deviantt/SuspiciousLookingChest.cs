using System.Collections.Generic;
using Terraria;
using Terraria.Localization;
using Terraria.ModLoader;

namespace Fargowiltas.Items.Summons.Deviantt;

public class SuspiciousLookingChest : BaseSummon
{
	public override int NPCType => Main.LocalPlayer.ZoneSnow ? 629 : 85;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		if (!Main.hardMode && !FargoUtils.EternityMode)
		{
			return false;
		}
		return base.CanUseItem(player);
	}

	public override void ModifyTooltips(List<TooltipLine> tooltips)
	{
		if (!FargoUtils.EternityMode)
		{
			tooltips.Insert(4, new TooltipLine(base.Mod, "HardmodeLock", Language.GetTextValue("Mods.Fargowiltas.Items.SuspiciousLookingChest.HardmodeLock")));
		}
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddRecipeGroup("Fargowiltas:AnyDemoniteBar", 10).AddIngredient(73, 10).AddIngredient(48)
			.AddTile(26)
			.Register();
	}
}
