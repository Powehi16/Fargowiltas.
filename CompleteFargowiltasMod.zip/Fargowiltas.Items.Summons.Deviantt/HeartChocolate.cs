using Fargowiltas.Common.Systems.Recipes;
using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class HeartChocolate : BaseSummon
{
	public override int NPCType => 196;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime || player.ZoneDirtLayerHeight || player.ZoneRockLayerHeight || player.ZoneUnderworldHeight;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(29).AddRecipeGroup(RecipeGroups.AnyFoodT2).AddTile(96)
			.Register();
	}
}
