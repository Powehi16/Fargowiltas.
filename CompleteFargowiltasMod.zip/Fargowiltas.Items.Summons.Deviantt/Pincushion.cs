using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class Pincushion : BaseSummon
{
	public override int NPCType => 463;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return Main.eclipse;
	}
}
