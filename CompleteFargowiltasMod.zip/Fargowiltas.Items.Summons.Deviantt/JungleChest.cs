namespace Fargowiltas.Items.Summons.Deviantt;

public class JungleChest : BaseSummon
{
	public override int NPCType => 476;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
