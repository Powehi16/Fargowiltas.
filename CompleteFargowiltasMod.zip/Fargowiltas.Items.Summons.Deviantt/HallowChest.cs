namespace Fargowiltas.Items.Summons.Deviantt;

public class HallowChest : BaseSummon
{
	public override int NPCType => 475;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
