namespace Fargowiltas.Items.Summons.Deviantt;

public class PlunderedBooty : BaseSummon
{
	public override int NPCType => 491;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
