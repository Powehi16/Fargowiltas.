using Fargowiltas.Common.Systems.Recipes;
using Terraria;

namespace Fargowiltas.Items.Summons.Deviantt;

public class RuneOrb : BaseSummon
{
	public override int NPCType => 172;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}

	public override bool CanUseItem(Player player)
	{
		return !Main.dayTime || player.ZoneDirtLayerHeight || player.ZoneRockLayerHeight || player.ZoneUnderworldHeight;
	}

	public override void AddRecipes()
	{
		CreateRecipe().AddIngredient(238).AddRecipeGroup(RecipeGroups.AnyGemRobe).AddIngredient(154, 10)
			.AddTile(134)
			.Register();
	}
}
