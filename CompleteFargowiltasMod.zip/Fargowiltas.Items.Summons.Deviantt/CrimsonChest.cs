namespace Fargowiltas.Items.Summons.Deviantt;

public class CrimsonChest : BaseSummon
{
	public override int NPCType => 474;

	public override void SetStaticDefaults()
	{
		base.SetStaticDefaults();
	}
}
