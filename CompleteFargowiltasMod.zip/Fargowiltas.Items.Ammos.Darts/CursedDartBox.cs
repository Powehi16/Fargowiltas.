namespace Fargowiltas.Items.Ammos.Darts;

internal class CursedDartBox : BaseAmmo
{
	public override int AmmunitionItem => 3010;
}
