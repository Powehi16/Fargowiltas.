namespace Fargowiltas.Items.Ammos.Darts;

internal class IchorDartBox : BaseAmmo
{
	public override int AmmunitionItem => 3011;
}
