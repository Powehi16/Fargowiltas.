namespace Fargowiltas.Items.Ammos.Darts;

internal class CrystalDartBox : BaseAmmo
{
	public override int AmmunitionItem => 3009;
}
