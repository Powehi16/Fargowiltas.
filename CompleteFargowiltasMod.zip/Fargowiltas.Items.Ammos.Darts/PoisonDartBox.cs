namespace Fargowiltas.Items.Ammos.Darts;

internal class PoisonDartBox : BaseAmmo
{
	public override int AmmunitionItem => 1310;
}
